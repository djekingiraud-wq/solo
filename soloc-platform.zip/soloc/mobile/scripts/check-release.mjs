// Contrôle AVANT un build de test ou de production : refuse les valeurs d'exemple et le HTTP en clair.
//   node scripts/check-release.mjs preview|production
import fs from 'node:fs';
const profile = process.argv[2] || 'production';
const eas = JSON.parse(fs.readFileSync(new URL('../eas.json', import.meta.url)));
const app = JSON.parse(fs.readFileSync(new URL('../app.json', import.meta.url))).expo;
const problems = [];
const url = eas.build?.[profile]?.env?.EXPO_PUBLIC_API_URL;
if (!url) problems.push(`eas.json : build.${profile}.env.EXPO_PUBLIC_API_URL manquant`);
else {
  if (!/^https:\/\/[^/\s]+$/.test(url)) problems.push(`EXPO_PUBLIC_API_URL doit être en https:// sans « / » final (reçu ${url}) : iOS et Android bloquent le HTTP en clair pour les builds distribués`);
  if (/\.example|localhost|127\.0\.0\.1|192\.168\.|10\.0\.2\.2/.test(url)) problems.push(`EXPO_PUBLIC_API_URL est une adresse d'exemple ou locale (${url})`);
}
if (/^com\.soloc\.app$/.test(app.ios?.bundleIdentifier || '') || /^com\.soloc\.app$/.test(app.android?.package || '')) problems.push('Identifiants com.soloc.app = provisoires : à remplacer par ceux de votre organisation avant la PREMIÈRE publication (impossible à changer ensuite sur les stores)');
if (profile === 'production' && /A_REMPLACER/.test(JSON.stringify(eas.submit?.production || {}))) problems.push('eas.json : submit.production.ios.ascAppId à renseigner (identifiant App Store Connect)');
if (!/^\d+\.\d+\.\d+$/.test(app.version || '')) problems.push('app.json : version doit être de la forme X.Y.Z');
if (app.ios?.config?.usesNonExemptEncryption !== false && app.ios?.infoPlist?.ITSAppUsesNonExemptEncryption === undefined) problems.push('Déclaration de chiffrement iOS absente');
if (problems.length) { console.error(`Profil « ${profile} » NON PRÊT :\n- ` + problems.join('\n- ')); process.exit(1); }
console.log(`Profil « ${profile} » : contrôles de configuration OK (cela ne prouve pas que le build ou l'app fonctionnent).`);
