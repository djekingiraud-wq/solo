import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';

const script = fs.readFileSync(new URL('../scripts/check-release.mjs', import.meta.url), 'utf8');
function run(eas: unknown, app: unknown, profile = 'production') {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'soloc-rel-')); fs.mkdirSync(path.join(dir, 'scripts'));
  fs.writeFileSync(path.join(dir, 'scripts/check-release.mjs'), script); fs.writeFileSync(path.join(dir, 'eas.json'), JSON.stringify(eas)); fs.writeFileSync(path.join(dir, 'app.json'), JSON.stringify({ expo: app }));
  return spawnSync('node', [path.join(dir, 'scripts/check-release.mjs'), profile], { encoding: 'utf8' });
}
const goodApp = { version: '1.0.0', ios: { bundleIdentifier: 'fr.monentreprise.soloc', config: { usesNonExemptEncryption: false } }, android: { package: 'fr.monentreprise.soloc' } };
const goodEas = { build: { production: { env: { EXPO_PUBLIC_API_URL: 'https://app.monentreprise.fr' } }, preview: { env: { EXPO_PUBLIC_API_URL: 'https://staging.monentreprise.fr' } } }, submit: { production: { ios: { ascAppId: '1234567890' } } } };

test('contrôle de publication : une configuration réelle est acceptée', () => { assert.equal(run(goodEas, goodApp).status, 0); assert.equal(run(goodEas, goodApp, 'preview').status, 0); });
test('contrôle de publication : HTTP en clair, adresses locales ou d\'exemple, identifiants provisoires refusés', () => {
  const bad = (url: string) => run({ ...goodEas, build: { production: { env: { EXPO_PUBLIC_API_URL: url } } } }, goodApp);
  for (const u of ['http://app.monentreprise.fr', 'https://app.monentreprise.fr/', 'https://soloc.example', 'https://localhost', 'https://192.168.1.20']) assert.equal(bad(u).status, 1, u);
  assert.equal(run(goodEas, { ...goodApp, android: { package: 'com.soloc.app' } }).status, 1);
  assert.equal(run({ ...goodEas, submit: { production: { ios: { ascAppId: 'A_REMPLACER' } } } }, goodApp).status, 1);
  assert.equal(run({ build: { production: {} } }, goodApp).status, 1);
});
