import test from 'node:test';
import assert from 'node:assert/strict';
import { createApi } from '../src/api.ts';
import { ApiError, describeError, isNetwork } from '../src/errors.ts';
import { eur, parseIntStrict } from '../src/format.ts';
import { atTen, fmtDay, validRange } from '../src/dates.ts';

const json = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const mk = (fetchImpl: any, extra: any = {}) => createApi({ baseUrl: 'http://x', getToken: () => 'tok', fetchImpl, ...extra });

test('envoie le jeton Bearer et l\'en-tête mobile', async () => {
  let seen: any;
  await mk(async (_u: string, init: any) => { seen = init.headers; return json(200, { ok: 1 }); }).get('/p');
  assert.equal(seen.authorization, 'Bearer tok'); assert.equal(seen['x-soloc-client'], 'mobile');
});

test('coupure réseau : GET rejoué une fois, puis erreur "network" explicite', async () => {
  let n = 0;
  const api = mk(async () => { n++; throw new TypeError('Network request failed'); });
  await assert.rejects(() => api.get('/p'), (e: any) => e instanceof ApiError && e.kind === 'network' && isNetwork(e));
  assert.equal(n, 2);
});

test('coupure réseau : un POST n\'est JAMAIS rejoué (pas de réservation en double)', async () => {
  let n = 0;
  const api = mk(async () => { n++; throw new TypeError('Network request failed'); });
  await assert.rejects(() => api.post('/api/bookings', {}), (e: any) => e.kind === 'network');
  assert.equal(n, 1);
});

test('délai dépassé : kind "timeout"', async () => {
  const api = mk((_u: string, init: any) => new Promise((_r, rej) => init.signal.addEventListener('abort', () => rej(Object.assign(new Error('a'), { name: 'AbortError' })))), { timeoutMs: 30 });
  await assert.rejects(() => api.post('/p'), (e: any) => e.kind === 'timeout');
});

test('statuts HTTP -> types d\'erreur ; 401 avec jeton déclenche la déconnexion', async () => {
  let out = 0;
  const cases: [number, string][] = [[400, 'validation'], [401, 'unauthorized'], [403, 'forbidden'], [404, 'notfound'], [409, 'conflict'], [429, 'ratelimited'], [503, 'server']];
  for (const [s, k] of cases) {
    const api = mk(async () => json(s, { error: 'c', message: 'Message serveur' }), { onUnauthorized: () => out++ });
    await assert.rejects(() => api.post('/p'), (e: any) => e.kind === k && e.status === s && e.code === 'c');
  }
  assert.equal(out, 1);
});

test('réponse non JSON : erreur propre, pas d\'exception brute', async () => {
  await assert.rejects(() => mk(async () => new Response('<html>502</html>', { status: 502 })).get('/p'), (e: any) => e.kind === 'server');
});

test('messages utilisateur en français, sans jargon', () => {
  assert.match(describeError(new ApiError('network', '')), /Vérifiez votre réseau/);
  assert.equal(describeError(new ApiError('conflict', "Ce véhicule n'est plus disponible sur ces dates.")), "Ce véhicule n'est plus disponible sur ces dates.");
  assert.equal(describeError(new Error('boom')), 'Une erreur est survenue.');
});

test('formats : euros, dates, saisies', () => {
  assert.equal(eur(4900), '49\u00a0€'); assert.equal(eur(123456), '1\u202f234,56\u00a0€'); assert.equal(eur(-500), '−5\u00a0€');
  assert.equal(fmtDay('2026-10-15T10:00:00'), 'jeu. 15 oct.');
  assert.equal(parseIntStrict(' 12 000 '), 12000); assert.equal(parseIntStrict('12,5'), null); assert.equal(parseIntStrict('abc'), null);
  assert.equal(validRange(new Date(2026, 9, 1), new Date(2026, 9, 1)), false);
  assert.equal(new Date(atTen(new Date(2026, 9, 15, 23))).getHours(), 10);
});
