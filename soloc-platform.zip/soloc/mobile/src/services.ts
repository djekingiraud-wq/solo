import type { Api } from './api.ts';
import type { Booking, Incident, IncidentCategory, Option, Quote, Severity, User, Vehicle } from './types.ts';

// Un seul point d'accès aux routes du backend : les règles métier (prix, disponibilité, droits) restent côté serveur.
export function createServices(api: Api) {
  const q = (s: string) => encodeURIComponent(s);
  return {
    config: (): Promise<{ onlinePayment: boolean }> => api.get('/api/config'),
    checkout: (ref: string): Promise<{ url: string }> => api.post(`/api/bookings/${q(ref)}/checkout`),
    me: (): Promise<User | null> => api.get('/api/me'),
    login: (email: string, password: string): Promise<User> => api.post('/api/auth/login', { email, password }),
    register: (i: { email: string; password: string; firstName: string; lastName: string }): Promise<User> => api.post('/api/auth/register', i),
    logout: (): Promise<unknown> => api.post('/api/auth/logout'),
    vehicles: (from?: string, to?: string): Promise<Vehicle[]> => api.get(from && to ? `/api/vehicles?from=${q(from)}&to=${q(to)}` : '/api/vehicles'),
    options: (): Promise<Option[]> => api.get('/api/options'),
    quote: (vehicle: string, from: string, to: string, options: string[]): Promise<Quote> =>
      api.get(`/api/quote?vehicle=${q(vehicle)}&from=${q(from)}&to=${q(to)}&options=${q(options.join(','))}`),
    createBooking: (i: { vehicleId: string; start: string; end: string; options: string[] }): Promise<Booking> => api.post('/api/bookings', i),
    bookings: (status?: string): Promise<Booking[]> => api.get(status ? `/api/bookings?status=${q(status)}` : '/api/bookings'),
    booking: (ref: string): Promise<Booking> => api.get(`/api/bookings/${q(ref)}`),
    cancel: (ref: string): Promise<Booking> => api.post(`/api/bookings/${q(ref)}/cancel`),
    confirm: (ref: string): Promise<Booking> => api.post(`/api/admin/bookings/${q(ref)}/confirm`),
    refuse: (ref: string): Promise<Booking> => api.post(`/api/admin/bookings/${q(ref)}/refuse`),
    pickup: (ref: string, odometerKm: number, fuelLevel: number, notes = ''): Promise<Booking> => api.post(`/api/bookings/${q(ref)}/pickup`, { odometerKm, fuelLevel, notes }),
    giveBack: (ref: string, odometerKm: number, fuelLevel: number, notes = ''): Promise<Booking> => api.post(`/api/bookings/${q(ref)}/return`, { odometerKm, fuelLevel, notes }),
    incidents: (): Promise<Incident[]> => api.get('/api/incidents'),
    createIncident: (i: { vehicleId: string; bookingRef?: string; category: IncidentCategory; severity: Severity; description: string }): Promise<Incident> => api.post('/api/incidents', i),
  };
}
export type Services = ReturnType<typeof createServices>;
