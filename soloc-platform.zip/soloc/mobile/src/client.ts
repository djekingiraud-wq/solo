import { createApi } from './api.ts';
import { createServices } from './services.ts';

export const API_URL = process.env.EXPO_PUBLIC_API_URL ?? 'http://localhost:3000';
let token: string | null = null;
let onUnauthorized: (() => void) | null = null;
export const setToken = (t: string | null) => { token = t; };
export const hasToken = () => token !== null;
export const setUnauthorizedHandler = (fn: (() => void) | null) => { onUnauthorized = fn; };

export const services = createServices(createApi({ baseUrl: API_URL, getToken: () => token, onUnauthorized: () => onUnauthorized?.() }));
