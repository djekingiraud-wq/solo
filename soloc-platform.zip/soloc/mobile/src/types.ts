export type Role = 'client' | 'employee' | 'admin';
export type BookingStatus = 'pending' | 'confirmed' | 'active' | 'completed' | 'cancelled' | 'refused' | 'expired';
export interface User { id: number; email: string; firstName: string; lastName: string; role: Role; token?: string }
export interface Vehicle {
  id: string; name: string; category: string; bodyType: 'cit' | 'ber' | 'suv' | 'spo'; color: string; seats: number; fuel: string;
  transmission: string; dailyPriceCents: number; depositCents: number; status: string; available: boolean; plate?: string;
}
export interface Option { id: string; label: string; perDayCents: number }
export interface Quote {
  days: number; baseCents: number; discountCents: number; optionsCents: number; totalCents: number; vatCents: number; depositCents: number; options: string[];
}
export interface Booking {
  ref: string; vehicleId: string; vehicleName: string; start: string; end: string; status: BookingStatus; days: number; baseCents: number;
  discountCents: number; optionsCents: number; vatCents: number; totalCents: number; depositCents: number; options: string[];
  expiresAt: string | null; paidCents: number; createdAt: string; client?: string; clientEmail?: string;
}
export type IncidentCategory = 'damage' | 'cleaning' | 'maintenance' | 'delay' | 'other';
export type Severity = 'low' | 'medium' | 'high';
export interface Incident {
  id: number; vehicleId: string; vehicleName: string; bookingRef: string | null; category: IncidentCategory; severity: Severity;
  description: string; status: string; createdAt: string; author: string | null;
}
