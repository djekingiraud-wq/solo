import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import * as SecureStore from 'expo-secure-store';
import { services, setToken, setUnauthorizedHandler } from './client';
import { isNetwork } from './errors';
import type { User } from './types';

const KEY = 'soloc_token';
interface Ctx {
  user: User | null; ready: boolean; offline: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (i: { email: string; password: string; firstName: string; lastName: string }) => Promise<void>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
}
const SessionCtx = createContext<Ctx>(null as unknown as Ctx);
export const useSession = () => useContext(SessionCtx);

export function SessionProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  const [offline, setOffline] = useState(false);

  const clear = useCallback(async () => { setToken(null); setUser(null); await SecureStore.deleteItemAsync(KEY).catch(() => {}); }, []);
  const store = useCallback(async (u: User) => {
    const { token, ...rest } = u;
    if (!token) throw new Error('Jeton manquant');
    setToken(token); await SecureStore.setItemAsync(KEY, token); setUser(rest);
  }, []);

  const refresh = useCallback(async () => {
    try {
      const me = await services.me();
      setOffline(false);
      if (me) setUser(me); else await clear();
    } catch (e) {
      if (isNetwork(e)) setOffline(true); // hors ligne : on garde le jeton et on réessaiera
      else await clear();
    }
  }, [clear]);

  useEffect(() => {
    setUnauthorizedHandler(() => { void clear(); });
    (async () => {
      const t = await SecureStore.getItemAsync(KEY).catch(() => null);
      if (t) { setToken(t); await refresh(); }
      setReady(true);
    })();
    return () => setUnauthorizedHandler(null);
  }, [clear, refresh]);

  const value = useMemo<Ctx>(() => ({
    user, ready, offline, refresh,
    login: async (email, password) => store(await services.login(email, password)),
    register: async (i) => store(await services.register(i)),
    logout: async () => { try { await services.logout(); } catch { /* le jeton local est supprimé quoi qu'il arrive */ } await clear(); },
  }), [user, ready, offline, refresh, store, clear]);
  return <SessionCtx.Provider value={value}>{children}</SessionCtx.Provider>;
}
