import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View, type ViewStyle } from 'react-native';
import { theme as t } from './theme';
import { describeError, isNetwork } from './errors';
import type { Tone } from './format';

export function Button({ title, onPress, kind = 'primary', disabled, loading, style }: {
  title: string; onPress: () => void; kind?: 'primary' | 'secondary' | 'danger'; disabled?: boolean; loading?: boolean; style?: ViewStyle;
}) {
  const off = disabled || loading;
  const bg = kind === 'primary' ? t.safran : 'transparent';
  const fg = kind === 'danger' ? t.err : kind === 'secondary' ? t.nuit : '#1d1503';
  return (
    <Pressable accessibilityRole="button" accessibilityState={{ disabled: !!off, busy: !!loading }} disabled={off} onPress={onPress}
      style={({ pressed }) => [s.btn, { backgroundColor: bg, borderWidth: kind === 'primary' ? 0 : 1.5, borderColor: fg, opacity: off ? 0.45 : pressed ? 0.8 : 1 }, style]}>
      {loading ? <ActivityIndicator color={fg} /> : <Text style={[s.btnText, { color: fg }]}>{title}</Text>}
    </Pressable>
  );
}

const TONES: Record<Tone, [string, string]> = { ok: [t.okBg, t.ok], warn: [t.warnBg, t.warn], err: [t.errBg, t.err], neutral: [t.neutralBg, t.neutral] };
export function Tag({ label, tone = 'neutral' }: { label: string; tone?: Tone }) {
  return <View style={[s.tag, { backgroundColor: TONES[tone][0] }]}><Text style={{ color: TONES[tone][1], fontWeight: '600', fontSize: 12 }}>{label}</Text></View>;
}

export function Loading() { return <View style={s.center}><ActivityIndicator size="large" color={t.nuit} accessibilityLabel="Chargement" /></View>; }

export function ErrorState({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
  return (
    <View style={s.center} accessibilityRole="alert">
      <Text style={s.errTitle}>{isNetwork(error) ? 'Pas de connexion' : 'Un problème est survenu'}</Text>
      <Text style={s.errText}>{describeError(error)}</Text>
      {onRetry ? <Button title="Réessayer" onPress={onRetry} kind="secondary" style={{ marginTop: 16, alignSelf: 'stretch' }} /> : null}
    </View>
  );
}
// Bandeau d'erreur non bloquant : on garde les données déjà affichées.
export function ErrorBanner({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
  return (
    <Pressable onPress={onRetry} accessibilityRole="button" accessibilityLabel={`${describeError(error)} Toucher pour réessayer`} style={s.banner}>
      <Text style={{ color: t.err, fontWeight: '600' }}>{describeError(error)}</Text>
      {onRetry ? <Text style={{ color: t.err, marginTop: 2 }}>Toucher pour réessayer</Text> : null}
    </Pressable>
  );
}
export function Empty({ title, text, action }: { title: string; text?: string; action?: React.ReactNode }) {
  return <View style={s.center}><Text style={s.errTitle}>{title}</Text>{text ? <Text style={s.errText}>{text}</Text> : null}{action ? <View style={{ marginTop: 16, alignSelf: 'stretch' }}>{action}</View> : null}</View>;
}
export function Line({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return <View style={s.line}><Text style={[s.lineT, bold && { color: t.texte, fontWeight: '700' }]}>{label}</Text><Text style={[s.lineT, bold && { color: t.texte, fontWeight: '700' }]}>{value}</Text></View>;
}
export function Chips<T extends string>({ items, value, onChange, label }: { items: { id: T; label: string }[]; value: T | null; onChange: (v: T) => void; label: string }) {
  return (
    <View accessibilityRole="radiogroup" accessibilityLabel={label} style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
      {items.map((i) => (
        <Pressable key={i.id} accessibilityRole="radio" accessibilityState={{ selected: value === i.id }} onPress={() => onChange(i.id)}
          style={[s.chip, value === i.id && { backgroundColor: t.nuit, borderColor: t.nuit }]}>
          <Text style={{ color: value === i.id ? '#fff' : t.texte, fontWeight: '500' }}>{i.label}</Text>
        </Pressable>
      ))}
    </View>
  );
}
export const card: ViewStyle = { backgroundColor: t.blanc, borderRadius: t.r, borderWidth: 1, borderColor: t.gris, padding: 16 };
export const h1 = { fontSize: 26, fontWeight: '700' as const, color: t.texte };

const s = StyleSheet.create({
  btn: { minHeight: 48, borderRadius: 99, paddingHorizontal: 24, alignItems: 'center', justifyContent: 'center' },
  btnText: { fontWeight: '600', fontSize: 16 },
  tag: { alignSelf: 'flex-start', borderRadius: 99, paddingHorizontal: 10, paddingVertical: 3 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  errTitle: { fontSize: 18, fontWeight: '700', color: t.texte, textAlign: 'center' },
  errText: { marginTop: 8, color: t.doux, textAlign: 'center', lineHeight: 21 },
  banner: { backgroundColor: t.errBg, padding: 12, borderRadius: 12, marginBottom: 12 },
  line: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 },
  lineT: { color: t.doux, fontSize: 15 },
  chip: { minHeight: 44, paddingHorizontal: 16, borderRadius: 99, borderWidth: 1.5, borderColor: t.gris, backgroundColor: '#fff', justifyContent: 'center' },
});
