import { useCallback, useRef, useState } from 'react';
import { useFocusEffect } from 'expo-router';

// Charge des données à chaque retour sur l'écran ; conserve les dernières données affichées si un rechargement échoue.
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[] = []) {
  const [state, set] = useState<{ data: T | null; error: unknown; loading: boolean }>({ data: null, error: null, loading: true });
  const seq = useRef(0);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const run = useCallback(async () => {
    const id = ++seq.current;
    set((s) => ({ ...s, loading: true, error: null }));
    try { const data = await fn(); if (id === seq.current) set({ data, error: null, loading: false }); }
    catch (error) { if (id === seq.current) set((s) => ({ data: s.data, error, loading: false })); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useFocusEffect(useCallback(() => { void run(); }, [run]));
  return { ...state, reload: run };
}
