import React from 'react';
import Svg, { Circle, Defs, Ellipse, LinearGradient, Path, Stop } from 'react-native-svg';
import type { Vehicle } from './types';

// Silhouettes dessinées (aucune photo en v1) : mêmes formes que le site.
const SHAPES: Record<Vehicle['bodyType'], [string, string]> = {
  cit: ['M30 116 L36 86 Q44 76 84 72 L112 46 Q124 40 160 40 L236 40 Q262 42 280 70 L332 76 Q368 82 372 106 L372 120 L30 120Z', 'M96 72 L118 50 Q126 44 160 44 L234 44 Q256 46 270 70Z'],
  ber: ['M20 112 L30 92 Q40 84 80 80 L120 56 Q135 48 170 48 L240 48 Q265 50 285 72 L330 80 Q372 86 380 108 L382 120 L20 120Z', 'M92 80 L124 58 Q136 52 168 52 L238 52 Q258 54 274 74Z'],
  suv: ['M18 116 L26 84 Q34 74 70 72 L100 44 Q112 38 150 38 L270 38 Q292 40 306 66 L346 72 Q380 78 384 104 L384 120 L18 120Z', 'M84 72 L106 48 Q114 42 150 42 L268 42 Q286 44 298 68Z'],
  spo: ['M16 116 L24 98 Q50 90 100 84 L150 62 Q175 54 215 54 L255 56 Q290 70 310 82 L366 92 Q386 100 386 112 L386 120 L16 120Z', 'M112 84 L152 66 Q176 58 214 58 L252 60 Q278 70 296 82Z'],
};
export function CarArt({ body, color, label }: { body: Vehicle['bodyType']; color: string; label: string }) {
  const [shell, glass] = SHAPES[body] ?? SHAPES.cit;
  const id = 'g' + color.replace('#', '');
  return (
    <Svg viewBox="0 0 400 160" width="100%" height={150} accessibilityRole="image" accessibilityLabel={label}>
      <Defs><LinearGradient id={id} x1="0" y1="0" x2="0" y2="1"><Stop offset="0" stopColor={color} /><Stop offset="1" stopColor={color} stopOpacity={0.72} /></LinearGradient></Defs>
      <Ellipse cx={200} cy={146} rx={170} ry={9} fill="#000" opacity={0.2} />
      <Path d={shell} fill={`url(#${id})`} />
      <Path d={glass} fill="#0d1b2e" opacity={0.82} />
      {[96, 312].map((x) => (<React.Fragment key={x}><Circle cx={x} cy={122} r={25} fill="#111820" /><Circle cx={x} cy={122} r={11} fill="#cfd5dc" /></React.Fragment>))}
    </Svg>
  );
}
