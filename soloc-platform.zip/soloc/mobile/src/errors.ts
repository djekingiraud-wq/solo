export type ApiErrorKind = 'network' | 'timeout' | 'unauthorized' | 'forbidden' | 'notfound' | 'conflict' | 'validation' | 'ratelimited' | 'server' | 'unknown';

export class ApiError extends Error {
  kind: ApiErrorKind;
  status: number;
  code: string | undefined;
  constructor(kind: ApiErrorKind, message: string, status = 0, code?: string) {
    super(message);
    this.name = 'ApiError';
    this.kind = kind; this.status = status; this.code = code;
  }
}

export const isNetwork = (e: unknown): boolean => e instanceof ApiError && (e.kind === 'network' || e.kind === 'timeout');
export const isKind = (e: unknown, k: ApiErrorKind): boolean => e instanceof ApiError && e.kind === k;

// Message affichable à l'utilisateur : actionnable, sans jargon technique.
export function describeError(e: unknown): string {
  if (e instanceof ApiError) {
    if (e.kind === 'network') return 'Connexion impossible. Vérifiez votre réseau, puis réessayez.';
    if (e.kind === 'timeout') return 'Le serveur met trop de temps à répondre. Réessayez dans un instant.';
    if (e.kind === 'server') return 'Le service est momentanément indisponible. Réessayez dans un instant.';
    if (e.kind === 'ratelimited') return e.message || 'Trop de tentatives. Patientez quelques minutes.';
    return e.message || 'Une erreur est survenue.';
  }
  return 'Une erreur est survenue.';
}

export function kindFromStatus(status: number): ApiErrorKind {
  if (status === 401) return 'unauthorized';
  if (status === 403) return 'forbidden';
  if (status === 404) return 'notfound';
  if (status === 409) return 'conflict';
  if (status === 429) return 'ratelimited';
  if (status >= 500) return 'server';
  if (status >= 400) return 'validation';
  return 'unknown';
}
