import React, { useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { fmtDay } from './dates';
import { theme as t } from './theme';

export function DateField({ label, value, onChange, minimumDate }: { label: string; value: Date; onChange: (d: Date) => void; minimumDate?: Date }) {
  const [open, setOpen] = useState(false);
  return (
    <View style={{ flex: 1 }}>
      <Text style={s.label}>{label}</Text>
      {Platform.OS === 'ios' ? (
        <DateTimePicker value={value} mode="date" display="compact" minimumDate={minimumDate} locale="fr-FR" onChange={(_, d) => { if (d) onChange(d); }} />
      ) : (
        <>
          <Pressable accessibilityRole="button" accessibilityLabel={`${label} : ${fmtDay(value)}. Modifier`} onPress={() => setOpen(true)} style={s.field}>
            <Text style={{ color: t.texte, fontSize: 16 }}>{fmtDay(value)}</Text>
          </Pressable>
          {open ? <DateTimePicker value={value} mode="date" minimumDate={minimumDate} onChange={(e, d) => { setOpen(false); if (e.type === 'set' && d) onChange(d); }} /> : null}
        </>
      )}
    </View>
  );
}
const s = StyleSheet.create({
  label: { fontSize: 13, fontWeight: '600', color: t.doux, marginBottom: 6 },
  field: { minHeight: 48, borderRadius: 12, borderWidth: 1.5, borderColor: t.gris, backgroundColor: '#fff', justifyContent: 'center', paddingHorizontal: 12 },
});
