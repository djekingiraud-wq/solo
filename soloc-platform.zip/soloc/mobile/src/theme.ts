export const theme = {
  nuit: '#0d1b2e', nuit2: '#16283f', ivoire: '#f6f5f1', gris: '#e3e2dc', texte: '#1b2430', doux: '#5d6775', safran: '#e9a23b',
  ok: '#14653f', okBg: '#dcf2e7', warn: '#82560e', warnBg: '#fbecd0', err: '#8e271c', errBg: '#f8dcd8', neutralBg: '#e6e9ee', neutral: '#3b4654', blanc: '#ffffff',
  r: 14, space: (n: number) => n * 4,
};
