import type { BookingStatus, IncidentCategory, Severity } from './types.ts';

export function eur(cents: number): string {
  const neg = cents < 0, abs = Math.abs(Math.round(cents));
  const whole = String(Math.floor(abs / 100)).replace(/\B(?=(\d{3})+(?!\d))/g, '\u202f');
  const dec = String(abs % 100).padStart(2, '0');
  return `${neg ? '−' : ''}${whole}${dec === '00' ? '' : ',' + dec}\u00a0€`;
}
export const STATUS_LABEL: Record<BookingStatus, string> = {
  pending: 'À confirmer', confirmed: 'Confirmée', active: 'En cours', completed: 'Terminée', cancelled: 'Annulée', refused: 'Refusée', expired: 'Expirée',
};
export type Tone = 'ok' | 'warn' | 'err' | 'neutral';
export const STATUS_TONE: Record<BookingStatus, Tone> = {
  pending: 'warn', confirmed: 'neutral', active: 'ok', completed: 'neutral', cancelled: 'err', refused: 'err', expired: 'err',
};
export const CATEGORY_LABEL: Record<IncidentCategory, string> = { damage: 'Dommage', cleaning: 'Nettoyage', maintenance: 'Entretien', delay: 'Retard', other: 'Autre' };
export const SEVERITY_LABEL: Record<Severity, string> = { low: 'Faible', medium: 'Moyenne', high: 'Élevée' };

// Saisie d'un entier : tolère espaces et virgule, refuse tout le reste.
export function parseIntStrict(s: string): number | null {
  const t = s.replace(/\s/g, '');
  return /^\d{1,7}$/.test(t) ? Number(t) : null;
}
