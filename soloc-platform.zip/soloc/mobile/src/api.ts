import { ApiError, kindFromStatus } from './errors.ts';

export interface ApiConfig {
  baseUrl: string;
  getToken: () => string | null;
  onUnauthorized?: () => void;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
}

export function createApi(cfg: ApiConfig) {
  const doFetch = cfg.fetchImpl ?? fetch;
  const timeoutMs = cfg.timeoutMs ?? 15000;

  async function once(method: string, path: string, body?: unknown): Promise<any> {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    const token = cfg.getToken();
    let res: Response;
    try {
      res = await doFetch(cfg.baseUrl + path, {
        method,
        signal: ctrl.signal,
        headers: { 'content-type': 'application/json', 'x-soloc-client': 'mobile', ...(token ? { authorization: `Bearer ${token}` } : {}) },
        body: body === undefined ? undefined : JSON.stringify(body),
      });
    } catch (e: any) {
      if (e?.name === 'AbortError') throw new ApiError('timeout', '');
      throw new ApiError('network', '');
    } finally {
      clearTimeout(timer);
    }
    let data: any = null;
    try { data = await res.json(); } catch { /* corps vide ou non JSON */ }
    if (res.ok) return data;
    if (res.status === 401 && token) cfg.onUnauthorized?.();
    throw new ApiError(kindFromStatus(res.status), data?.message ?? '', res.status, data?.error);
  }

  // Les lectures (GET) sont rejouées une fois en cas de coupure réseau ; les écritures jamais
  // (un POST rejoué pourrait créer une réservation en double).
  async function request(method: string, path: string, body?: unknown): Promise<any> {
    try {
      return await once(method, path, body);
    } catch (e) {
      if (method === 'GET' && e instanceof ApiError && (e.kind === 'network' || e.kind === 'timeout')) {
        await new Promise((r) => setTimeout(r, 400));
        return once(method, path, body);
      }
      throw e;
    }
  }

  return {
    get: (p: string) => request('GET', p),
    post: (p: string, b?: unknown) => request('POST', p, b ?? {}),
    patch: (p: string, b: unknown) => request('PATCH', p, b),
  };
}
export type Api = ReturnType<typeof createApi>;
