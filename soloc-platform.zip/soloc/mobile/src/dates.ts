export const startOfToday = (): Date => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
export const addDays = (d: Date, n: number): Date => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
// Les dates choisies sont envoyées au serveur à 10 h (heure locale), comme sur le site web.
export const atTen = (d: Date): string => { const x = new Date(d); x.setHours(10, 0, 0, 0); return x.toISOString(); };
export const validRange = (from: Date, to: Date): boolean => to.getTime() > from.getTime();
export const sameDay = (a: Date | string, b: Date | string): boolean => new Date(a).toDateString() === new Date(b).toDateString();
export const endOfToday = (): Date => { const d = new Date(); d.setHours(23, 59, 59, 999); return d; };
const J = ['dim.', 'lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.'], M = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
// Format maison (sans dépendre du support Intl du moteur JS) : "jeu. 15 oct."
export const fmtDay = (d: Date | string): string => { const x = new Date(d); return `${J[x.getDay()]} ${x.getDate()} ${M[x.getMonth()]}`; };
export const fmtRange = (a: string, b: string): string => `${fmtDay(a)} → ${fmtDay(b)}`;
