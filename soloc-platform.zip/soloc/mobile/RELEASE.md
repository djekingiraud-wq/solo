# SOLOC Mobile — versions de test et publication sur les stores

**Aucun build n'a été généré et aucune soumission n'a été faite** : ce guide n'a pas été exécuté (pas d'accès réseau ni de comptes ici). Les règles des stores ci-dessous ont été relevées le 11 octobre 2026 ; **elles changent chaque année : relisez les pages officielles le jour de la publication.**

## 0. Avant tout build
1. Le backend de production (HTTPS) doit être en ligne : l'app n'a pas de mode hors ligne et les builds distribués refusent le HTTP en clair.
2. Renseigner dans `eas.json` : `EXPO_PUBLIC_API_URL` (https, sans `/` final) pour `preview` (préproduction) et `production`.
3. Remplacer les identifiants provisoires `com.soloc.app` (`app.json`, iOS `bundleIdentifier` et Android `package`) par ceux de votre organisation **avant la première publication** : ils ne se changent plus ensuite.
4. `npm run check:release -- production` (ou `preview`) : refuse HTTP, adresses locales/d'exemple, identifiants provisoires, `ascAppId` manquant. Ce contrôle vérifie la configuration, pas le fonctionnement.
5. `npx expo install --fix`, `npx tsc --noEmit`, `npm test`.
6. **Android — niveau d'API cible** : Google Play exige depuis le 31 août 2026 que les nouvelles applications et mises à jour ciblent Android 16 (API 36) ou plus. Vérifiez dans le build que `targetSdkVersion` vaut 36 ; au besoin ajoutez `"plugins": [..., ["expo-build-properties", { "android": { "compileSdkVersion": 36, "targetSdkVersion": 36 } }]]` (paquet `npx expo install expo-build-properties`) puis testez sur un appareil ou émulateur Android 16.
7. **iOS — Xcode** : depuis le 28 avril 2026, les builds envoyés à App Store Connect doivent être faits avec Xcode 26 / SDK iOS 26. Selon Expo, les projets en SDK 54 ou 55 l'utilisent par défaut sur EAS Build ; confirmez dans les journaux du build.

## 1. Outils et comptes
- Compte Expo (gratuit pour démarrer) ; `npm install -g eas-cli` ; `eas login` ; `eas init` (crée le projet EAS).
- **Apple Developer Program** (environ 99 $/an, authentification à deux facteurs obligatoire) — requis pour TestFlight et l'App Store, et pour tout build installable sur iPhone hors Expo Go.
- **Google Play Console** (frais d'inscription uniques). Compte **personnel** créé après le 13 novembre 2023 : un test fermé avec **au moins 12 testeurs inscrits pendant 14 jours consécutifs** est obligatoire avant de demander l'accès à la production (règle officielle Google). Les comptes **organisation** en seraient exemptés d'après des sources secondaires : à confirmer auprès de Google. Prévoyez environ trois semaines pour une première publication.

## 2. Versions de test
| Cible | Commande | Distribution |
|---|---|---|
| Développement (client de dev, API locale) | `eas build --profile development --platform android\|ios` | interne ; iOS : appareils enregistrés |
| Android — test interne rapide | `eas build --profile preview --platform android` | **APK** installable par lien ou fichier |
| iOS — test interne | `eas device:create` (enregistrer chaque iPhone) puis `eas build --profile preview --platform ios` | ad hoc, appareils enregistrés seulement |
| iOS — TestFlight | build `production` + `eas submit --platform ios` | testeurs internes d'abord ; testeurs externes après une revue bêta Apple (vérifier les limites dans App Store Connect) |
| Android — Play (test interne) | build `production` (AAB) + `eas submit --platform android` (piste `internal`, brouillon) | jusqu'à 100 testeurs d'après des sources secondaires ; ne compte **pas** pour la règle des 12 testeurs |
La toute première version d'une app Android doit généralement être créée et envoyée **à la main** dans la Play Console avant que `eas submit` fonctionne (à vérifier dans la documentation EAS). Les profils de `eas.json` sont des **exemples non testés**.

## 3. Publication
**Android** : créer l'application dans la Play Console ; signature Play App Signing (clé d'envoi gérée par EAS) ; fiche (description, captures, icône 512×512, bannière) ; classification du contenu ; public cible ; formulaire **Sécurité des données** (voir `../docs/DONNEES-PERSONNELLES.md`) ; URL de politique de confidentialité ; test fermé 12 × 14 jours si compte personnel ; demande d'accès à la production ; déploiement progressif conseillé.
**iOS** : créer l'app dans App Store Connect (`ascAppId` → `eas.json`) ; **URL de politique de confidentialité** et questionnaire **App Privacy** obligatoires ; questionnaire de classification d'âge (mis à jour en 2026) ; captures pour les tailles d'écran exigées ; déclaration de chiffrement (`usesNonExemptEncryption: false` déjà posé : l'app n'utilise que HTTPS standard — à confirmer par SOLOC) ; **identifiants de démonstration** dans les notes de revue : créer en production un compte client dédié aux relecteurs avec une réservation confirmée (sinon rejet probable) ; faire relire la guideline 5.1.1 (collecte de données) et 3.1.1 (paiement : la location d'un bien physique via Stripe est en principe hors achat intégré — **à confirmer à la lecture des règles Apple du jour**).
**Les deux** : la politique de confidentialité et les CGL **n'existent pas encore** dans le produit (voir `../docs/READINESS.md`) : bloquant.

## 4. Versions et mises à jour
`appVersionSource: remote` + `autoIncrement: true` : EAS incrémente `buildNumber` / `versionCode`. `version` (X.Y.Z) se change dans `app.json`. Les mises à jour à distance (`expo-updates`) ne sont **pas** installées : tout changement passe par une nouvelle soumission. Compatibilité API : ne supprimez une route que lorsque plus aucune version publiée n'en dépend.

## 5. Ce qui n'est pas prêt
Notifications push (non implémentées) ; photos d'états des lieux ; mode hors ligne ; liens profonds et retour automatique vers l'app après un paiement (le paiement s'ouvre dans le navigateur) ; polices de marque ; écrans non testés sur appareil.
