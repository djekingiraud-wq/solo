import React, { useState } from 'react';
import { ScrollView, Text, TextInput, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { services } from '../../src/client';
import { useAsync } from '../../src/useAsync';
import { Button, Chips, ErrorState, Loading } from '../../src/ui';
import { describeError } from '../../src/errors';
import { CATEGORY_LABEL, SEVERITY_LABEL } from '../../src/format';
import { theme as t } from '../../src/theme';
import type { IncidentCategory, Severity } from '../../src/types';

const cats = (Object.keys(CATEGORY_LABEL) as IncidentCategory[]).map((id) => ({ id, label: CATEGORY_LABEL[id] }));
const sevs = (Object.keys(SEVERITY_LABEL) as Severity[]).map((id) => ({ id, label: SEVERITY_LABEL[id] }));

export default function NewIncident() {
  const router = useRouter();
  const p = useLocalSearchParams<{ vehicleId?: string; ref?: string }>();
  const [vehicleId, setVehicleId] = useState<string | null>(p.vehicleId ? String(p.vehicleId) : null);
  const [category, setCategory] = useState<IncidentCategory | null>(null);
  const [severity, setSeverity] = useState<Severity | null>('low');
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const vehicles = useAsync(() => services.vehicles(), []);

  async function submit() {
    if (!vehicleId) return setMsg('Choisissez le véhicule concerné.');
    if (!category) return setMsg('Choisissez le type de signalement.');
    if (!severity) return setMsg('Choisissez la gravité.');
    if (text.trim().length < 3) return setMsg('Décrivez brièvement ce qui s\'est passé.');
    setBusy(true); setMsg(null);
    try { await services.createIncident({ vehicleId, bookingRef: p.ref ? String(p.ref) : undefined, category, severity, description: text.trim() }); router.back(); }
    catch (e) { setMsg(describeError(e)); } finally { setBusy(false); }
  }
  if (vehicles.loading && !vehicles.data && !vehicles.error) return <Loading />;
  if (vehicles.error && !vehicles.data) return <ErrorState error={vehicles.error} onRetry={vehicles.reload} />;
  const lab = { fontWeight: '700' as const, color: t.texte, marginBottom: 8 };
  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 18 }} keyboardShouldPersistTaps="handled">
      <View><Text style={lab}>Véhicule</Text><Chips label="Véhicule" value={vehicleId} onChange={setVehicleId} items={(vehicles.data ?? []).map((v) => ({ id: v.id, label: v.name }))} /></View>
      <View><Text style={lab}>Type</Text><Chips label="Type de signalement" value={category} onChange={setCategory} items={cats} /></View>
      <View><Text style={lab}>Gravité</Text><Chips label="Gravité" value={severity} onChange={setSeverity} items={sevs} /></View>
      <View><Text style={lab}>Description</Text>
        <TextInput accessibilityLabel="Description" multiline value={text} onChangeText={setText} placeholder="Ex. rayure sur l'aile avant droite" maxLength={1000}
          style={{ minHeight: 110, borderWidth: 1.5, borderColor: t.gris, borderRadius: 12, padding: 12, backgroundColor: '#fff', fontSize: 16, textAlignVertical: 'top' }} />
        <Text style={{ color: t.doux, fontSize: 12, marginTop: 6 }}>Les photos ne sont pas encore prises en charge.</Text></View>
      {msg ? <View accessibilityRole="alert" style={{ backgroundColor: t.errBg, padding: 12, borderRadius: 12 }}><Text style={{ color: t.err }}>{msg}</Text></View> : null}
      <Button title="Envoyer le signalement" onPress={submit} loading={busy} />
    </ScrollView>
  );
}
