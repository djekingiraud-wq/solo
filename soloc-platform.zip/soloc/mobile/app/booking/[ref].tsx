import React, { useState } from 'react';
import { Alert, Linking, ScrollView, Text, TextInput, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { services } from '../../src/client';
import { useAsync } from '../../src/useAsync';
import { useSession } from '../../src/session';
import { Button, ErrorBanner, ErrorState, Line, Loading, Tag, card } from '../../src/ui';
import { describeError } from '../../src/errors';
import { STATUS_LABEL, STATUS_TONE, eur, parseIntStrict } from '../../src/format';
import { fmtRange } from '../../src/dates';
import { theme as t } from '../../src/theme';

export default function BookingScreen() {
  const router = useRouter();
  const { user } = useSession();
  const { ref, created } = useLocalSearchParams<{ ref: string; created?: string }>();
  const { data: b, error, loading, reload } = useAsync(() => services.booking(String(ref)), [ref]);
  const cfg = useAsync(() => services.config().catch(() => ({ onlinePayment: false })), []);
  const [km, setKm] = useState('');
  const [fuel, setFuel] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  if (loading && !b && !error) return <Loading />;
  if (error && !b) return <ErrorState error={error} onRetry={reload} />;
  if (!b) return null;
  const staff = !!user && user.role !== 'client', admin = user?.role === 'admin';

  async function run(fn: () => Promise<unknown>) {
    setBusy(true); setMsg(null);
    try { await fn(); await reload(); } catch (e) { setMsg(describeError(e)); } finally { setBusy(false); }
  }
  function ask(title: string, text: string, confirmLabel: string, fn: () => Promise<unknown>) {
    Alert.alert(title, text, [{ text: 'Non', style: 'cancel' }, { text: confirmLabel, style: 'destructive', onPress: () => void run(fn) }]);
  }
  // Le paiement s'effectue sur la page sécurisée du prestataire (navigateur) ; la réservation n'est marquée payée que par le serveur, après confirmation du prestataire.
  function payOnline() { void run(async () => { const { url } = await services.checkout(b!.ref); await Linking.openURL(url); }); }
  function submitOps(kind: 'pickup' | 'return') {
    const k = parseIntStrict(km), f = parseIntStrict(fuel);
    if (k === null) return setMsg('Saisissez le kilométrage (nombre entier).');
    if (f === null || f > 100) return setMsg('Saisissez le niveau de carburant ou de charge (0 à 100).');
    void run(() => (kind === 'pickup' ? services.pickup(b!.ref, k, f) : services.giveBack(b!.ref, k, f)).then(() => { setKm(''); setFuel(''); }));
  }
  const input = { minHeight: 48, borderWidth: 1.5, borderColor: t.gris, borderRadius: 12, paddingHorizontal: 12, backgroundColor: '#fff', fontSize: 16, color: t.texte } as const;

  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }} keyboardShouldPersistTaps="handled">
      {created ? <View style={{ backgroundColor: t.okBg, padding: 12, borderRadius: 12 }}><Text style={{ color: t.ok, fontWeight: '600' }}>Demande envoyée. Elle sera validée par l'agence. Aucun paiement n'a été prélevé.</Text></View> : null}
      {error ? <ErrorBanner error={error} onRetry={reload} /> : null}
      <View style={[card, { gap: 6 }]}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><Text style={{ fontSize: 20, fontWeight: '700' }}>{b.ref}</Text><Tag label={STATUS_LABEL[b.status]} tone={STATUS_TONE[b.status]} /></View>
        <Text style={{ fontSize: 16, color: t.texte }}>{b.vehicleName}</Text>
        <Text style={{ color: t.doux }}>{fmtRange(b.start, b.end)}</Text>
        {staff && b.client ? <Text style={{ color: t.texte }}>Client : {b.client}{b.clientEmail ? ` · ${b.clientEmail}` : ''}</Text> : null}
        {b.status === 'pending' && b.expiresAt ? <Text style={{ color: t.warn }}>Demande retenue jusqu'au {new Date(b.expiresAt).toLocaleString('fr-FR')}</Text> : null}
      </View>
      <View style={card}>
        <Text style={{ fontWeight: '700', marginBottom: 6 }}>Montants</Text>
        <Line label={`${b.days} jour${b.days > 1 ? 's' : ''}`} value={eur(b.baseCents)} />
        {b.optionsCents ? <Line label="Options" value={eur(b.optionsCents)} /> : null}
        {b.discountCents ? <Line label="Remise" value={`−${eur(b.discountCents)}`} /> : null}
        <Line label="dont TVA 20 %" value={eur(b.vatCents)} />
        <Line label="Total TTC" value={eur(b.totalCents)} bold />
        <Line label="Déjà réglé" value={eur(b.paidCents)} />
        <Line label="Dépôt de garantie" value={eur(b.depositCents)} />
      </View>
      {msg ? <View accessibilityRole="alert" style={{ backgroundColor: t.errBg, padding: 12, borderRadius: 12 }}><Text style={{ color: t.err }}>{msg}</Text></View> : null}

      {staff && (b.status === 'confirmed' || b.status === 'active') ? (
        <View style={[card, { gap: 10 }]}>
          <Text style={{ fontWeight: '700' }}>{b.status === 'confirmed' ? 'Remise des clés' : 'Retour du véhicule'}</Text>
          <TextInput accessibilityLabel="Kilométrage" style={input} placeholder="Kilométrage au compteur" keyboardType="number-pad" value={km} onChangeText={setKm} />
          <TextInput accessibilityLabel="Carburant ou charge en pourcentage" style={input} placeholder="Carburant / charge (0 à 100 %)" keyboardType="number-pad" value={fuel} onChangeText={setFuel} />
          <Button title={b.status === 'confirmed' ? 'Enregistrer la remise' : 'Enregistrer le retour'} loading={busy} onPress={() => submitOps(b.status === 'confirmed' ? 'pickup' : 'return')} />
        </View>
      ) : null}
      {admin && b.status === 'pending' ? (
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Button style={{ flex: 1 }} title="Confirmer" loading={busy} onPress={() => void run(() => services.confirm(b.ref))} />
          <Button style={{ flex: 1 }} kind="danger" title="Refuser" disabled={busy} onPress={() => ask('Refuser la demande ?', 'Le client sera informé du refus.', 'Refuser', () => services.refuse(b.ref))} />
        </View>
      ) : null}
      {!staff && b.status === 'confirmed' && b.totalCents - b.paidCents > 0 && cfg.data?.onlinePayment ? <Button title={`Payer ${eur(b.totalCents - b.paidCents)} en ligne`} loading={busy} onPress={payOnline} /> : null}
      {staff ? <Button kind="secondary" title="Signaler un incident" onPress={() => router.push({ pathname: '/incident/new', params: { vehicleId: b.vehicleId, ref: b.ref } })} /> : null}
      {(b.status === 'pending' || b.status === 'confirmed') && (!staff || admin) ? (
        <Button kind="danger" title="Annuler la réservation" disabled={busy} onPress={() => ask('Annuler cette réservation ?', 'Cette action est définitive.', "Oui, annuler", () => services.cancel(b.ref))} />
      ) : null}
    </ScrollView>
  );
}
