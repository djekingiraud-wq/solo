import React from 'react';
import { FlatList, RefreshControl, Text, View } from 'react-native';
import { Redirect, useRouter } from 'expo-router';
import { services } from '../../src/client';
import { useAsync } from '../../src/useAsync';
import { useSession } from '../../src/session';
import { Button, Empty, ErrorBanner, ErrorState, Loading, Tag, card } from '../../src/ui';
import { CATEGORY_LABEL, SEVERITY_LABEL } from '../../src/format';
import { fmtDay } from '../../src/dates';
import { theme as t } from '../../src/theme';

export default function Incidents() {
  const router = useRouter();
  const { user } = useSession();
  const staff = !!user && user.role !== 'client';
  const { data, error, loading, reload } = useAsync(() => (staff ? services.incidents() : Promise.resolve([])), [user?.id]);
  if (!user) return <Empty title="Incidents" text="Connectez-vous avec votre compte employé." action={<Button title="Se connecter" onPress={() => router.push('/login')} />} />;
  if (!staff) return <Redirect href="/" />;
  return (
    <FlatList
      data={data ?? []}
      keyExtractor={(i) => String(i.id)}
      contentContainerStyle={{ padding: 16, gap: 12, flexGrow: 1 }}
      refreshControl={<RefreshControl refreshing={loading && !!data} onRefresh={reload} />}
      ListHeaderComponent={<View style={{ gap: 12, marginBottom: 4 }}><Button title="Signaler un incident" onPress={() => router.push('/incident/new')} />{error && data ? <ErrorBanner error={error} onRetry={reload} /> : null}</View>}
      ListEmptyComponent={loading && !data ? <Loading /> : error && !data ? <ErrorState error={error} onRetry={reload} /> : <Empty title="Aucun incident" text="Les signalements de l'équipe apparaîtront ici." />}
      renderItem={({ item: i }) => (
        <View style={[card, { gap: 6 }]}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><Text style={{ fontWeight: '700', fontSize: 16 }}>{i.vehicleName}</Text><Tag label={`${CATEGORY_LABEL[i.category]} · ${SEVERITY_LABEL[i.severity]}`} tone={i.severity === 'high' ? 'err' : i.severity === 'medium' ? 'warn' : 'neutral'} /></View>
          <Text style={{ color: t.texte }}>{i.description}</Text>
          <Text style={{ color: t.doux, fontSize: 13 }}>{fmtDay(i.createdAt)}{i.bookingRef ? ` · ${i.bookingRef}` : ''}{i.author ? ` · ${i.author}` : ''}</Text>
        </View>
      )}
    />
  );
}
