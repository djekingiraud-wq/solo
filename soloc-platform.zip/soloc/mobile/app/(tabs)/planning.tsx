import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, RefreshControl, Text, TextInput, View } from 'react-native';
import { Redirect, useRouter } from 'expo-router';
import { services } from '../../src/client';
import { useAsync } from '../../src/useAsync';
import { useSession } from '../../src/session';
import { Button, Chips, Empty, ErrorBanner, ErrorState, Loading, Tag, card } from '../../src/ui';
import { STATUS_LABEL, STATUS_TONE } from '../../src/format';
import { endOfToday, fmtRange } from '../../src/dates';
import { theme as t } from '../../src/theme';
import type { Booking } from '../../src/types';

type Seg = 'dep' | 'ret' | 'next' | 'req';

export default function Planning() {
  const router = useRouter();
  const { user, offline, refresh } = useSession();
  const staff = !!user && user.role !== 'client';
  const { data, error, loading, reload } = useAsync(() => (staff ? services.bookings() : Promise.resolve([] as Booking[])), [user?.id]);
  const [seg, setSeg] = useState<Seg>('dep');
  const [q, setQ] = useState('');

  const groups = useMemo(() => {
    const all = data ?? [], eod = endOfToday().getTime();
    const g: Record<Seg, Booking[]> = {
      dep: all.filter((b) => b.status === 'confirmed' && new Date(b.start).getTime() <= eod).sort((a, b) => +new Date(a.start) - +new Date(b.start)),
      ret: all.filter((b) => b.status === 'active').sort((a, b) => +new Date(a.end) - +new Date(b.end)),
      next: all.filter((b) => b.status === 'confirmed' && new Date(b.start).getTime() > eod).sort((a, b) => +new Date(a.start) - +new Date(b.start)),
      req: all.filter((b) => b.status === 'pending'),
    };
    return g;
  }, [data]);

  if (!user) return <Empty title="Espace équipe" text={offline ? 'Connexion impossible pour le moment.' : 'Connectez-vous avec votre compte employé.'} action={offline ? <Button title="Réessayer" kind="secondary" onPress={() => void refresh()} /> : <Button title="Se connecter" onPress={() => router.push('/login')} />} />;
  if (!staff) return <Redirect href="/" />;

  const needle = q.trim().toLowerCase();
  const list = groups[seg].filter((b) => !needle || [b.ref, b.client ?? '', b.vehicleName].some((x) => x.toLowerCase().includes(needle)));
  const now = Date.now();
  return (
    <FlatList
      data={list}
      keyExtractor={(b) => b.ref}
      keyboardShouldPersistTaps="handled"
      contentContainerStyle={{ padding: 16, gap: 12, flexGrow: 1 }}
      refreshControl={<RefreshControl refreshing={loading && !!data} onRefresh={reload} />}
      ListHeaderComponent={
        <View style={{ gap: 12 }}>
          <TextInput accessibilityLabel="Rechercher une réservation" placeholder="Référence, client ou véhicule" value={q} onChangeText={setQ} autoCapitalize="none" clearButtonMode="while-editing"
            style={{ minHeight: 48, borderWidth: 1.5, borderColor: t.gris, borderRadius: 12, paddingHorizontal: 12, backgroundColor: '#fff', fontSize: 16 }} />
          <Chips<Seg> label="Filtre du planning" value={seg} onChange={setSeg} items={[
            { id: 'dep', label: `Départs (${groups.dep.length})` }, { id: 'ret', label: `Retours (${groups.ret.length})` },
            { id: 'next', label: `À venir (${groups.next.length})` }, { id: 'req', label: `Demandes (${groups.req.length})` }]} />
          {error && data ? <ErrorBanner error={error} onRetry={reload} /> : null}
        </View>
      }
      ListEmptyComponent={loading && !data ? <Loading /> : error && !data ? <ErrorState error={error} onRetry={reload} /> : <Empty title="Rien à afficher" text={needle ? 'Aucun résultat pour cette recherche.' : 'Aucune réservation dans cette catégorie.'} />}
      renderItem={({ item: b }) => {
        const late = b.status === 'active' && new Date(b.end).getTime() < now;
        return (
          <Pressable accessibilityRole="button" accessibilityLabel={`${b.ref}, ${b.client ?? ''}, ${b.vehicleName}${late ? ', en retard' : ''}`} onPress={() => router.push({ pathname: '/booking/[ref]', params: { ref: b.ref } })} style={({ pressed }) => [card, { gap: 5, opacity: pressed ? 0.85 : 1 }]}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><Text style={{ fontWeight: '700', fontSize: 17 }}>{b.vehicleName}</Text>{late ? <Tag label="En retard" tone="err" /> : <Tag label={STATUS_LABEL[b.status]} tone={STATUS_TONE[b.status]} />}</View>
            <Text style={{ color: t.texte }}>{b.client} · {b.ref}</Text>
            <Text style={{ color: t.doux }}>{fmtRange(b.start, b.end)}</Text>
          </Pressable>
        );
      }}
    />
  );
}
