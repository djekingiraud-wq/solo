import React from 'react';
import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSession } from '../../src/session';
import { theme as t } from '../../src/theme';

const icon = (name: React.ComponentProps<typeof Ionicons>['name']) => ({ color, size }: { color: string; size: number }) => <Ionicons name={name} color={color} size={size} />;

// Navigation par rôle : un client voit le catalogue et ses locations ; le personnel voit le planning et les incidents.
export default function TabsLayout() {
  const { user } = useSession();
  const staff = !!user && user.role !== 'client';
  return (
    <Tabs screenOptions={{ headerStyle: { backgroundColor: t.nuit }, headerTintColor: '#fff', tabBarActiveTintColor: t.nuit, tabBarInactiveTintColor: t.doux, tabBarStyle: { backgroundColor: '#fff' } }}>
      <Tabs.Screen name="index" options={{ title: 'Véhicules', tabBarIcon: icon('car-sport-outline'), href: staff ? null : undefined }} />
      <Tabs.Screen name="trips" options={{ title: 'Mes locations', tabBarIcon: icon('calendar-outline'), href: staff ? null : undefined }} />
      <Tabs.Screen name="planning" options={{ title: 'Planning', tabBarIcon: icon('list-outline'), href: staff ? undefined : null }} />
      <Tabs.Screen name="incidents" options={{ title: 'Incidents', tabBarIcon: icon('warning-outline'), href: staff ? undefined : null }} />
      <Tabs.Screen name="account" options={{ title: 'Compte', tabBarIcon: icon('person-outline') }} />
    </Tabs>
  );
}
