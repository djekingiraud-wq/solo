import React from 'react';
import { FlatList, Pressable, RefreshControl, Text, View } from 'react-native';
import { Redirect, useRouter } from 'expo-router';
import { services } from '../../src/client';
import { useAsync } from '../../src/useAsync';
import { useSession } from '../../src/session';
import { Button, Empty, ErrorBanner, ErrorState, Loading, Tag, card } from '../../src/ui';
import { STATUS_LABEL, STATUS_TONE, eur } from '../../src/format';
import { fmtRange } from '../../src/dates';
import { theme as t } from '../../src/theme';

export default function Trips() {
  const router = useRouter();
  const { user, offline, refresh } = useSession();
  const { data, error, loading, reload } = useAsync(() => (user ? services.bookings() : Promise.resolve([])), [user?.id]);
  if (user && user.role !== 'client') return <Redirect href="/planning" />;
  if (!user) {
    return <Empty title="Vos locations" text={offline ? 'Connexion impossible pour le moment.' : 'Connectez-vous pour retrouver vos réservations.'}
      action={offline ? <Button title="Réessayer" kind="secondary" onPress={() => void refresh()} /> : <Button title="Se connecter" onPress={() => router.push('/login')} />} />;
  }
  return (
    <FlatList
      data={data ?? []}
      keyExtractor={(b) => b.ref}
      contentContainerStyle={{ padding: 16, gap: 12, flexGrow: 1 }}
      refreshControl={<RefreshControl refreshing={loading && !!data} onRefresh={reload} />}
      ListHeaderComponent={error && data ? <ErrorBanner error={error} onRetry={reload} /> : null}
      ListEmptyComponent={loading ? <Loading /> : error ? <ErrorState error={error} onRetry={reload} /> : <Empty title="Aucune location" text="Vos demandes de réservation apparaîtront ici." action={<Button title="Choisir un véhicule" onPress={() => router.push('/')} />} />}
      renderItem={({ item: b }) => (
        <Pressable accessibilityRole="button" accessibilityLabel={`Réservation ${b.ref}, ${b.vehicleName}, ${STATUS_LABEL[b.status]}`} onPress={() => router.push({ pathname: '/booking/[ref]', params: { ref: b.ref } })} style={({ pressed }) => [card, { gap: 6, opacity: pressed ? 0.85 : 1 }]}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><Text style={{ fontWeight: '700', fontSize: 17 }}>{b.vehicleName}</Text><Tag label={STATUS_LABEL[b.status]} tone={STATUS_TONE[b.status]} /></View>
          <Text style={{ color: t.doux }}>{fmtRange(b.start, b.end)}</Text>
          <Text style={{ color: t.texte, fontWeight: '600' }}>{eur(b.totalCents)} · {b.ref}</Text>
        </Pressable>
      )}
    />
  );
}
