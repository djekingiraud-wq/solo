import React from 'react';
import { Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useSession } from '../../src/session';
import { Button, card } from '../../src/ui';
import { theme as t } from '../../src/theme';

const ROLE = { client: 'Client', employee: 'Employé', admin: 'Administrateur' } as const;
export default function Account() {
  const router = useRouter();
  const { user, offline, refresh, logout } = useSession();
  return (
    <View style={{ padding: 16, gap: 14 }}>
      {offline ? <View accessibilityRole="alert" style={{ backgroundColor: t.warnBg, padding: 12, borderRadius: 12 }}><Text style={{ color: t.warn }}>Hors connexion : impossible de vérifier votre session.</Text><Button title="Réessayer" kind="secondary" onPress={() => void refresh()} style={{ marginTop: 10 }} /></View> : null}
      {user ? (
        <>
          <View style={[card, { gap: 4 }]}>
            <Text style={{ fontSize: 22, fontWeight: '700', color: t.texte }}>{user.firstName} {user.lastName}</Text>
            <Text style={{ color: t.doux }}>{user.email}</Text>
            <Text style={{ color: t.doux }}>{ROLE[user.role]}</Text>
          </View>
          <Button title="Se déconnecter" kind="secondary" onPress={() => void logout()} />
        </>
      ) : (
        <View style={[card, { gap: 12 }]}>
          <Text style={{ fontSize: 20, fontWeight: '700', color: t.texte }}>Votre compte SOLOC</Text>
          <Text style={{ color: t.doux }}>Connectez-vous pour réserver et suivre vos locations.</Text>
          <Button title="Se connecter ou créer un compte" onPress={() => router.push('/login')} />
        </View>
      )}
    </View>
  );
}
