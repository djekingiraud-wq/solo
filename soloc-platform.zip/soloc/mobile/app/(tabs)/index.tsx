import React, { useState } from 'react';
import { FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { Redirect, useRouter } from 'expo-router';
import { services } from '../../src/client';
import { useAsync } from '../../src/useAsync';
import { useSession } from '../../src/session';
import { addDays, atTen, fmtDay, startOfToday, validRange } from '../../src/dates';
import { DateField } from '../../src/DateField';
import { CarArt } from '../../src/CarArt';
import { Empty, ErrorBanner, ErrorState, Loading, Tag, card } from '../../src/ui';
import { eur } from '../../src/format';
import { theme as t } from '../../src/theme';
import type { Vehicle } from '../../src/types';

export default function Catalogue() {
  const router = useRouter();
  const { user } = useSession();
  const [from, setFrom] = useState(() => addDays(startOfToday(), 3));
  const [to, setTo] = useState(() => addDays(startOfToday(), 6));
  const ok = validRange(from, to);
  const { data, error, loading, reload } = useAsync(() => (ok ? services.vehicles(atTen(from), atTen(to)) : Promise.resolve([] as Vehicle[])), [from.getTime(), to.getTime()]);
  if (user && user.role !== 'client') return <Redirect href="/planning" />;

  const sorted = [...(data ?? [])].sort((a, b) => Number(b.available) - Number(a.available) || a.dailyPriceCents - b.dailyPriceCents);
  return (
    <FlatList
      data={ok ? sorted : []}
      keyExtractor={(v) => v.id}
      contentContainerStyle={{ padding: 16, gap: 14, flexGrow: 1 }}
      refreshControl={<RefreshControl refreshing={loading && !!data} onRefresh={reload} />}
      ListHeaderComponent={
        <View style={{ gap: 12 }}>
          <View style={[card, { flexDirection: 'row', gap: 12 }]}>
            <DateField label="Départ" value={from} minimumDate={startOfToday()} onChange={(d) => { setFrom(d); if (!validRange(d, to)) setTo(addDays(d, 1)); }} />
            <DateField label="Retour" value={to} minimumDate={addDays(from, 1)} onChange={setTo} />
          </View>
          {!ok ? <Text style={{ color: t.err }}>Le retour doit être après le départ.</Text> : null}
          {error && data ? <ErrorBanner error={error} onRetry={reload} /> : null}
        </View>
      }
      ListEmptyComponent={loading ? <Loading /> : error ? <ErrorState error={error} onRetry={reload} /> : <Empty title="Aucun véhicule" text="Aucun véhicule n'est proposé pour le moment." />}
      renderItem={({ item: v }) => (
        <Pressable accessibilityRole="button" accessibilityLabel={`${v.name}, ${eur(v.dailyPriceCents)} par jour, ${v.available ? 'disponible' : 'indisponible'} du ${fmtDay(from)} au ${fmtDay(to)}`}
          onPress={() => router.push({ pathname: '/vehicle/[id]', params: { id: v.id, from: from.toISOString(), to: to.toISOString() } })}
          style={({ pressed }) => [card, { padding: 0, overflow: 'hidden', opacity: pressed ? 0.85 : v.available ? 1 : 0.7 }]}>
          <View style={{ backgroundColor: '#e4e7eb', paddingTop: 10 }}><CarArt body={v.bodyType} color={v.color} label={v.name} /></View>
          <View style={{ padding: 14, gap: 6 }}>
            <View style={s.row}><Text style={s.name}>{v.name}</Text><Tag label={v.available ? 'Disponible' : 'Indisponible'} tone={v.available ? 'ok' : 'err'} /></View>
            <Text style={{ color: t.doux }}>{v.category} · {v.seats} places · {v.fuel} · {v.transmission}</Text>
            <Text style={s.price}>{eur(v.dailyPriceCents)} <Text style={{ fontSize: 13, fontWeight: '400', color: t.doux }}>/ jour TTC</Text></Text>
          </View>
        </Pressable>
      )}
    />
  );
}
const s = StyleSheet.create({ row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, name: { fontSize: 18, fontWeight: '700', color: t.texte }, price: { fontSize: 20, fontWeight: '700', color: t.texte } });
