import React, { useState } from 'react';
import { ScrollView, Switch, Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { services } from '../../src/client';
import { useAsync } from '../../src/useAsync';
import { useSession } from '../../src/session';
import { addDays, atTen, startOfToday, validRange } from '../../src/dates';
import { DateField } from '../../src/DateField';
import { CarArt } from '../../src/CarArt';
import { Button, ErrorBanner, ErrorState, Line, Loading, Tag, card } from '../../src/ui';
import { describeError, isKind, isNetwork } from '../../src/errors';
import { eur } from '../../src/format';
import { theme as t } from '../../src/theme';

export default function VehicleScreen() {
  const router = useRouter();
  const { user } = useSession();
  const p = useLocalSearchParams<{ id: string; from?: string; to?: string }>();
  const id = String(p.id);
  const [from, setFrom] = useState(() => (p.from ? new Date(p.from) : addDays(startOfToday(), 3)));
  const [to, setTo] = useState(() => (p.to ? new Date(p.to) : addDays(startOfToday(), 6)));
  const [opts, setOpts] = useState<Record<string, boolean>>({});
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const ok = validRange(from, to);
  const sel = Object.keys(opts).filter((k) => opts[k]);

  const veh = useAsync(() => services.vehicles(atTen(from), atTen(to)).then((l) => l.find((v) => v.id === id) ?? null), [id, from.getTime(), to.getTime()]);
  const options = useAsync(() => services.options(), []);
  const quote = useAsync(() => (ok ? services.quote(id, atTen(from), atTen(to), sel) : Promise.resolve(null)), [id, from.getTime(), to.getTime(), sel.join(',')]);

  async function reserve() {
    if (!user) { router.push('/login'); return; }
    setBusy(true); setMsg(null);
    try {
      const b = await services.createBooking({ vehicleId: id, start: atTen(from), end: atTen(to), options: sel });
      router.replace({ pathname: '/booking/[ref]', params: { ref: b.ref, created: '1' } });
    } catch (e) {
      // Coupure pendant l'envoi : la demande a pu être enregistrée. On ne la rejoue jamais automatiquement.
      setMsg(isNetwork(e) ? "La connexion a été interrompue : votre demande a peut-être été enregistrée. Consultez « Mes locations » avant de réessayer." : describeError(e));
      if (isKind(e, 'conflict')) { void veh.reload(); void quote.reload(); }
    } finally { setBusy(false); }
  }

  if (veh.loading && !veh.data && !veh.error) return <Loading />;
  if (veh.error && !veh.data) return <ErrorState error={veh.error} onRetry={veh.reload} />;
  const v = veh.data;
  if (!v) return <ErrorState error={new Error('introuvable')} />;
  const q = quote.data;
  const staff = !!user && user.role !== 'client';
  const canBook = ok && v.available && !!q && !staff;

  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }} keyboardShouldPersistTaps="handled">
      <View style={[card, { padding: 0, overflow: 'hidden' }]}><View style={{ backgroundColor: '#e4e7eb', paddingTop: 10 }}><CarArt body={v.bodyType} color={v.color} label={v.name} /></View></View>
      <View style={{ gap: 4 }}>
        <Text style={{ fontSize: 26, fontWeight: '700', color: t.texte }}>{v.name}</Text>
        <Text style={{ color: t.doux }}>{v.category} · {v.seats} places · {v.fuel} · {v.transmission}</Text>
        <Text style={{ color: t.doux }}>Dépôt de garantie : {eur(v.depositCents)}</Text>
      </View>
      <View style={[card, { flexDirection: 'row', gap: 12 }]}>
        <DateField label="Départ" value={from} minimumDate={startOfToday()} onChange={(d) => { setFrom(d); if (!validRange(d, to)) setTo(addDays(d, 1)); }} />
        <DateField label="Retour" value={to} minimumDate={addDays(from, 1)} onChange={setTo} />
      </View>
      {veh.error ? <ErrorBanner error={veh.error} onRetry={veh.reload} /> : null}
      <Tag label={v.available ? 'Disponible sur ces dates' : 'Indisponible sur ces dates'} tone={v.available ? 'ok' : 'err'} />

      <View style={card}>
        <Text style={{ fontWeight: '700', fontSize: 16, marginBottom: 6 }}>Options</Text>
        {(options.data ?? []).map((o) => (
          <View key={o.id} style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 48 }}>
            <View style={{ flex: 1 }}><Text style={{ color: t.texte }}>{o.label}</Text><Text style={{ color: t.doux, fontSize: 13 }}>+{eur(o.perDayCents)} / jour</Text></View>
            <Switch accessibilityLabel={o.label} value={!!opts[o.id]} onValueChange={(on) => setOpts((s) => ({ ...s, [o.id]: on }))} trackColor={{ true: t.safran }} />
          </View>
        ))}
        {options.error ? <ErrorBanner error={options.error} onRetry={options.reload} /> : null}
      </View>

      <View style={card}>
        <Text style={{ fontWeight: '700', fontSize: 16, marginBottom: 6 }}>Prix détaillé</Text>
        {!ok ? <Text style={{ color: t.err }}>Le retour doit être après le départ.</Text> : quote.error && !q ? <ErrorBanner error={quote.error} onRetry={quote.reload} /> : q ? (
          <>
            <Line label={`${q.days} jour${q.days > 1 ? 's' : ''} × ${eur(v.dailyPriceCents)}`} value={eur(q.baseCents)} />
            {q.optionsCents ? <Line label="Options" value={eur(q.optionsCents)} /> : null}
            {q.discountCents ? <Line label="Remise location longue durée" value={`−${eur(q.discountCents)}`} /> : null}
            <Line label="dont TVA 20 %" value={eur(q.vatCents)} />
            <Line label="Total TTC" value={eur(q.totalCents)} bold />
            <Text style={{ color: t.doux, fontSize: 12, marginTop: 6 }}>Le prix définitif est recalculé par le serveur à l'envoi de la demande.</Text>
          </>
        ) : <Loading />}
      </View>

      {msg ? <View accessibilityRole="alert" style={{ backgroundColor: t.errBg, padding: 12, borderRadius: 12 }}><Text style={{ color: t.err }}>{msg}</Text></View> : null}
      {staff ? <Text style={{ color: t.doux }}>Les demandes de réservation sont réservées aux comptes clients.</Text> : null}
      <Button title={user ? 'Envoyer la demande de réservation' : 'Se connecter pour réserver'} onPress={reserve} disabled={!!user && !canBook} loading={busy} />
      <Text style={{ color: t.doux, fontSize: 12, textAlign: 'center' }}>Aucun paiement n'est prélevé : la demande est validée par l'agence.</Text>
    </ScrollView>
  );
}
