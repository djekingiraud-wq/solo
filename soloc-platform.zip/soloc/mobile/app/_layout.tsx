import React from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { SessionProvider, useSession } from '../src/session';
import { Loading } from '../src/ui';
import { theme as t } from '../src/theme';

function Root() {
  const { ready } = useSession();
  if (!ready) return <Loading />;
  return (
    <Stack screenOptions={{ headerStyle: { backgroundColor: t.nuit }, headerTintColor: '#fff', headerTitleStyle: { fontWeight: '700' }, contentStyle: { backgroundColor: t.ivoire }, headerBackTitle: 'Retour' }}>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="vehicle/[id]" options={{ title: 'Véhicule' }} />
      <Stack.Screen name="booking/[ref]" options={{ title: 'Réservation' }} />
      <Stack.Screen name="login" options={{ title: 'Connexion', presentation: 'modal' }} />
      <Stack.Screen name="incident/new" options={{ title: 'Signaler un incident', presentation: 'modal' }} />
    </Stack>
  );
}
export default function Layout() {
  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <SessionProvider><Root /></SessionProvider>
    </SafeAreaProvider>
  );
}
