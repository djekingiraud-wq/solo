import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useSession } from '../src/session';
import { Button, Chips } from '../src/ui';
import { describeError } from '../src/errors';
import { theme as t } from '../src/theme';

type Mode = 'login' | 'register';
export default function Login() {
  const router = useRouter();
  const { login, register } = useSession();
  const [mode, setMode] = useState<Mode>('login');
  const [email, setEmail] = useState(''), [password, setPassword] = useState(''), [first, setFirst] = useState(''), [last, setLast] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function submit() {
    const e = email.trim();
    if (!/^\S+@\S+\.\S+$/.test(e)) return setMsg('Saisissez une adresse e-mail valide.');
    if (mode === 'register') {
      if (!first.trim() || !last.trim()) return setMsg('Indiquez votre prénom et votre nom.');
      if (password.length < 10) return setMsg('Le mot de passe doit contenir au moins 10 caractères.');
    } else if (!password) return setMsg('Saisissez votre mot de passe.');
    setBusy(true); setMsg(null);
    try {
      if (mode === 'login') await login(e, password); else await register({ email: e, password, firstName: first.trim(), lastName: last.trim() });
      router.back();
    } catch (err) { setMsg(describeError(err)); } finally { setBusy(false); }
  }
  const input = { minHeight: 48, borderWidth: 1.5, borderColor: t.gris, borderRadius: 12, paddingHorizontal: 12, backgroundColor: '#fff', fontSize: 16, color: t.texte } as const;
  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ padding: 16, gap: 12 }} keyboardShouldPersistTaps="handled">
        <Chips<Mode> label="Mode" value={mode} onChange={(m) => { setMode(m); setMsg(null); }} items={[{ id: 'login', label: 'Connexion' }, { id: 'register', label: 'Créer un compte' }]} />
        {mode === 'register' ? (<>
          <TextInput accessibilityLabel="Prénom" style={input} placeholder="Prénom" value={first} onChangeText={setFirst} autoComplete="given-name" textContentType="givenName" />
          <TextInput accessibilityLabel="Nom" style={input} placeholder="Nom" value={last} onChangeText={setLast} autoComplete="family-name" textContentType="familyName" />
        </>) : null}
        <TextInput accessibilityLabel="E-mail" style={input} placeholder="E-mail" value={email} onChangeText={setEmail} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" autoComplete="email" textContentType="emailAddress" />
        <TextInput accessibilityLabel="Mot de passe" style={input} placeholder={mode === 'register' ? 'Mot de passe (10 caractères minimum)' : 'Mot de passe'} value={password} onChangeText={setPassword} secureTextEntry autoComplete={mode === 'register' ? 'new-password' : 'current-password'} textContentType={mode === 'register' ? 'newPassword' : 'password'} onSubmitEditing={submit} />
        {msg ? <View accessibilityRole="alert" style={{ backgroundColor: t.errBg, padding: 12, borderRadius: 12 }}><Text style={{ color: t.err }}>{msg}</Text></View> : null}
        <Button title={mode === 'login' ? 'Se connecter' : 'Créer mon compte'} onPress={submit} loading={busy} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
