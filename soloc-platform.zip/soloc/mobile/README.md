# SOLOC Mobile (Expo / React Native)

Une seule application pour iOS et Android. Elle appelle le backend SOLOC existant : **prix, disponibilité, droits et règles de réservation restent côté serveur**.
Navigation par rôle : le **client** voit *Véhicules · Mes locations · Compte* ; l'**employé** et l'**administrateur** voient *Planning · Incidents · Compte*.

## Prérequis
- Node ≥ 22, le backend lancé (`npm run seed && npm start` à la racine du projet).
- Un téléphone avec **Expo Go** (App Store / Google Play) **ou** un simulateur iOS (macOS + Xcode) / un émulateur Android (Android Studio).
- Ordinateur et téléphone sur le **même Wi-Fi** (téléphone physique).

## 1. Installer
```
cd mobile
npm install
npx expo install --fix      # aligne les versions des paquets Expo/React Native sur votre SDK
cp .env.example .env        # puis éditez EXPO_PUBLIC_API_URL
```
`EXPO_PUBLIC_API_URL` ne doit jamais valoir `localhost` sauf simulateur iOS :
| Cible | URL |
|---|---|
| Simulateur iOS | `http://localhost:3000` |
| Émulateur Android | `http://10.0.2.2:3000` |
| Téléphone (iOS ou Android) | `http://<IP locale du PC>:3000` (ex. `ipconfig` / `ifconfig`) |

Le pare-feu du PC doit autoriser le port 3000 en réseau privé.

## 2. Lancer
```
npx expo start
```
- **iPhone** : ouvrez l'appareil photo, scannez le QR code, ouvrez dans Expo Go.
- **Android** : ouvrez Expo Go, « Scan QR code ».
- **Simulateur iOS** : touche `i` dans le terminal. **Émulateur Android** : touche `a`.
- Si le téléphone ne trouve pas le PC : `npx expo start --tunnel`. Le backend doit rester joignable par `EXPO_PUBLIC_API_URL`.

## 3. Comptes de démonstration
`npm run seed` (racine) affiche une seule fois les mots de passe de `client@soloc.test`, `agent@soloc.test` (employé) et `admin@soloc.test`.

## 4. Plan de test manuel
**Client** : catalogue → changer les dates (les badges Disponible/Indisponible changent) → fiche → options (le prix se recalcule) → « Se connecter pour réserver » → créer un compte → demande envoyée → *Mes locations* → annuler.
**Conflit** : avec deux comptes, réservez le même véhicule aux mêmes dates : le second voit « n'est plus disponible ».
**Employé** : *Planning* (Départs / Retours / À venir / Demandes, recherche) → ouvrir une réservation confirmée → *Remise des clés* (km + carburant) → *Retour* → *Signaler un incident*.
**Administrateur** : en plus, Confirmer / Refuser une demande depuis son détail.
**Réseau** : activez le mode avion, tirez pour rafraîchir → message « Pas de connexion » + bouton Réessayer, données déjà affichées conservées ; coupez le backend pendant l'envoi d'une demande → message qui invite à vérifier *Mes locations* (la demande n'est jamais renvoyée automatiquement). Redémarrez le backend avec une session expirée → retour à l'état déconnecté.

## 5. Tests automatiques
```
cd mobile && npm test      # client réseau, erreurs, formats, contrôle de publication (10 tests)
cd .. && npm test          # backend, audit, exploitation, paiement, e-mails et client mobile (69 tests)
```
Ils couvrent la couche réseau, la gestion d'erreurs et la compatibilité avec l'API réelle. **Les écrans eux-mêmes n'ont pas été exécutés** (voir limites).

## 6. Builds de test / production (hors Expo Go)
- `npx expo install expo-dev-client` puis `eas build --profile development --platform ios|android` (compte Expo requis ; iOS exige un compte Apple Developer).
- Identifiants provisoires à remplacer dans `app.json` : `com.soloc.app`.
- **HTTPS obligatoire** pour les builds distribuables (iOS App Transport Security, Android bloque le HTTP en clair) : déployez le backend derrière HTTPS et mettez à jour `EXPO_PUBLIC_API_URL`.

## Décisions et limites
- **Authentification** : jeton Bearer stocké dans le trousseau sécurisé (`expo-secure-store`). Le backend le renvoie uniquement si l'en-tête `x-soloc-client: mobile` est présent (modification additive du backend, testée).
- **Hors ligne** : volontairement **non géré** en v1 (pas de saisie différée) ; les écritures exigent le réseau pour garantir disponibilité et prix côté serveur. Un mode hors ligne pour l'état des lieux demanderait file de synchronisation, résolution de conflits et droits : à cadrer à part.
- **Non implémenté** : notifications push (aucun service configuré), photos des dommages (pas de stockage côté backend), paiement en ligne, e-mails, modification de dates, signature électronique, polices de marque (police système).
- **Non vérifié** : les écrans (`app/`, composants) n'ont été ni compilés ni lancés sur appareil ou simulateur dans l'environnement de développement (pas de réseau pour installer Expo). Seuls la couche réseau/formatage (`src/api.ts`, `services.ts`, `errors.ts`, `format.ts`, `dates.ts`) est testée et typée. Attendez-vous à de petits ajustements au premier `expo start` / `tsc --noEmit` (versions de paquets, types).
- Les versions de `package.json` visent Expo SDK 54 ; `npx expo install --fix` est la référence.
