// Vérification contre un VRAI PostgreSQL (exécutée par la CI GitHub, job « postgres »).
// Elle comble le point que les tests SQLite ne peuvent pas couvrir : migrations, contrainte EXCLUDE, verrous, types, et chaque requête métier.
// NON EXÉCUTÉE dans l'environnement où ce fichier a été écrit (aucun PostgreSQL disponible) : sa première exécution peut révéler des écarts.
//   TEST_DATABASE_URL=postgres://user:pass@host:5432/soloc_test node scripts/pg-smoke.mjs
// DANGER : la base visée est VIDÉE (DROP SCHEMA public). Le nom de base doit contenir « test », « ci » ou « smoke » (sinon PG_SMOKE_ALLOW_RESET=1).
import assert from 'node:assert/strict';
import { openDb, migrate, pendingMigrations } from '../src/db.js';
import { hashPassword } from '../src/auth.js';
import * as S from '../src/service.js';
import { dispatchDue } from '../src/notifications.js';

// PG_SMOKE_SELFTEST=sqlite : rejoue ce script sur SQLite pour détecter ses PROPRES erreurs de logique (ne prouve rien sur PostgreSQL).
const SELF = process.env.PG_SMOKE_SELFTEST === 'sqlite';
const url = process.env.TEST_DATABASE_URL || '';
if (!SELF) {
  if (!/^postgres(ql)?:\/\//.test(url)) { console.error('TEST_DATABASE_URL (postgres://…) requis.'); process.exit(2); }
  const name = new URL(url).pathname.slice(1);
  if (!/test|ci|smoke/i.test(name) && process.env.PG_SMOKE_ALLOW_RESET !== '1') { console.error(`Refus : la base « ${name} » ne ressemble pas à une base de test (elle serait vidée).`); process.exit(2); }
}
process.env.MAX_PENDING_PER_USER = '1000'; process.env.NOTIFY_MODE = 'log';

let passed = 0; const failures = [];
const step = async (label, fn) => { try { await fn(); passed++; console.log(`OK      ${label}`); } catch (e) { failures.push(label); console.log(`ÉCHEC   ${label}\n        ${String(e.stack || e).split('\n').slice(0, 4).join('\n        ')}`); } };
const iso = (h) => new Date(Date.now() + h * 3600e3).toISOString();

const db = await openDb(SELF ? { SQLITE_FILE: ':memory:' } : { DATABASE_URL: url });
if (!SELF) await db.script('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
let admin, clients = [];
const mkUser = async (role, email) => { const r = await db.get(`INSERT INTO users(email,password_hash,first_name,last_name,role,active,created_at) VALUES(?,?,?,?,?,1,?) RETURNING id`, [email, await hashPassword('correct-horse-battery'), 'T', role, role, new Date().toISOString()]); return { id: r.id, role, email }; };

await step('migrations appliquées dans l\'ordre, idempotentes, verrou consultatif sans erreur', async () => {
  assert.equal((await migrate(db)).length, 3); assert.deepEqual(await migrate(db), []); assert.deepEqual(await pendingMigrations(db), []);
  const t = (await db.all(SELF ? `SELECT name table_name FROM sqlite_master WHERE type='table'` : `SELECT table_name FROM information_schema.tables WHERE table_schema='public'`)).map((r) => r.table_name);
  for (const x of ['users', 'sessions', 'vehicles', 'bookings', 'payments', 'incidents', 'notifications', 'webhook_events', 'audit_log']) assert.ok(t.includes(x), x);
});
await step('une migration modifiée après application est refusée', async () => {
  await db.run(`UPDATE schema_migrations SET checksum='deadbeef' WHERE name='001_init.sql'`);
  await assert.rejects(() => migrate(db), /modifiée/); await db.run(`UPDATE schema_migrations SET checksum=NULL`); await migrate(db);
});
await step('types : identifiants en nombres, dates en chaînes ISO, comptages en nombres', async () => {
  admin = await mkUser('admin', 'adm@pg.test'); assert.equal(typeof admin.id, 'number');
  const u = await db.get('SELECT created_at FROM users WHERE id=?', [admin.id]); assert.match(u.created_at, /^\d{4}-\d{2}-\d{2}T.*Z$/);
  assert.equal(typeof (await db.get('SELECT COUNT(*) c FROM users')).c, 'number');
});
await step('véhicules : création, plaque unique, archivage', async () => {
  for (const id of ['pa', 'pb']) await S.createVehicle(db, admin, { id, plate: `PG-${id}-001`, name: `Auto ${id}`, category: 'Citadine', bodyType: 'cit', seats: 5, fuel: 'Essence', transmission: 'Manuelle', dailyPriceCents: 5000, depositCents: 30000 });
  await assert.rejects(() => S.createVehicle(db, admin, { id: 'pc', plate: 'PG-pa-001', name: 'x', category: 'x', bodyType: 'cit', seats: 5, fuel: 'x', transmission: 'x', dailyPriceCents: 1, depositCents: 0 }), /déjà utilisé/);
});
await step('contrainte EXCLUDE : un INSERT SQL direct qui chevauche est rejeté (code 23P01)', async () => {
  const u = await mkUser('client', 'c0@pg.test'); clients.push(u); const b = await S.createBooking(db, u, { vehicleId: 'pa', start: iso(100), end: iso(124), options: [] });
  await assert.rejects(() => db.run(`INSERT INTO bookings(ref,user_id,vehicle_id,start_at,end_at,status,days,base_cents,discount_cents,options_cents,vat_cents,total_cents,deposit_cents,options,created_at,updated_at) VALUES('SL-RAW',?,?,?,?,'confirmed',1,1,0,0,0,1,0,'[]',?,?)`, [u.id, 'pa', b.start, b.end, iso(0), iso(0)]), (e) => (SELF ? /booking_overlap/.test(e.message) : e.code === '23P01'));
});
await step('concurrence : 25 demandes simultanées sur le même créneau => une seule réussit', async () => {
  for (let i = 1; i <= 25; i++) clients.push(await mkUser('client', `c${i}@pg.test`));
  const res = await Promise.allSettled(clients.slice(1).map((u) => S.createBooking(db, u, { vehicleId: 'pb', start: iso(200), end: iso(224), options: [] })));
  assert.equal(res.filter((r) => r.status === 'fulfilled').length, 1);
  assert.ok(res.filter((r) => r.status === 'rejected').every((r) => r.reason.status === 409), 'toutes les autres doivent recevoir 409');
  const dup = await db.get(`SELECT COUNT(*) c FROM bookings a JOIN bookings b ON a.vehicle_id=b.vehicle_id AND a.id<b.id WHERE a.status IN ('pending','confirmed','active') AND b.status IN ('pending','confirmed','active') AND a.start_at<b.end_at AND b.start_at<a.end_at`);
  assert.equal(dup.c, 0);
});
await step('cycle complet : confirmation, remise, retour, encaissement, plafond de remboursement', async () => {
  const b = await S.createBooking(db, clients[1], { vehicleId: 'pa', start: iso(1), end: iso(25), options: ['ass'] });
  await S.confirmBooking(db, admin, b.ref);
  const staff = await mkUser('employee', 'emp@pg.test');
  assert.equal((await S.pickupBooking(db, staff, b.ref, { odometerKm: 1000, fuelLevel: 80 })).status, 'active');
  assert.equal((await S.returnBooking(db, staff, b.ref, { odometerKm: 1100, fuelLevel: 40 })).status, 'completed');
  assert.equal((await S.recordPayment(db, admin, b.ref, { kind: 'payment', amountCents: 3000, method: 'manual' })).paidCents, 3000);
  await assert.rejects(() => S.recordPayment(db, admin, b.ref, { kind: 'refund', amountCents: 9000 }), /dépasse/);
});
await step('Stripe : webhook idempotent (ON CONFLICT), doublon, remboursement cumulé', async () => {
  const b = await S.createBooking(db, clients[2], { vehicleId: 'pa', start: iso(300), end: iso(324), options: [] }); await S.confirmBooking(db, admin, b.ref);
  const ev = (id) => ({ id, type: 'checkout.session.completed', data: { object: { id: 'cs_1', payment_intent: 'pi_pg1', client_reference_id: b.ref, payment_status: 'paid', amount_total: 5000, currency: 'eur' } } });
  assert.equal((await S.applyStripeEvent(db, ev('evt_a'))).handled, true); assert.equal((await S.applyStripeEvent(db, ev('evt_a'))).reason, 'duplicate'); assert.equal((await S.applyStripeEvent(db, ev('evt_b'))).reason, 'duplicate');
  assert.equal((await S.applyStripeEvent(db, { id: 'evt_r', type: 'charge.refunded', data: { object: { id: 'ch', payment_intent: 'pi_pg1', amount_refunded: 2000 } } })).handled, true);
  assert.equal((await S.getBooking(db, admin, b.ref)).paidCents, 3000);
});
await step('incidents, archivage, tableau de bord, audit, file d\'e-mails', async () => {
  await S.createIncident(db, admin, { vehicleId: 'pa', category: 'cleaning', severity: 'low', description: 'Intérieur à nettoyer' }); assert.equal((await S.listIncidents(db)).length, 1);
  const d = await S.dashboard(db, admin); for (const k of ['activeVehicles', 'rented', 'available', 'toConfirm', 'late', 'occupancyPct', 'revenueCents', 'pendingPaymentsCents']) assert.equal(typeof d[k], 'number', k);
  assert.ok((await S.listAudit(db, { action: 'booking.confirm' })).length >= 1);
  assert.ok((await S.listBookings(db, admin)).length >= 3); assert.ok((await S.listVehicles(db, { from: iso(5), to: iso(9), staff: true })).length === 2);
  const sent = []; const out = await dispatchDue(db, { send: async (m) => sent.push(m.to) }); assert.ok(out.sent >= 1 && sent.length === out.sent);
  assert.equal((await S.notificationStats(db)).counts.sent, out.sent);
  await assert.rejects(() => S.archiveVehicle(db, admin, 'pa'), /empêchent/);
});

await db.close();
console.log(`\n${passed} étapes réussies, ${failures.length} échec(s)${failures.length ? ' : ' + failures.join(' | ') : ''}`);
process.exit(failures.length ? 1 : 0);
