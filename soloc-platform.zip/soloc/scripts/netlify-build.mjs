// Construit dist/ pour Netlify : copie public/, génère _redirects (relais /api/* vers le backend) et _headers.
// Variables (à définir dans Netlify > Site configuration > Environment variables, par contexte) :
//   BACKEND_URL                 obligatoire : https://api.votre-domaine (sans « / » final)
//   PRODUCTION_BACKEND_URL      optionnel   : si défini, les aperçus (deploy-preview, branch-deploy) refusent de pointer dessus
//   ALLOW_PREVIEW_ON_PRODUCTION_BACKEND=1  contourne ce garde-fou (déconseillé : les aperçus écriraient dans la base de production)
// Netlify fournit CONTEXT = production | deploy-preview | branch-deploy | dev.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const env = process.env;
const ctx = env.CONTEXT || 'production';
const out = path.resolve(root, env.OUT_DIR || 'dist');
const backend = (env.BACKEND_URL || '').trim();
const fail = (m) => { console.error(`BUILD NETLIFY REFUSÉ : ${m}`); process.exit(1); };

if (!/^https:\/\/[^/\s?#]+$/.test(backend)) fail('BACKEND_URL doit être une URL https:// sans chemin ni « / » final (ex. https://api.votre-domaine).');
if (/\.example(?![A-Za-z0-9-])|example\.(com|org)|localhost|127\.0\.0\.1|CHANGE_ME/i.test(backend)) fail(`BACKEND_URL est une adresse d'exemple ou locale (${backend}).`);
if (ctx !== 'production' && env.PRODUCTION_BACKEND_URL && backend === env.PRODUCTION_BACKEND_URL.trim() && env.ALLOW_PREVIEW_ON_PRODUCTION_BACKEND !== '1')
  fail(`le contexte « ${ctx} » pointe sur le backend de PRODUCTION : définissez un BACKEND_URL de préproduction pour ce contexte.`);

fs.rmSync(out, { recursive: true, force: true });
fs.cpSync(path.join(root, 'public'), out, { recursive: true });
fs.writeFileSync(path.join(out, '404.html'), '<!doctype html><meta charset="utf-8"><title>Introuvable</title><p>Page introuvable.</p>\n');

// Règles évaluées dans l'ordre. Le webhook Stripe ne doit PAS passer par Netlify : il est configuré directement sur le backend.
fs.writeFileSync(path.join(out, '_redirects'), [
  '/api/webhooks/*  /404.html  404!',
  `/api/*  ${backend}/api/:splat  200!`,
  '',
].join('\n'));

const csp = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; frame-ancestors 'none'";
fs.writeFileSync(path.join(out, '_headers'), [
  '/*',
  '  Strict-Transport-Security: max-age=31536000',
  '  X-Content-Type-Options: nosniff',
  '  X-Frame-Options: DENY',
  '  Referrer-Policy: same-origin',
  '  Permissions-Policy: camera=(), microphone=(), geolocation=()',
  `  Content-Security-Policy: ${csp}`,
  ...(ctx === 'production' ? [] : ['  X-Robots-Tag: noindex, nofollow']), // aperçus non indexés
  '/api/*',
  '  Cache-Control: no-store',
  '',
].join('\n'));

console.log(`dist prêt (${ctx}) : ${fs.readdirSync(out).join(', ')}\n/api/* -> ${backend}/api/*`);
