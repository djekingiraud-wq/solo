-- SOLOC — schéma PostgreSQL 14+ (non exécuté dans l'environnement de développement initial)
CREATE EXTENSION IF NOT EXISTS btree_gist;

CREATE TABLE users (
  id            bigserial PRIMARY KEY,
  email         text NOT NULL UNIQUE,               -- toujours stocké en minuscules par l'application
  password_hash text NOT NULL,
  first_name    text NOT NULL,
  last_name     text NOT NULL,
  role          text NOT NULL DEFAULT 'client' CHECK (role IN ('client','employee','admin')),
  active        integer NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE sessions (
  token_hash text PRIMARY KEY,                      -- SHA-256 du jeton ; le jeton brut n'est jamais stocké
  user_id    bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE vehicles (
  id                text PRIMARY KEY,
  plate             text NOT NULL UNIQUE,
  name              text NOT NULL,
  category          text NOT NULL,
  body_type         text NOT NULL CHECK (body_type IN ('cit','ber','suv','spo')),
  color             text NOT NULL DEFAULT '#888888',
  seats             integer NOT NULL CHECK (seats > 0),
  fuel              text NOT NULL,
  transmission      text NOT NULL,
  daily_price_cents integer NOT NULL CHECK (daily_price_cents > 0),
  deposit_cents     integer NOT NULL CHECK (deposit_cents >= 0),
  status            text NOT NULL DEFAULT 'active' CHECK (status IN ('active','maintenance','archived')),
  created_at        timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE unavailabilities (
  id         bigserial PRIMARY KEY,
  vehicle_id text NOT NULL REFERENCES vehicles(id),
  start_at   timestamptz NOT NULL,
  end_at     timestamptz NOT NULL,
  reason     text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (end_at > start_at)
);

CREATE TABLE bookings (
  id             bigserial PRIMARY KEY,
  ref            text NOT NULL UNIQUE,
  user_id        bigint NOT NULL REFERENCES users(id),
  vehicle_id     text NOT NULL REFERENCES vehicles(id) ON DELETE RESTRICT,
  start_at       timestamptz NOT NULL,
  end_at         timestamptz NOT NULL,
  status         text NOT NULL CHECK (status IN ('pending','confirmed','active','completed','cancelled','refused','expired')),
  -- instantané du prix au moment de la demande : une modification de tarif n'est jamais rétroactive
  days           integer NOT NULL,
  base_cents     integer NOT NULL,
  discount_cents integer NOT NULL,
  options_cents  integer NOT NULL,
  vat_cents      integer NOT NULL,
  total_cents    integer NOT NULL,
  deposit_cents  integer NOT NULL,
  options        text NOT NULL DEFAULT '[]',
  expires_at     timestamptz,                       -- fin de la retenue d'une demande non confirmée
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  CHECK (end_at > start_at),
  -- garde-fou ultime contre les doubles réservations, indépendant du code applicatif
  CONSTRAINT bookings_no_overlap EXCLUDE USING gist
    (vehicle_id WITH =, tstzrange(start_at, end_at, '[)') WITH &&)
    WHERE (status IN ('pending','confirmed','active'))
);
CREATE INDEX bookings_user_idx    ON bookings(user_id);
CREATE INDEX bookings_status_idx  ON bookings(status, start_at);
CREATE INDEX unavail_vehicle_idx  ON unavailabilities(vehicle_id, start_at, end_at);

CREATE TABLE booking_events (
  id         bigserial PRIMARY KEY,
  booking_id bigint NOT NULL REFERENCES bookings(id),
  actor_id   bigint REFERENCES users(id),
  action     text NOT NULL,
  detail     text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE payments (
  id           bigserial PRIMARY KEY,
  booking_id   bigint NOT NULL REFERENCES bookings(id),
  kind         text NOT NULL CHECK (kind IN ('payment','refund','deposit')),
  amount_cents integer NOT NULL CHECK (amount_cents > 0),
  method       text NOT NULL,                       -- 'manual' tant qu'aucun prestataire n'est branché
  created_by   bigint REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE inspections (
  id          bigserial PRIMARY KEY,
  booking_id  bigint NOT NULL REFERENCES bookings(id),
  kind        text NOT NULL CHECK (kind IN ('pickup','return')),
  odometer_km integer NOT NULL CHECK (odometer_km >= 0),
  fuel_level  integer NOT NULL CHECK (fuel_level BETWEEN 0 AND 100),
  notes       text NOT NULL DEFAULT '',
  created_by  bigint REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (booking_id, kind)
);

CREATE TABLE audit_log (
  id         bigserial PRIMARY KEY,
  actor_id   bigint,
  action     text NOT NULL,
  entity     text NOT NULL,
  entity_id  text NOT NULL,
  detail     text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
