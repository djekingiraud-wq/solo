#!/usr/bin/env bash
# Retour à la version applicative précédente (la base N'EST PAS restaurée : voir docs/ROLLBACK.md). NON EXÉCUTÉ dans l'environnement de développement initial.
set -euo pipefail
cd "$(dirname "$0")/.."
PREV="$(cat .deploy/previous 2>/dev/null || true)"; [ -n "$PREV" ] || { echo "Aucune version précédente enregistrée (.deploy/previous)." >&2; exit 1; }
CUR="$(cat .deploy/current 2>/dev/null || true)"
echo "Retour de $CUR vers $PREV"
echo "$PREV" > .deploy/current; [ -n "$CUR" ] && echo "$CUR" > .deploy/previous
SOLOC_IMAGE="$PREV" docker compose up -d app
for i in $(seq 1 30); do
  if docker compose exec -T app wget -qO- http://127.0.0.1:3000/readyz >/dev/null 2>&1; then echo "OK : $PREV est prêt."; exit 0; fi
  sleep 2
done
echo "ÉCHEC : $PREV n'est pas prêt non plus. Si une migration a modifié la base de façon incompatible : docs/ROLLBACK.md (restauration)." >&2; exit 1
