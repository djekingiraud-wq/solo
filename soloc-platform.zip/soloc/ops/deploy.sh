#!/usr/bin/env bash
# Déploiement d'une version. Retour arrière automatique si la nouvelle version n'est pas prête. NON EXÉCUTÉ dans l'environnement de développement initial.
# Usage : ops/deploy.sh <étiquette>   (ex. v0.3.0 ou le SHA git)
set -euo pipefail
cd "$(dirname "$0")/.."
TAG="${1:?usage: ops/deploy.sh <étiquette>}"; IMAGE="soloc:$TAG"; mkdir -p .deploy
[ -f .env.production ] || { echo "ERREUR : .env.production absent" >&2; exit 1; }
echo "1/7 sauvegarde avant déploiement"; ./ops/backup.sh pre-deploy
echo "2/7 construction de l'image $IMAGE"; docker build -t "$IMAGE" .
echo "3/7 validation de la configuration (refuse les valeurs d'exemple)"; docker run --rm --env-file .env.production "$IMAGE" node src/check-config.js
echo "4/7 migrations (explicites ; additives uniquement)"; SOLOC_IMAGE="$IMAGE" docker compose run --rm migrate
PREV="$(cat .deploy/current 2>/dev/null || true)"; [ -n "$PREV" ] && echo "$PREV" > .deploy/previous
echo "5/7 bascule vers $IMAGE"; echo "$IMAGE" > .deploy/current; SOLOC_IMAGE="$IMAGE" docker compose up -d app caddy
echo "6/7 attente de /readyz (60 s max)"
for i in $(seq 1 30); do
  if docker compose exec -T app wget -qO- http://127.0.0.1:3000/readyz >/dev/null 2>&1; then echo "7/7 OK : $IMAGE est prêt. Vérifiez maintenant un parcours réel (voir docs/DEPLOY.md, section « Vérifications après déploiement »)."; exit 0; fi
  sleep 2
done
echo "ÉCHEC : la nouvelle version n'est pas prête. Retour arrière automatique…" >&2
[ -n "$PREV" ] && ./ops/rollback.sh || echo "Aucune version précédente connue : intervention manuelle requise." >&2
exit 1
