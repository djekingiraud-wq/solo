#!/usr/bin/env bash
# Prouve qu'une sauvegarde est RESTAURABLE : restaure dans une base temporaire et contrôle les données. NON EXÉCUTÉ dans l'environnement de développement initial.
# Usage : ops/verify-restore.sh [fichier.dump]   (défaut : la plus récente)
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; . ./.env.production; set +a
DIR="${BACKUP_DIR:-/var/backups/soloc}"; U="${POSTGRES_USER:-soloc}"; SCRATCH="soloc_verify_$$"
FILE="${1:-$(ls -1t "$DIR"/soloc-*.dump 2>/dev/null | head -1)}"; [ -f "$FILE" ] || { echo "Aucune sauvegarde trouvée" >&2; exit 1; }
( cd "$(dirname "$FILE")" && sha256sum -c "$(basename "$FILE").sha256" ) || { echo "ÉCHEC : somme de contrôle" >&2; exit 1; }
cleanup() { docker compose exec -T db dropdb -U "$U" --if-exists "$SCRATCH" >/dev/null 2>&1 || true; }; trap cleanup EXIT
docker compose exec -T db createdb -U "$U" "$SCRATCH"
docker compose exec -T db pg_restore -U "$U" -d "$SCRATCH" --no-owner --exit-on-error < "$FILE"
q() { docker compose exec -T db psql -U "$U" -d "$SCRATCH" -Atc "$1"; }
echo "migrations : $(q 'SELECT COUNT(*) FROM schema_migrations')  utilisateurs : $(q 'SELECT COUNT(*) FROM users')  véhicules : $(q 'SELECT COUNT(*) FROM vehicles')  réservations : $(q 'SELECT COUNT(*) FROM bookings')  paiements : $(q 'SELECT COUNT(*) FROM payments')"
OVERLAP="$(q "SELECT COUNT(*) FROM bookings a JOIN bookings b ON a.vehicle_id=b.vehicle_id AND a.id<b.id WHERE a.status IN ('pending','confirmed','active') AND b.status IN ('pending','confirmed','active') AND a.start_at<b.end_at AND b.start_at<a.end_at")"
[ "$OVERLAP" = "0" ] || { echo "ÉCHEC : $OVERLAP chevauchements dans la sauvegarde" >&2; exit 1; }
[ "$(q 'SELECT COUNT(*) FROM schema_migrations')" -ge 1 ] || { echo "ÉCHEC : aucune migration" >&2; exit 1; }
echo "OK : sauvegarde restaurable ($FILE)"
