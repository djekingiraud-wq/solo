#!/usr/bin/env bash
# Sauvegarde PostgreSQL (format custom, compressé) + somme de contrôle + rotation. NON EXÉCUTÉ dans l'environnement de développement initial.
# Usage : ops/backup.sh [étiquette]      (ex. pre-deploy)
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; . ./.env.production; set +a
LABEL="${1:-daily}"; DIR="${BACKUP_DIR:-/var/backups/soloc}"; KEEP="${BACKUP_RETENTION_DAYS:-14}"
mkdir -p "$DIR"; chmod 700 "$DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"; OUT="$DIR/soloc-$STAMP-$LABEL.dump"
# écriture dans un fichier temporaire : une sauvegarde interrompue n'est jamais prise pour une sauvegarde valide
docker compose exec -T db pg_dump -U "${POSTGRES_USER:-soloc}" -d "${POSTGRES_DB:-soloc}" -Fc > "$OUT.partial"
[ -s "$OUT.partial" ] || { echo "ERREUR : sauvegarde vide" >&2; rm -f "$OUT.partial"; exit 1; }
mv "$OUT.partial" "$OUT"
( cd "$DIR" && sha256sum "$(basename "$OUT")" > "$(basename "$OUT").sha256" )
# chiffrement optionnel (clé publique GPG) : BACKUP_GPG_RECIPIENT=ops@votre-domaine
if [ -n "${BACKUP_GPG_RECIPIENT:-}" ]; then gpg --batch --yes --encrypt --recipient "$BACKUP_GPG_RECIPIENT" -o "$OUT.gpg" "$OUT" && echo "chiffré : $OUT.gpg"; fi
# rotation (les sauvegardes « pre-deploy » suivent la même durée)
find "$DIR" -name 'soloc-*.dump*' -mtime +"$KEEP" -delete
echo "Sauvegarde créée : $OUT ($(du -h "$OUT" | cut -f1))"
echo "RAPPEL : une copie hors du serveur est indispensable (rclone, rsync, S3…) : non automatisée ici."
