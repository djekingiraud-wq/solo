#!/usr/bin/env bash
# RESTAURATION DE PRODUCTION (destructive : remplace la base). NON EXÉCUTÉ dans l'environnement de développement initial.
# Usage : ops/restore.sh <fichier.dump> --yes-remplacer-la-production
set -euo pipefail
cd "$(dirname "$0")/.."
FILE="${1:?usage: ops/restore.sh <fichier.dump> --yes-remplacer-la-production}"; [ "${2:-}" = "--yes-remplacer-la-production" ] || { echo "Confirmation explicite manquante." >&2; exit 2; }
set -a; . ./.env.production; set +a
U="${POSTGRES_USER:-soloc}"; DB="${POSTGRES_DB:-soloc}"
( cd "$(dirname "$FILE")" && sha256sum -c "$(basename "$FILE").sha256" )
echo "1/5 sauvegarde de sécurité de l'état actuel"; ./ops/backup.sh before-restore || echo "ATTENTION : sauvegarde de sécurité impossible"
echo "2/5 arrêt de l'application"; docker compose stop app
echo "3/5 recréation de la base"; docker compose exec -T db dropdb -U "$U" --if-exists "$DB"; docker compose exec -T db createdb -U "$U" "$DB"
echo "4/5 restauration"; docker compose exec -T db pg_restore -U "$U" -d "$DB" --no-owner --exit-on-error < "$FILE"
echo "5/5 migrations éventuellement manquantes puis redémarrage"; docker compose run --rm migrate; docker compose up -d app
echo "Terminé. Vérifiez /readyz puis un parcours de réservation. Les paiements Stripe survenus après la sauvegarde sont à réconcilier (tableau de bord Stripe)."
