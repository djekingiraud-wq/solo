# Déploiement de SOLOC

Cible documentée : **un serveur Linux** avec Docker Compose (PostgreSQL + application + Caddy pour HTTPS).
Rien de ce document n'a été exécuté sur un vrai serveur : voir `READINESS.md`. Les commandes sont à rejouer en **préproduction** avant la production.

## 1. Environnements
| | Développement | Tests (CI) | Préproduction | Production |
|---|---|---|---|---|
| Base | SQLite ou PostgreSQL local | SQLite en mémoire | PostgreSQL (même version que prod) | PostgreSQL 16 |
| `NODE_ENV` | — | — | `production` | `production` |
| Domaine | localhost | — | `staging.<domaine>` | `<domaine>` |
| Stripe | off ou clés `sk_test_` | faux Stripe | clés `sk_test_` | `sk_live_` après validation |
| E-mails | `log` | faux fournisseur | domaine d'essai, destinataires internes | `resend` |
| Données de démonstration | `npm run seed` | oui | `FORCE_SEED_IN_PRODUCTION=1 npm run seed` (jamais en prod) | **interdit** (refus automatique) |
La préproduction doit ressembler à la production (mêmes images, mêmes scripts) : c'est elle qui valide un déploiement.

## 2. Prérequis serveur
Linux 64 bits (2 vCPU / 2 Go minimum à ajuster), Docker et Docker Compose v2, ports 80 et 443 ouverts, accès SSH par clé (mot de passe désactivé), pare-feu n'exposant que 22/80/443, mises à jour de sécurité automatiques. Le port 5432 n'est **pas** publié.

## 3. Domaine et DNS
- Enregistrement **A** (et **AAAA** si IPv6) de `<domaine>` vers l'IP du serveur ; **CNAME** `www` vers `<domaine>` (le `Caddyfile` redirige `www` vers l'apex).
- Attendre la propagation **avant** le premier démarrage de Caddy (sinon l'émission du certificat échoue et peut être temporairement limitée).
- Domaine d'envoi d'e-mails : ajouter les enregistrements fournis par le prestataire (SPF/DKIM) ; ajouter un DMARC. Le domaine de la boutique et celui de l'e-mail peuvent être identiques.

## 4. HTTPS
Caddy obtient et renouvelle automatiquement les certificats (Let's Encrypt) si le domaine pointe bien vers le serveur. Le volume `caddy_data` doit être conservé. L'application ajoute HSTS, un cookie de session `Secure` et refuse de démarrer en production si `PUBLIC_URL` n'est pas en `https://`.
Vérifier : `curl -I https://<domaine>` (200, `strict-transport-security`), `curl -I http://<domaine>` (redirection 301/308), test SSL Labs. N'activez la « preload list » HSTS qu'une fois sûr de tenir HTTPS durablement.

## 5. Variables d'environnement (`.env.production`, jamais versionné, droits 600)
| Variable | Obligatoire | Rôle |
|---|---|---|
| `NODE_ENV=production` | oui | active HSTS, cookie `Secure`, validations strictes |
| `DOMAIN`, `PUBLIC_URL` | oui | domaine pour Caddy ; URL `https://…` sans `/` final (retours de paiement) |
| `DATABASE_URL`, `POSTGRES_PASSWORD` | oui | connexion PostgreSQL ; mot de passe ≥ 12 caractères, **pas** `CHANGE_ME` |
| `TRUST_PROXY=1`, `TRUST_PROXY_HOPS=1` | oui derrière Caddy | lit la vraie IP (dernière valeur de `X-Forwarded-For`) pour la limitation des tentatives |
| `PENDING_TTL_HOURS`, `MAX_PENDING_PER_USER` | non | durée de retenue d'une demande (24) ; plafond par client (3) |
| `PAYMENTS_MODE`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` | si paiement | `off` par défaut |
| `NOTIFY_MODE`, `RESEND_API_KEY`, `MAIL_FROM` | si e-mails | `off` / `log` / `resend` |
| `LOG_REQUESTS=1` | conseillé | une ligne JSON par requête (méthode, chemin sans paramètres, statut, durée) |
| `AUTO_MIGRATE` | non | `1` = migrer au démarrage ; **déconseillé** en production |
| `BACKUP_DIR`, `BACKUP_RETENTION_DAYS`, `BACKUP_GPG_RECIPIENT` | non | voir §8 |
`npm run check:config` (ou le déploiement) **refuse** : valeurs d'exemple, domaine `.example`, SQLite en production, clés Stripe mal formées.

## 6. Premier déploiement
1. Sur le serveur : récupérer le code (`/opt/soloc`), `cp .env.production.example .env.production`, tout remplacer, `chmod 600 .env.production`.
2. `docker compose build` puis `docker compose up -d db` (attendre « healthy »).
3. `docker compose run --rm migrate` (les migrations sont une étape explicite : l'application **refuse de démarrer** si l'une est en attente).
4. Créer l'administrateur : `docker compose run --rm app node src/create-admin.js admin@<domaine> Prénom Nom` — le mot de passe généré s'affiche une seule fois ; le noter dans un gestionnaire de mots de passe puis le changer.
5. `docker compose up -d app caddy`, puis `docker compose logs -f app` (message « SOLOC démarré (production) »).
6. §9 « Vérifications après déploiement ».
**Ne jamais** lancer `npm run seed` en production (refus automatique).

## 7. Déploiements suivants
`ops/deploy.sh <étiquette>` : sauvegarde → build → validation de config → migrations → bascule → attente de `/readyz` → **retour arrière automatique** si non prêt. Détail et cas d'échec : `ROLLBACK.md`.
Règle de migration : **additives seulement** dans une version (nouvelle table/colonne nullable) ; supprimer ou renommer se fait en deux versions. Une migration déjà appliquée ne se modifie jamais (la somme de contrôle bloque le démarrage) : créer `00N_…sql`.

## 8. Sauvegardes
- `ops/backup.sh` (quotidienne via `ops/crontab.example`) : `pg_dump` compressé, somme de contrôle, rotation (14 jours par défaut), chiffrement GPG optionnel.
- **Une copie hors du serveur est obligatoire** (rclone/rsync/S3) : non automatisée ici.
- `ops/verify-restore.sh` (hebdomadaire) restaure la dernière sauvegarde dans une base temporaire et contrôle les données. **Une sauvegarde jamais restaurée n'est pas une sauvegarde.**
- Objectifs (RPO/RTO) : à décider par SOLOC ; avec une sauvegarde quotidienne, la perte maximale est d'environ 24 h hors sauvegarde pré-déploiement.
- Restauration réelle : `ops/restore.sh <fichier> --yes-remplacer-la-production`.

## 9. Vérifications après déploiement (à faire à la main)
`/healthz` et `/readyz` = 200 ; connexion admin ; création d'une réservation de test puis confirmation ; en cas de paiement actif, paiement de test ; reception d'un e-mail de test ; `GET /api/admin/audit` montre les actions ; `GET /api/admin/notifications` sans messages en échec ; `docker compose logs app` sans erreur.

## 10. Paiement Stripe — mise en service
1. Créer et activer le compte Stripe (informations légales de la société, compte bancaire : étapes côté Stripe).
2. Mode **test** d'abord : `PAYMENTS_MODE=stripe`, `STRIPE_SECRET_KEY=sk_test_…`.
3. Tableau de bord Stripe → Développeurs → Webhooks : ajouter `https://<domaine>/api/webhooks/stripe`, événements `checkout.session.completed`, `checkout.session.async_payment_succeeded`, `charge.refunded` ; copier le secret `whsec_…` dans `STRIPE_WEBHOOK_SECRET` ; redémarrer.
4. `npm run check:config -- --online` (teste la clé) ; **envoyer un événement de test depuis Stripe** et vérifier la réponse 200 ; payer une réservation confirmée avec une carte de test ; vérifier qu'elle passe en « payée » **uniquement** après le webhook ; rejouer l'événement (aucun doublon) ; rembourser depuis Stripe (remboursement enregistré).
5. Seulement ensuite : clés `sk_live_…` + nouveau webhook live. Une clé de test en production déclenche un avertissement au démarrage.
Limites connues : une session Checkout non payée expire côté Stripe (SOLOC en recrée une à la demande) ; un double paiement accidentel est enregistré puis signalé dans l'audit (`payment.overpaid`) pour **remboursement manuel** ; factures et avoirs légaux non implémentés ; 3-D Secure et moyens de paiement relèvent de la configuration Stripe.
En cas d'incident paiement : `PAYMENTS_MODE=off` puis redémarrer — Stripe réessaie ses webhooks pendant plusieurs jours, ils seront traités à la réactivation.

## 11. E-mails
`NOTIFY_MODE=resend` avec `RESEND_API_KEY`, `MAIL_FROM` d'un domaine **vérifié** chez le prestataire. Les messages sont écrits en base dans la même transaction que l'événement, envoyés par un répartiteur avec réessais (jusqu'à 6, délais croissants) ; les erreurs définitives (4xx) sont marquées « failed ». Suivi : `GET /api/admin/notifications` (admin). Aucun e-mail n'est envoyé en `off`/`log`.
**Notifications push : non implémentées.** À prévoir : paquet `expo-notifications`, table des jetons d'appareil + route d'enregistrement, identifiants FCM (Android) et clé APNs (iOS) via EAS, demande de consentement dans l'app, envoi via l'API Expo Push, mise à jour de la politique de confidentialité. Ne pas les annoncer aux utilisateurs avant test sur appareils réels.

## 12. Surveillance
`/healthz` (processus vivant) pour une sonde externe avec alerte e-mail/SMS ; `/readyz` (base + migrations) pour Caddy et le déploiement ; journaux JSON : `docker compose logs`. Non fait : suivi d'erreurs (Sentry), métriques, alertes Stripe (à activer dans Stripe), supervision disque/sauvegardes.

## 13. Sécurité d'exploitation
Secrets uniquement dans `.env.production` (600) ; rotation en cas de fuite (§ROLLBACK) ; mises à jour régulières de l'OS et des images (`docker compose pull`/rebuild) ; accès SSH par clé ; compte administrateur nominatif ; revue périodique du journal d'audit ; le conteneur tourne en utilisateur non-root.
Aucun test d'intrusion externe n'a été réalisé. Données personnelles : `DONNEES-PERSONNELLES.md`.
