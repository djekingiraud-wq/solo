# SOLOC — état de préparation au déploiement (11 octobre 2026)

Règle de lecture : **« configuré » ne veut jamais dire « opérationnel »**. Un service n'est opérationnel que lorsque la dernière colonne indique un test réel, fait par un humain, dans l'environnement visé.

| Élément | Ce qui est fait | Vérifié automatiquement | **Reste à faire / non vérifié** |
|---|---|---|---|
| Application serveur | API, rôles, réservations, sondes `/healthz` `/readyz`, journaux JSON sans données sensibles, arrêt propre, délais HTTP | Oui : 69 tests, démarrage et arrêt (SIGTERM) d'un vrai processus | Charge réelle, supervision externe |
| Validation de configuration | Refus du démarrage en production si variable absente, factice ou mal formée (base, URL HTTPS, Stripe, e-mail) | Oui : 5 tests + démarrage refusé réel | — |
| Migrations | Ordre, transaction, somme de contrôle, migration modifiée refusée, verrou consultatif PostgreSQL | **SQLite seulement** | **PostgreSQL jamais exécuté** (schéma, `EXCLUDE`, verrou) |
| Sauvegarde / restauration | SQLite : vérifiée et restaurée (test). PostgreSQL : scripts `ops/*.sh` | SQLite : oui | **Scripts PostgreSQL non exécutés** (pas de `pg_dump` ici) ; **copie hors serveur non automatisée** ; premier test de restauration réel à faire |
| Conteneur, compose, Caddy | `Dockerfile`, `docker-compose.yml`, `Caddyfile`, scripts `deploy.sh` / `rollback.sh` | Syntaxe seulement (YAML, `bash -n`) | **Jamais construit ni lancé** (pas de Docker) |
| Domaine et DNS | Procédure documentée | Non | Acheter / configurer le domaine, enregistrements DNS |
| HTTPS | Caddy (certificat automatique), HSTS et cookie `Secure` en production | Cookie `Secure` + HSTS : oui (test) ; certificat : **non** | Domaine réel, ports 80/443, test `curl -I` et SSL Labs |
| Paiement Stripe | Création de session (montant lu en base), webhook signé idempotent, remboursements, trop-perçu tracé, bouton web et mobile | Oui contre un **faux Stripe local** : 8 tests + 9 contrôles navigateur | **Aucun appel au vrai Stripe.** Compte Stripe, clés, endpoint webhook, paiement test, remboursement test, bascule en mode live |
| E-mails | File d'envoi transactionnelle, réessais, modèles, fournisseur Resend | Oui contre un **faux Resend local** : 7 tests | **Aucun e-mail réel envoyé.** Compte, domaine d'envoi (SPF/DKIM), réception réelle |
| Notifications push | — | — | **Non implémentées** (voir `DEPLOY.md` §10) |
| Application mobile | Écrans, client réseau, `eas.json`, contrôle de publication | Client réseau contre le vrai serveur : oui ; types : partiel ; contrôle de config : 2 tests | **Écrans jamais lancés.** Aucun build EAS, aucun appareil, aucune soumission |
| Pages légales | — | — | **Absentes** : CGL, politique de confidentialité, mentions, FAQ, contact. Bloquant pour la mise en ligne et les stores |
| Factures / avoirs, e-signature, PDF | — | — | Non implémentés |
| Surveillance / alertes | Sondes, journaux JSON, suivi de la file d'e-mails | Sondes : oui | Aucune alerte configurée, aucun suivi d'erreurs (Sentry…) |
| Conformité RGPD / juridique | Inventaire des données (`DONNEES-PERSONNELLES.md`) | Non | Validation par un juriste : durées de conservation, mentions, contrats |

## Liste de contrôle avant ouverture au public
Cochez seulement après avoir **vu** le résultat vous-même.

- [ ] `npm test` vert sur la machine de CI **avec PostgreSQL** (variable `DATABASE_URL`) — en particulier la concurrence
- [ ] `docker compose build` et `docker compose up` réussis sur le serveur cible
- [ ] DNS propagé, `https://DOMAINE` valide, redirection `www`, test SSL Labs
- [ ] `npm run check:config -- --online` sans échec (base, migrations, clé Stripe)
- [ ] Premier administrateur créé (`npm run create-admin`), mot de passe changé, aucun compte de démonstration
- [ ] Sauvegarde réelle + `ops/verify-restore.sh` réussi + copie hors serveur
- [ ] Retour arrière répété sur un environnement de préproduction (`ops/rollback.sh`)
- [ ] Stripe : paiement de test, rejeu du webhook, remboursement, puis seulement ensuite clés live
- [ ] E-mail : message réel reçu (hors spam) pour chaque modèle
- [ ] Pages légales validées et publiées ; politique de confidentialité accessible par URL
- [ ] Parcours complet client / employé / admin rejoué sur le domaine réel et sur un vrai téléphone
- [ ] Alerte externe sur `/healthz` ; personne désignée pour répondre
