# Mettre SOLOC sur GitHub

## 1. Fichiers fournis (ensemble GitHub)
Ces fichiers supposent le **dépôt SOLOC complet** (la CI utilise `package.json`, `src/`, `.env.production.example`, `scripts/netlify-build.mjs`).
| Fichier | Rôle |
|---|---|
| `.github/workflows/ci.yml` | 4 jobs : **`test`** (77 tests backend, tests mobile, refus du fichier d'exemple de config), **`netlify-build`** (build `dist/` valide et refus sans `BACKEND_URL`), **`postgres`** (`scripts/pg-smoke.mjs` contre un vrai PostgreSQL 16), **`browser`** (Chromium/Playwright : parcours, XSS, paiement) |
| `.github/workflows/netlify-deploy.yml` | déploiement Netlify par Actions — **inactif** tant que la variable `DEPLOY_VIA_ACTIONS` ≠ `true` |
| `.github/dependabot.yml` | mises à jour hebdomadaires (npm racine, npm mobile, actions) ; paquets Expo/React Native exclus (à aligner avec `npx expo install --fix`) |
| `.github/CODEOWNERS` | **tout est commenté** : à compléter avec vos vrais comptes |
| `.github/pull_request_template.md` | liste de contrôle de PR (migrations, secrets, compatibilité mobile) |
| `.gitattributes`, `.gitignore` | fins de ligne LF ; exclut `.env*`, `data/`, bases `*.db`, sauvegardes, `node_modules` |
| `SECURITY.md` | où signaler une vulnérabilité (adresse à remplacer) |
| `scripts/pg-smoke.mjs` | 9 vérifications PostgreSQL (migrations, contrainte `EXCLUDE`, 25 demandes concurrentes, cycle complet, webhook Stripe, SQL du tableau de bord) — **vide la base visée** : nom doit contenir `test`, `ci` ou `smoke` |

## 2. Première mise en ligne du dépôt
```
git init -b main
git add -A && git status        # relire : aucun .env, aucune base, aucune sauvegarde, aucun secret
git commit -m "SOLOC : version initiale"
# Créer un dépôt PRIVÉ vide sur github.com (sans README), puis :
git remote add origin git@github.com:VOTRE-COMPTE/soloc.git
git push -u origin main
```
Si un secret a été commité par erreur : le **révoquer** d'abord (le supprimer de l'historique ne suffit pas).
Conseil : exécuter une fois `npm install` sur une machine connectée et versionner `package-lock.json` (reproductibilité des builds).

## 3. Réglages du dépôt (non versionnables : à faire dans l'interface)
- **Settings → Branches → règle sur `main`** : exiger une pull request ; exiger les vérifications **`test`**, **`netlify-build`**, **`postgres`** (ne pas exiger `browser` tant qu'il n'a pas tourné proprement une fois) ; exiger la branche à jour ; interdire le push direct et le force-push ; (équipe) exiger une revue des CODEOWNERS.
- **Settings → Code security** : activer Dependabot alerts et security updates, **Secret scanning** et **Push protection**.
- **Settings → Actions → General** : permissions du `GITHUB_TOKEN` en **lecture seule** par défaut ; « Require approval for first-time contributors ».
- **Settings → Environments** : créer `production` (reviewers requis = vous, branche `main` seulement) et `preview`.
- **Settings → Secrets and variables → Actions** (seulement si option B de Netlify) :
| Type | Nom | Valeur |
|---|---|---|
| Variable | `DEPLOY_VIA_ACTIONS` | `true` |
| Variable | `BACKEND_URL` | `https://api.votre-domaine` |
| Variable | `STAGING_BACKEND_URL` | `https://api-staging.votre-domaine` |
| Secret (environnement `production` et `preview`) | `NETLIFY_AUTH_TOKEN` | jeton personnel Netlify |
| Secret | `NETLIFY_SITE_ID` | identifiant du site (Site configuration → General) |
**Aucun secret du backend (Stripe, base, e-mail) ne va dans GitHub** : ils vivent dans `.env.production` sur le serveur. Le job `postgres` utilise un mot de passe jetable de CI, sans valeur.

## 4. Choisir UN mode de déploiement du site
- **Option A (par défaut)** : intégration Git native de Netlify (`docs/NETLIFY.md` §3). Netlify déploie chaque push sur `main` et chaque pull request. Rien à configurer dans GitHub hormis la protection de branche.
- **Option B** : `netlify-deploy.yml`. Déploie **après** vos règles GitHub (environnement `production` avec validation manuelle possible). À épingler : version de `netlify-cli`.
Ne pas cumuler : double déploiement.

## 5. Déploiement du backend
Le workflow ne déploie **pas** le backend (serveur Linux + `ops/deploy.sh`, voir `docs/DEPLOY.md`). Pour étiqueter une version : `git tag v0.3.0 && git push --tags`, puis `ops/deploy.sh v0.3.0` sur le serveur.

## 6. Ce qui n'est pas vérifié
Aucun workflow n'a tourné sur GitHub (écrits ici sans accès réseau) : YAML valide, étapes shell rejouées en local, `pg-smoke.mjs` auto-testé sur SQLite uniquement. **Le premier passage de la CI peut échouer** pour des raisons d'environnement ; le job `postgres` est le premier test réel du code sur PostgreSQL. Versions d'actions (`checkout@v4`, `setup-node@v4`, `setup-python@v5`) à confirmer.
