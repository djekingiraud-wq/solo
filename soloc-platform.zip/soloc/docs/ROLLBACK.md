# Retour arrière et incidents

Principe : **les migrations sont additives**, donc la version applicative précédente reste compatible avec la base après une migration. Revenir en arrière = redéployer l'image précédente, **pas** restaurer la base (qui perdrait des données).

| Situation | Action | Perte de données |
|---|---|---|
| Nouvelle version non prête (`/readyz` ≠ 200) | `ops/deploy.sh` revient seul à la version précédente | aucune |
| Nouvelle version prête mais défectueuse | `ops/rollback.sh` (relance l'image de `.deploy/previous`, attend `/readyz`) | aucune |
| Migration incompatible avec l'ancienne version (ne devrait pas arriver : règle « additive ») | Corriger en avant par une nouvelle migration ; en dernier recours restaurer la sauvegarde « pre-deploy » (`ops/restore.sh`) | **oui : tout ce qui a été écrit depuis la sauvegarde** |
| Base corrompue ou supprimée | `ops/restore.sh <dernière sauvegarde vérifiée> --yes-remplacer-la-production` ; réconcilier ensuite les paiements Stripe survenus après la sauvegarde (tableau de bord Stripe ↔ table `payments`) | jusqu'à la dernière sauvegarde |
| Problème de paiement | `PAYMENTS_MODE=off`, redémarrer `app` (le bouton disparaît ; les webhooks reçoivent 503 et Stripe les rejoue) | aucune |
| Problème d'e-mails | `NOTIFY_MODE=off`, redémarrer (les messages déjà en file restent en base, rien n'est perdu) | aucune |
| Certificat / domaine | `docker compose logs caddy` ; vérifier DNS et ports 80/443 ; ne pas supprimer `caddy_data` | aucune |
| Fuite d'un secret | Remplacer la valeur (Stripe : « roll key » ; Resend : nouvelle clé ; base : nouveau mot de passe), redémarrer ; pour la clé Stripe, vérifier le journal Stripe ; pour une fuite de base, invalider les sessions : `DELETE FROM sessions;` | aucune |
| Version mobile défectueuse | Retirer/suspendre la version dans le store et republier une correction ; l'API reste compatible tant qu'aucune route n'est supprimée (ne supprimer une route qu'après adoption de la version mobile qui n'en dépend plus) | aucune |

## Procédure standard
1. Constater : `docker compose ps`, `docker compose logs --tail=200 app`, `/readyz`.
2. Décider : revenir en arrière **d'abord**, comprendre ensuite.
3. `ops/rollback.sh`, puis vérifier un parcours réel.
4. Noter l'incident (cause, durée, données touchées) ; ajouter un test qui l'aurait détecté.

## Jamais
Modifier une migration déjà appliquée (le démarrage est bloqué : somme de contrôle) ; restaurer la base « pour essayer » sans sauvegarde de sécurité (le script en fait une) ; supprimer le volume `pgdata` ou `caddy_data`.
## Non vérifié
Tous ces scripts n'ont été validés que syntaxiquement. **Répéter chaque ligne de ce tableau en préproduction** avant la production.
