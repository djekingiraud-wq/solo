# Inventaire des données personnelles (point de départ — à faire valider par un juriste)

Ce document décrit ce que SOLOC fait **techniquement**. Il n'est pas une politique de confidentialité ni un avis juridique.

| Donnée | Où | Finalité | Notes |
|---|---|---|---|
| Nom, prénom, e-mail | table `users` | compte, réservations, e-mails de service | requis |
| Mot de passe | `users.password_hash` (scrypt) | authentification | jamais en clair |
| Jeton de session | `sessions` (SHA-256), cookie HttpOnly (web), trousseau sécurisé (mobile) | connexion | durée 7 jours |
| Réservations, dates, montants | `bookings`, `booking_events` | exécution du contrat | prix figé |
| Paiements (montant, référence Stripe) | `payments` | suivi comptable | **aucun numéro de carte** : saisi chez Stripe |
| Incidents (description libre) | `incidents` | exploitation | saisis par le personnel ; éviter les données personnelles |
| Journal d'audit (qui, quoi, quand) | `audit_log` | sécurité | contient l'e-mail de l'acteur à l'affichage |
| Adresse IP | **non stockée** ; journaux de requêtes sans IP ni paramètres ; limitation des tentatives en mémoire seulement | — | le reverse proxy (Caddy) journalise les IP : à couvrir par la politique |
| E-mails envoyés | `notifications` | messages de service | contiennent nom, véhicule, dates, montant |
Pas de publicité, pas de traceur tiers, pas d'analytique dans le code actuel (polices Google chargées par le site web : à mentionner ou à héberger soi-même).

## À décider avec SOLOC et un juriste
Durées de conservation (réservations, factures, comptes inactifs, sauvegardes) ; base légale ; pièces d'identité / permis (non collectés aujourd'hui) ; sous-traitants (hébergeur, Stripe, prestataire d'e-mail) et transferts hors UE ; procédure d'accès / effacement : **non automatisée** (suppression d'un client à faire manuellement en conservant les écritures comptables) ; mentions légales, CGL, politique de cookies (un seul cookie de session strictement nécessaire).

## Pour les stores
Ces éléments alimentent le « App Privacy » d'Apple et le formulaire « Sécurité des données » de Google : données collectées = nom, e-mail, identifiants de compte, historique de réservations, informations de paiement traitées par un tiers ; aucune donnée de localisation, contacts, photos ni identifiant publicitaire. À re-vérifier si des notifications push, de l'analytique ou des photos sont ajoutées.
