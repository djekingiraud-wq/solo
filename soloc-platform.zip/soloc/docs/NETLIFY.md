# Déployer le site SOLOC sur Netlify

## 0. Ce que Netlify peut et ne peut pas héberger
SOLOC n'est pas un site statique : l'API est un **serveur Node.js avec base de données, tâches d'arrière-plan (e-mails) et webhooks Stripe**. Netlify ne sait pas exécuter cela tel quel.
La découpe retenue, **vérifiée localement** avec un relais simulé :

```
Navigateur ──► Netlify (https://monsite.netlify.app ou votre domaine)
                 ├─ /, app.js, style.css           servis par Netlify (dossier dist/)
                 └─ /api/*  ──relais (200)──►  Backend SOLOC (https://api.votre-domaine) ──► PostgreSQL
Application mobile ───────────────────────────►  Backend SOLOC (directement, jamais via Netlify)
Stripe (webhook) ─────────────────────────────►  Backend SOLOC /api/webhooks/stripe (jamais via Netlify)
```
**Le backend doit donc être déployé d'abord, ailleurs** (le dépôt fournit `docker-compose.yml` + `docs/DEPLOY.md` pour un serveur Linux ; tout hébergeur Node + PostgreSQL convient, non fourni ni testé ici). Réécrire l'API en fonctions Netlify serait un autre projet.
Avantage du relais : le navigateur ne parle qu'à **un seul domaine** → le cookie de session reste « même site » (pas de CORS à ouvrir).

## 1. Fichiers fournis (ensemble Netlify)
| Fichier | Rôle |
|---|---|
| `netlify.toml` | commande de build (`node scripts/netlify-build.mjs`), dossier publié (`dist`), Node 22 |
| `scripts/netlify-build.mjs` | copie `public/` dans `dist/`, **génère** `_redirects` (relais `/api/*`, blocage de `/api/webhooks/*`) et `_headers` (HSTS, CSP, anti-iframe, `noindex` hors production). **Fait échouer le build** si `BACKEND_URL` est absent, en http, local, d'exemple, ou si un aperçu pointe sur la production |
| `.nvmrc` | Node 22 |
| `test/netlify.test.js` | 4 tests (build, garde-fous, relais simulé) |
Pourquoi générer `_redirects` : `netlify.toml` ne permet pas d'insérer une variable d'environnement dans l'adresse d'un relais. **N'ajoutez ni `[[redirects]]` ni `[[headers]]` à la main.**

## 2. Backend : réglages requis AVANT de brancher Netlify
Dans `.env.production` du backend (voir `docs/DEPLOY.md`) :
| Variable | Valeur | Pourquoi |
|---|---|---|
| `DOMAIN` | `api.votre-domaine` | domaine du backend (certificat par Caddy) |
| `PUBLIC_URL` | `https://votre-site` (domaine Netlify ou personnalisé) | **origine du site** acceptée pour les écritures + adresses de retour de paiement. Sans elle : **toutes les écritures sont refusées (403)** — reproduit dans les tests |
| `ALLOWED_ORIGINS` | autres origines du site, séparées par des virgules (ex. `https://www.votre-domaine`) | domaine `www`, domaine `*.netlify.app` d'origine |
| `TRUST_PROXY=1`, `TRUST_PROXY_HOPS=N` | N = nombre de relais de confiance devant l'application | limitation des tentatives par IP. **N doit être mesuré**, voir §6 |
Le backend doit contenir le **contrôle d'origine par liste** (`PUBLIC_URL` / `ALLOWED_ORIGINS`, dans `src/server.js` et `src/config.js` du projet complet) : sans lui, le relais provoque des 403.
Stripe : l'endpoint webhook se déclare sur **`https://api.votre-domaine/api/webhooks/stripe`** (pas sur Netlify : le build le bloque exprès).
Application mobile : `EXPO_PUBLIC_API_URL=https://api.votre-domaine` (direct).

## 3. Créer le site Netlify (intégration Git native — « option A », recommandée)
1. Netlify → **Add new site → Import an existing project** → GitHub → choisir le dépôt. (Les libellés exacts de l'interface peuvent évoluer.)
2. Branche de production : `main`. Les paramètres de build sont lus dans `netlify.toml` : ne rien saisir à la main.
3. **Site configuration → Environment variables**, avec une portée **par contexte** :
| Variable | Production | Deploy Previews et Branch deploys |
|---|---|---|
| `BACKEND_URL` | `https://api.votre-domaine` | `https://api-staging.votre-domaine` (backend de **préproduction**) |
| `PRODUCTION_BACKEND_URL` | `https://api.votre-domaine` | `https://api.votre-domaine` (sert au garde-fou : un aperçu ne peut pas pointer sur la production) |
4. Lancer le premier déploiement. Un échec « BUILD NETLIFY REFUSÉ » indique une variable manquante ou invalide : le message dit laquelle.
**Option B** (déploiement piloté par GitHub Actions, `.github/workflows/netlify-deploy.yml`) : voir `docs/GITHUB.md`. **Ne jamais activer A et B ensemble.**

## 4. Domaine personnalisé et HTTPS
Site configuration → Domain management → ajouter le domaine ; créer au registrar les enregistrements indiqués par Netlify (ou déléguer le DNS à Netlify) ; le certificat HTTPS est émis automatiquement une fois le DNS propagé. Ensuite : mettre ce domaine dans `PUBLIC_URL` du backend, redémarrer le backend. L'en-tête HSTS est posé sans `includeSubDomains` ni « preload » (à n'ajouter qu'en connaissance de cause).

## 5. Vérifications après déploiement (à faire à la main : rien de ceci n'a été exécuté sur Netlify)
```
curl -I https://votre-site/                      # 200 ; strict-transport-security, x-frame-options: DENY, content-security-policy
curl -s https://votre-site/api/options           # JSON des options : le relais fonctionne
curl -i https://votre-site/api/webhooks/stripe -X POST -d '{}'   # 404 (volontairement inaccessible via Netlify)
curl -s https://votre-site/api/config            # {"onlinePayment":false|true}
```
Puis dans un navigateur : **créer un compte, se connecter, recharger** (le cookie `soloc_sid` doit persister), réserver, confirmer côté admin. Ouvrir une Deploy Preview : elle doit afficher `X-Robots-Tag: noindex` et parler au backend de préproduction.
Aperçus : leurs adresses changent (`deploy-preview-12--monsite.netlify.app`). Sur le backend de **préproduction uniquement**, `ALLOWED_ORIGINS=https://deploy-preview-*--monsite.netlify.app` (le `*` ne remplace qu'un morceau de libellé, jamais un libellé entier ; refusé tel quel en production par la validation, qui avertit).

## 6. Mesurer `TRUST_PROXY_HOPS` (indispensable)
Sans cela, soit la limitation des tentatives est contournable, soit tous les visiteurs partagent la même IP. Sur le backend de préproduction : `LOG_REQUESTS=1`, `LOG_CLIENT_IP=1`, redémarrer ; faire un appel depuis votre poste (`curl https://votre-site/api/options`) ; lire la ligne de journal : `xff` montre la chaîne reçue (ex. `votre.ip, ip-netlify, ip-hébergeur`) et `ip` l'adresse retenue. Réglez `TRUST_PROXY_HOPS` pour que `ip` = **votre** IP (valeur = nombre de relais de confiance à partir de la droite). Puis retirer `LOG_CLIENT_IP` (l'IP est une donnée personnelle).

## 7. Retour arrière du site
Netlify → Deploys → ouvrir un déploiement précédent réussi → **Publish deploy** (retour immédiat, sans reconstruire). **Lock publishing** gèle le site pendant un incident. Le retour arrière du **backend** et de la base suit `docs/ROLLBACK.md` : les deux sont indépendants (site statique ↔ API additive).

## 8. Limites et points non vérifiés
- Aucun déploiement Netlify réel n'a été fait : le comportement du relais est **ma lecture des règles `_redirects`** (relais simulé, 4 tests), pas Netlify lui-même. Points à confirmer au premier aperçu : transmission de `Set-Cookie` et `Origin` par le relais, délai maximal d'une réponse relayée (de l'ordre de quelques dizaines de secondes, à vérifier dans la documentation Netlify), taille des requêtes.
- Une réponse relayée plus lente que le délai Netlify échouera côté navigateur même si le backend aboutit.
- Le site charge des polices Google (CSP autorisée) ; la CSP garde `'unsafe-inline'` pour les scripts (gestionnaires `onclick` de l'interface).
- Plan Netlify, quotas de bande passante et coûts : à vérifier selon votre offre.
