// Audit : permissions, robustesse aux entrées hostiles, concurrence, calculs tarifaires, sécurité HTTP.
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { openDb, migrate } from '../src/db.js';
import { createApp } from '../src/server.js';
import { hashPassword } from '../src/auth.js';
import { quote } from '../src/pricing.js';

process.env.MAX_PENDING_PER_USER = '1000'; // les tests de charge ne doivent pas être bridés ; la limite a son propre test
let db, server, base;
const PW = 'correct-horse-battery';
const T0 = Date.now(); // horloge figée : les bornes "bout à bout" doivent être exactes
const iso = (h) => new Date(T0 + h * 3600e3).toISOString();

class Client {
  constructor() { this.cookie = ''; }
  async call(method, url, body, headers = {}, raw = false) {
    const r = await fetch(base + url, { method, headers: { ...(raw ? {} : { 'content-type': 'application/json' }), cookie: this.cookie, ...headers }, body: body === undefined ? undefined : raw ? body : JSON.stringify(body) });
    const sc = r.headers.get('set-cookie'); if (sc) this.cookie = sc.split(';')[0].endsWith('=') ? '' : sc.split(';')[0];
    const text = await r.text(); let json = null; try { json = JSON.parse(text); } catch { /* */ }
    return { status: r.status, body: json, text, headers: r.headers };
  }
  get(u) { return this.call('GET', u); } post(u, b = {}) { return this.call('POST', u, b); } patch(u, b) { return this.call('PATCH', u, b); }
}
async function mkUser(role, email) {
  const r = await db.get(`INSERT INTO users(email,password_hash,first_name,last_name,role,active,created_at) VALUES(?,?,?,?,?,1,?) RETURNING id`, [email, await hashPassword(PW), 'T', role, role, new Date().toISOString()]);
  const c = new Client(); assert.equal((await c.post('/api/auth/login', { email, password: PW })).status, 200); c.id = r.id; return c;
}
const veh = (id) => ({ id, plate: id.toUpperCase() + '-9', name: 'Auto ' + id, category: 'Citadine', bodyType: 'cit', seats: 5, fuel: 'Essence', transmission: 'Manuelle', dailyPriceCents: 5000, depositCents: 30000 });
let anon, alice, bob, staff, admin, REF;

before(async () => {
  db = await openDb({ SQLITE_FILE: ':memory:' }); await migrate(db);
  server = createApp(db); await new Promise((r) => server.listen(0, r)); base = `http://127.0.0.1:${server.address().port}`;
  anon = new Client(); admin = await mkUser('admin', 'adm@a.test'); staff = await mkUser('employee', 'emp@a.test');
  alice = await mkUser('client', 'ali@a.test'); bob = await mkUser('client', 'bob@a.test');
  for (const id of ['p1', 'p2', 'p3', 'p4', 'p5']) await admin.post('/api/admin/vehicles', veh(id));
  REF = (await alice.post('/api/bookings', { vehicleId: 'p1', start: iso(2000), end: iso(2024) })).body.ref;
});
after(async () => { server.close(); await db.close(); });

// ---------- 1. Matrice de permissions : chaque route × chaque rôle
const R = (m, p, body, allowed) => ({ m, p, body, allowed });
const ALL = ['anon', 'client', 'employee', 'admin'], AUTH = ['client', 'employee', 'admin'], STAFF = ['employee', 'admin'], ADM = ['admin'];
const MATRIX = () => [
  R('GET', '/api/options', undefined, ALL), R('GET', '/api/vehicles', undefined, ALL), R('GET', '/api/vehicles/p1', undefined, ALL),
  R('GET', `/api/quote?vehicle=p1&from=${iso(5000)}&to=${iso(5024)}`, undefined, ALL), R('GET', '/api/me', undefined, ALL),
  R('POST', '/api/bookings', { vehicleId: 'p5', start: iso(3000), end: iso(3024) }, ['client', 'admin']),
  R('GET', '/api/bookings', undefined, AUTH), R('GET', `/api/bookings/${REF}`, undefined, AUTH), R('POST', `/api/bookings/${REF}/cancel`, {}, AUTH),
  R('POST', `/api/bookings/${REF}/pickup`, { odometerKm: 1, fuelLevel: 1 }, STAFF), R('POST', `/api/bookings/${REF}/return`, { odometerKm: 1, fuelLevel: 1 }, STAFF),
  R('GET', '/api/admin/dashboard', undefined, STAFF), R('GET', '/api/admin/unavailabilities', undefined, STAFF),
  R('POST', `/api/admin/bookings/${REF}/confirm`, {}, ADM), R('POST', `/api/admin/bookings/${REF}/refuse`, {}, ADM),
  R('POST', `/api/admin/bookings/${REF}/payments`, { kind: 'payment', amountCents: 100 }, ADM),
  R('POST', '/api/admin/vehicles', veh('mx'), ADM), R('PATCH', '/api/admin/vehicles/p2', { name: 'Renommée' }, ADM),
  R('POST', '/api/admin/vehicles/p3/unavailabilities', { start: iso(6000), end: iso(6024), reason: 'x' }, ADM), R('POST', '/api/admin/vehicles/zzz/archive', {}, ADM),
  R('GET', '/api/admin/audit', undefined, ADM), R('POST', '/api/admin/users', { email: 'n@a.test', password: PW, role: 'employee' }, ADM), R('PATCH', '/api/admin/users/999999', { active: true }, ADM),
  R('POST', '/api/incidents', { vehicleId: 'p1', category: 'other', severity: 'low', description: 'test' }, STAFF), R('GET', '/api/incidents', undefined, STAFF),
];
test('permissions : matrice complète route × rôle (refus 401/403, accès ni 401 ni 403)', async () => {
  const who = { anon, client: alice, employee: staff, admin };
  const failures = [];
  for (const r of MATRIX()) for (const [role, c] of Object.entries(who)) {
    const res = await c.call(r.m, r.p, r.body);
    const denied = res.status === 401 || res.status === 403;
    const shouldAllow = r.allowed.includes(role);
    if (shouldAllow === denied || res.status >= 500) failures.push(`${role} ${r.m} ${r.p.split('?')[0]} -> ${res.status} (attendu ${shouldAllow ? 'accès' : 'refus'})`);
    if (!shouldAllow && role === 'anon' && res.status !== 401) failures.push(`anon doit recevoir 401 : ${r.p}`);
  }
  assert.deepEqual(failures, []);
});

test('permissions : isolation des données entre clients (lecture, annulation, liste)', async () => {
  assert.equal((await bob.get(`/api/bookings/${REF}`)).status, 404);
  assert.equal((await bob.post(`/api/bookings/${REF}/cancel`)).status, 404);
  assert.ok((await bob.get('/api/bookings')).body.every((b) => b.ref !== REF));
  const mine = (await alice.get(`/api/bookings/${REF}`)).body; assert.equal(mine.clientEmail, undefined); // pas d'infos staff côté client
  assert.equal((await staff.get(`/api/bookings/${REF}`)).body.clientEmail, 'ali@a.test');
  assert.equal((await anon.get('/api/vehicles')).body[0].plate, undefined);
});

test('permissions : un compte désactivé perd immédiatement l\'accès (sessions révoquées)', async () => {
  const x = await mkUser('client', 'tmp@a.test');
  assert.equal((await x.get('/api/bookings')).status, 200);
  assert.equal((await admin.patch(`/api/admin/users/${x.id}`, { active: false })).status, 200);
  assert.equal((await x.get('/api/bookings')).status, 401);
  assert.equal((await new Client().post('/api/auth/login', { email: 'tmp@a.test', password: PW })).status, 401);
});

// ---------- 2. Entrées hostiles : jamais de 500
const JUNK = [null, true, 0, -1, 1.5, 1e99, '', 'x'.repeat(5000), [], {}, [1], { a: 1 }, "'; DROP TABLE users;--", '<script>alert(1)</script>', '\u0000', '2026-13-45', 'NaN', '9'.repeat(400)];
const SPECS = () => [
  ['POST', '/api/bookings', { vehicleId: 'p4', start: iso(7000), end: iso(7024), options: [] }],
  ['POST', `/api/bookings/${REF}/pickup`, { odometerKm: 10, fuelLevel: 50, notes: 'n' }], ['POST', `/api/bookings/${REF}/return`, { odometerKm: 10, fuelLevel: 50 }],
  ['POST', `/api/admin/bookings/${REF}/payments`, { kind: 'payment', amountCents: 100, method: 'manual' }],
  ['POST', '/api/admin/vehicles', veh('fz')], ['PATCH', '/api/admin/vehicles/p2', { name: 'N', dailyPriceCents: 5100, status: 'active', color: '#112233' }],
  ['POST', '/api/admin/vehicles/p3/unavailabilities', { start: iso(8000), end: iso(8024), reason: 'r' }],
  ['POST', '/api/incidents', { vehicleId: 'p1', bookingRef: REF, category: 'other', severity: 'low', description: 'desc' }],
  ['POST', '/api/admin/users', { email: 'f@a.test', password: PW, role: 'employee', firstName: 'a', lastName: 'b' }], ['PATCH', '/api/admin/users/999999', { active: true }],
  ['POST', '/api/auth/register', { email: 'g@a.test', password: PW, firstName: 'a', lastName: 'b' }],
];
test('robustesse : aucun champ de type inattendu ne provoque d\'erreur 500', async () => {
  const bad = []; let n = 0;
  for (const [m, p, tpl] of SPECS()) {
    const c = p.includes('/auth/') ? anon : admin;
    for (const f of Object.keys(tpl)) for (const j of JUNK) {
      const res = await c.call(m, p, { ...tpl, [f]: j }); n++;
      if (res.status >= 500) bad.push(`${m} ${p} ${f}=${JSON.stringify(j)?.slice(0, 30)} -> ${res.status}`);
    }
    for (const body of [[], null, 'str', 42]) { const res = await c.call(m, p, body); n++; if (res.status >= 500) bad.push(`${m} ${p} corps=${JSON.stringify(body)} -> ${res.status}`); }
  }
  assert.ok(n > 600); assert.deepEqual(bad, []);
});
test('robustesse : chemins et paramètres d\'URL malformés', async () => {
  const bad = [];
  for (const u of ['/api/bookings/%E0%A4%A', '/api/vehicles/%00', '/api/vehicles/%', '/api/quote?vehicle=%FF', '/api/quote', '/api/vehicles?from=x&to=y', '/api/bookings?status=%27', '/api/' + 'a'.repeat(5000)]) {
    const res = await admin.get(u); if (res.status >= 500) bad.push(`${u.slice(0, 40)} -> ${res.status}`);
  }
  const mal = await admin.call('POST', '/api/bookings', '{"vehicleId":', { 'content-type': 'application/json' }, true); if (mal.status !== 400) bad.push(`JSON invalide -> ${mal.status}`);
  assert.deepEqual(bad, []);
});
test('robustesse : requête d\'écriture sans en-tête JSON refusée (défense CSRF en profondeur)', async () => {
  const res = await alice.call('POST', '/api/bookings', Buffer.from(JSON.stringify({ vehicleId: 'p4', start: iso(9000), end: iso(9024) })), {}, true);
  assert.equal(res.status, 415);
});

// ---------- 3. Règles métier : réservations et paiements
test('conflits : contenu, contenant, identique, bout à bout, autre véhicule', async () => {
  const b = (c, v, s, e) => c.post('/api/bookings', { vehicleId: v, start: iso(s), end: iso(e) });
  assert.equal((await b(alice, 'p1', 100, 200)).status, 201);
  for (const [s, e] of [[100, 200], [120, 150], [50, 300], [90, 101], [199, 260]]) assert.equal((await b(bob, 'p1', s, e)).status, 409, `${s}-${e}`);
  assert.equal((await b(bob, 'p1', 200, 260)).status, 201); assert.equal((await b(bob, 'p1', 40, 100)).status, 201);
  assert.equal((await b(bob, 'p2', 100, 200)).status, 201);
});
test('charge : 300 demandes concurrentes aléatoires, zéro chevauchement en base', async () => {
  const users = []; for (let i = 0; i < 12; i++) users.push(await mkUser('client', `u${i}@a.test`));
  const jobs = []; let seed = 42; const rnd = () => (seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296;
  for (let i = 0; i < 300; i++) { const s = 10000 + Math.floor(rnd() * 240), len = 6 + Math.floor(rnd() * 72); jobs.push([users[i % 12], 'p' + (3 + Math.floor(rnd() * 3)), s, s + len]); }
  const res = []; for (let i = 0; i < jobs.length; i += 30) res.push(...await Promise.all(jobs.slice(i, i + 30).map(([c, v, s, e]) => c.post('/api/bookings', { vehicleId: v, start: iso(s), end: iso(e) }))));
  assert.ok(res.every((r) => [201, 409].includes(r.status)), 'statuts inattendus : ' + [...new Set(res.map((r) => r.status))]);
  const ok = res.filter((r) => r.status === 201).length; assert.ok(ok > 10 && ok < 300);
  const dup = await db.get(`SELECT COUNT(*) c FROM bookings a JOIN bookings b ON a.vehicle_id=b.vehicle_id AND a.id<b.id WHERE a.status IN ('pending','confirmed','active') AND b.status IN ('pending','confirmed','active') AND a.start_at<b.end_at AND b.start_at<a.end_at`);
  assert.equal(Number(dup.c), 0);
});
test('anti-accaparement : le nombre de demandes en attente par client est plafonné', async () => {
  delete process.env.MAX_PENDING_PER_USER;
  const c = await mkUser('client', 'hoard@a.test'); const out = [];
  for (let i = 0; i < 6; i++) out.push((await c.post('/api/bookings', { vehicleId: 'p3', start: iso(20000 + i * 100), end: iso(20024 + i * 100) })).status);
  process.env.MAX_PENDING_PER_USER = '1000';
  assert.equal(out.filter((s) => s === 201).length, 3); assert.ok(out.slice(3).every((s) => s === 429 || s === 409));
});
test('paiements : pas de sur-encaissement, remboursement plafonné au montant encaissé', async () => {
  const r = (await alice.post('/api/bookings', { vehicleId: 'p5', start: iso(30000), end: iso(30024) })).body; // total 5000
  assert.equal((await admin.post(`/api/admin/bookings/${r.ref}/payments`, { kind: 'payment', amountCents: 5001 })).status, 409);
  assert.equal((await admin.post(`/api/admin/bookings/${r.ref}/payments`, { kind: 'payment', amountCents: 3000 })).status, 200);
  assert.equal((await admin.post(`/api/admin/bookings/${r.ref}/payments`, { kind: 'payment', amountCents: 2001 })).status, 409);
  assert.equal((await admin.post(`/api/admin/bookings/${r.ref}/payments`, { kind: 'refund', amountCents: 3001 })).status, 409);
});
test('dates : recherche et devis refusent les plages invalides ou hors limites', async () => {
  assert.equal((await anon.get(`/api/vehicles?from=${iso(50)}&to=${iso(10)}`)).status, 400);
  assert.equal((await anon.get(`/api/quote?vehicle=p1&from=${iso(50)}&to=${iso(50)}`)).status, 400);
  assert.equal((await anon.get(`/api/quote?vehicle=p1&from=${iso(50)}&to=${iso(50 + 24 * 61)}`)).status, 400); // mêmes limites que la réservation
});

// ---------- 4. Calculs tarifaires
test('tarification : propriétés sur 3000 cas aléatoires + frontières exactes', () => {
  let seed = 7; const rnd = () => (seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648;
  const OPT = { ass: 1400, sie: 500, cdr: 800 };
  for (let i = 0; i < 3000; i++) {
    const daily = 1000 + Math.floor(rnd() * 99000), ms = 1 + Math.floor(rnd() * 59 * 864e5), t0 = Date.parse('2026-10-11T10:00:00Z');
    const ids = Object.keys(OPT).filter(() => rnd() < 0.5), q = quote({ dailyCents: daily, depositCents: 0, start: new Date(t0).toISOString(), end: new Date(t0 + ms).toISOString(), options: ids });
    const days = Math.ceil(ms / 864e5), base = days * daily, disc = days >= 7 ? Math.floor((base + 5) / 10) : 0, opt = ids.reduce((s, k) => s + OPT[k] * days, 0), total = base - disc + opt;
    assert.deepEqual([q.days, q.baseCents, q.discountCents, q.optionsCents, q.totalCents], [days, base, disc, opt, total]);
    assert.equal(q.vatCents, total - Math.floor((5 * total + 3) / 6)); // arrondi demi-supérieur en arithmétique entière
    assert.ok(Number.isInteger(q.totalCents) && q.totalCents > 0 && q.vatCents >= 0 && q.vatCents < q.totalCents);
  }
  const d = (ms) => quote({ dailyCents: 1000, depositCents: 0, start: '2026-01-01T10:00:00.000Z', end: new Date(Date.parse('2026-01-01T10:00:00.000Z') + ms).toISOString() }).days;
  assert.deepEqual([d(864e5), d(864e5 + 1), d(7 * 864e5)], [1, 2, 7]);
});
test('tarification : l\'arrondi flottant ne diverge jamais de l\'arithmétique entière (TVA et remise, exhaustif)', () => {
  const bad = [];
  for (let t = 1; t <= 400000; t++) {
    if (t - Math.round(t / 1.2) !== t - Math.floor((5 * t + 3) / 6)) bad.push(['tva', t]);
    if (Math.round(t * 0.1) !== Math.floor((t + 5) / 10)) bad.push(['remise', t]);
    if (bad.length > 5) break;
  }
  assert.deepEqual(bad, []);
});

// ---------- 5. Sécurité HTTP et données
test('sécurité : en-têtes, cookie Secure + HSTS en production, aucun secret ni stack dans les réponses', async () => {
  const r = await anon.get('/api/options');
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff'); assert.equal(r.headers.get('x-frame-options'), 'DENY'); assert.match(r.headers.get('content-security-policy'), /frame-ancestors 'none'/);
  const dev = await new Client().post('/api/auth/login', { email: 'ali@a.test', password: PW }); assert.ok(!/secure/i.test(dev.headers.get('set-cookie')));
  process.env.NODE_ENV = 'production';
  try {
    const p = await new Client().post('/api/auth/login', { email: 'ali@a.test', password: PW });
    assert.match(p.headers.get('set-cookie'), /HttpOnly/); assert.match(p.headers.get('set-cookie'), /Secure/); assert.match(p.headers.get('set-cookie'), /SameSite=Lax/);
    assert.ok(p.headers.get('strict-transport-security'));
  } finally { delete process.env.NODE_ENV; }
  const err = await anon.get('/api/bookings/%E0%A4%A'); assert.ok(!/at .*\.js|node_modules|SQLITE|SELECT /i.test(err.text));
  const dump = JSON.stringify(await db.all('SELECT * FROM users')); assert.ok(!dump.includes(PW));
  assert.ok(!(await db.all('SELECT token_hash FROM sessions')).some((s) => s.token_hash.length !== 64));
});
test('sécurité : la connexion réussie ne consomme pas le quota d\'échecs ; les échecs, si', async () => {
  const c = new Client(); for (let i = 0; i < 8; i++) assert.equal((await c.post('/api/auth/login', { email: 'bob@a.test', password: PW })).status, 200, `connexion ${i + 1}`);
  let last; for (let i = 0; i < 7; i++) last = await new Client().post('/api/auth/login', { email: 'bob@a.test', password: 'faux-mot-de-passe' });
  assert.equal(last.status, 429);
});
test('sécurité : PATCH utilisateur exige un booléen explicite et un identifiant numérique', async () => {
  const x = await mkUser('client', 'keep@a.test');
  assert.equal((await admin.patch(`/api/admin/users/${x.id}`, {})).status, 400);
  assert.equal((await admin.patch('/api/admin/users/abc', { active: false })).status, 400);
  assert.equal((await x.get('/api/bookings')).status, 200); // toujours actif
});
test('journal d\'audit : les actions sensibles sont tracées', async () => {
  const rb = (await alice.post('/api/bookings', { vehicleId: 'p5', start: iso(40000), end: iso(40024) })).body; assert.equal((await admin.post(`/api/admin/bookings/${rb.ref}/confirm`)).status, 200);
  for (const a of ['vehicle.create', 'user.active', 'booking.confirm', 'auth.login', 'auth.login_failed']) assert.ok((await admin.get(`/api/admin/audit?action=${a}`)).body.length > 0, `manque ${a}`);
  const page = (await admin.get('/api/admin/audit?limit=5')).body; assert.equal(page.length, 5);
  assert.ok((await admin.get(`/api/admin/audit?limit=5&before=${page[4].id}`)).body.every((x) => x.id < page[4].id));
});

test('défense en profondeur : balisage HTML refusé dans les noms (inscription, véhicule)', async () => {
  process.env.TRUST_PROXY = '1'; // IP distincte (la limite d'inscriptions par IP est déjà consommée par le test de robustesse) ; exerce aussi TRUST_PROXY
  try {
    const r = await new Client().call('POST', '/api/auth/register', { email: 'm1@a.test', password: PW, firstName: '<img src=x onerror=alert(1)>', lastName: 'X' }, { 'x-forwarded-for': '203.0.113.9' });
    assert.equal(r.status, 400); assert.equal(r.body.error, 'invalid_name');
  } finally { delete process.env.TRUST_PROXY; }
  assert.equal((await admin.post('/api/admin/vehicles', { ...veh('mk'), name: 'Auto <script>' })).status, 400);
});
