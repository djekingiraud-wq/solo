// Paiement Stripe — vérifié contre un FAUX Stripe local et des signatures calculées selon la spécification.
// Ce test ne prouve PAS le bon fonctionnement avec le vrai Stripe (voir READINESS.md).
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import crypto from 'node:crypto';
import { openDb, migrate } from '../src/db.js';
import { createApp } from '../src/server.js';
import { hashPassword } from '../src/auth.js';
import { verifyStripeSignature } from '../src/stripe.js';

process.env.MAX_PENDING_PER_USER = '1000';
const SECRET = 'whsec_testsecret0123456789', KEY = 'sk_test_0123456789abcdef';
const T0 = Date.now(), iso = (h) => new Date(T0 + h * 3600e3).toISOString();
let db, server, base, fake, fakeCalls = [], fakeStatus = 200, admin, alice, bob, n = 0;

class Client {
  constructor() { this.cookie = ''; }
  async call(m, u, b, h = {}) { const r = await fetch(base + u, { method: m, headers: { 'content-type': 'application/json', cookie: this.cookie, ...h }, body: b === undefined ? undefined : JSON.stringify(b) }); const sc = r.headers.get('set-cookie'); if (sc) this.cookie = sc.split(';')[0]; return { status: r.status, body: await r.json().catch(() => null) }; }
  get(u) { return this.call('GET', u); } post(u, b = {}) { return this.call('POST', u, b); }
}
async function mk(role, email) { await db.run(`INSERT INTO users(email,password_hash,first_name,last_name,role,active,created_at) VALUES(?,?,?,?,?,1,?)`, [email, await hashPassword('correct-horse-battery'), 'T', role, role, new Date().toISOString()]); const c = new Client(); await c.post('/api/auth/login', { email, password: 'correct-horse-battery' }); return c; }
const sign = (body, secret = SECRET, t = Math.floor(Date.now() / 1000)) => `t=${t},v1=${crypto.createHmac('sha256', secret).update(`${t}.${body}`).digest('hex')}`;
const hook = async (event, headers) => { const body = JSON.stringify(event); const r = await fetch(base + '/api/webhooks/stripe', { method: 'POST', headers: { 'content-type': 'application/json', 'stripe-signature': sign(body), ...headers }, body }); return { status: r.status, body: await r.json().catch(() => null) }; };
const session = (ref, amount, extra = {}) => ({ id: 'cs_' + ++n, payment_intent: 'pi_' + n, client_reference_id: ref, payment_status: 'paid', amount_total: amount, currency: 'eur', ...extra });
const completed = (s, id = 'evt_' + ++n) => ({ id, type: 'checkout.session.completed', data: { object: s } });
async function confirmedBooking(vehicle = 'v' + ++n) {
  await admin.post('/api/admin/vehicles', { id: vehicle, plate: vehicle.toUpperCase() + '-1', name: 'Auto ' + vehicle, category: 'Citadine', bodyType: 'cit', seats: 5, fuel: 'Essence', transmission: 'Manuelle', dailyPriceCents: 5000, depositCents: 0 });
  const b = (await alice.post('/api/bookings', { vehicleId: vehicle, start: iso(100 + n * 50), end: iso(124 + n * 50) })).body; await admin.post(`/api/admin/bookings/${b.ref}/confirm`); return b.ref;
}
const paid = async (ref) => (await alice.get(`/api/bookings/${ref}`)).body.paidCents;

before(async () => {
  fake = http.createServer((req, res) => { let d = ''; req.on('data', (c) => (d += c)); req.on('end', () => { fakeCalls.push({ url: req.url, headers: req.headers, form: new URLSearchParams(d) }); res.writeHead(fakeStatus, { 'content-type': 'application/json' }); res.end(JSON.stringify(fakeStatus === 200 ? { id: 'cs_test_fake', url: 'https://checkout.stripe.test/pay/cs_test_fake' } : { error: { type: 'invalid_request_error', message: 'secret details' } })); }); });
  await new Promise((r) => fake.listen(0, r));
  Object.assign(process.env, { PAYMENTS_MODE: 'stripe', STRIPE_SECRET_KEY: KEY, STRIPE_WEBHOOK_SECRET: SECRET, PUBLIC_URL: 'https://soloc.test', STRIPE_API_BASE: `http://127.0.0.1:${fake.address().port}` });
  db = await openDb({ SQLITE_FILE: ':memory:' }); await migrate(db);
  server = createApp(db); await new Promise((r) => server.listen(0, r)); base = `http://127.0.0.1:${server.address().port}`;
  admin = await mk('admin', 'a@p.test'); alice = await mk('client', 'al@p.test'); bob = await mk('client', 'bo@p.test');
});
after(async () => { server.close(); fake.close(); await db.close(); for (const k of ['PAYMENTS_MODE', 'STRIPE_SECRET_KEY', 'STRIPE_WEBHOOK_SECRET', 'PUBLIC_URL', 'STRIPE_API_BASE']) delete process.env[k]; });

test('signature : algorithme conforme (valide, falsifiée, mauvais secret, ancienne, absente, plusieurs v1)', () => {
  const body = '{"id":"evt_1"}', t = 1_700_000_000, now = t * 1000, mkh = (s) => `t=${t},v1=${crypto.createHmac('sha256', s).update(`${t}.${body}`).digest('hex')}`;
  assert.equal(verifyStripeSignature(body, mkh(SECRET), SECRET, { nowMs: now }), true);
  assert.equal(verifyStripeSignature(body + ' ', mkh(SECRET), SECRET, { nowMs: now }), false);
  assert.equal(verifyStripeSignature(body, mkh('whsec_autre'), SECRET, { nowMs: now }), false);
  assert.equal(verifyStripeSignature(body, mkh(SECRET), SECRET, { nowMs: now + 301_000 }), false);
  assert.equal(verifyStripeSignature(body, mkh(SECRET), SECRET, { nowMs: now - 301_000 }), false);
  assert.equal(verifyStripeSignature(body, undefined, SECRET), false); assert.equal(verifyStripeSignature(body, 'garbage', SECRET), false);
  assert.equal(verifyStripeSignature(body, `${mkh('x')},v1=${mkh(SECRET).split('v1=')[1]}`, SECRET, { nowMs: now }), true);
});

test('config publique : onlinePayment reflète la configuration', async () => {
  assert.equal((await new Client().get('/api/config')).body.onlinePayment, true);
});

test('checkout : le montant vient de la base (jamais du client), propriétaire seulement, réservation confirmée seulement', async () => {
  const ref = await confirmedBooking(); fakeCalls = [];
  const r = await alice.post(`/api/bookings/${ref}/checkout`, { amountCents: 1, totalCents: 1, currency: 'usd' });
  assert.equal(r.status, 200); assert.equal(r.body.url, 'https://checkout.stripe.test/pay/cs_test_fake');
  const c = fakeCalls[0]; assert.equal(c.url, '/v1/checkout/sessions'); assert.equal(c.headers.authorization, `Bearer ${KEY}`);
  assert.equal(c.form.get('line_items[0][price_data][unit_amount]'), '5000'); assert.equal(c.form.get('line_items[0][price_data][currency]'), 'eur');
  assert.equal(c.form.get('client_reference_id'), ref); assert.equal(c.form.get('metadata[booking_ref]'), ref); assert.equal(c.form.get('customer_email'), 'al@p.test');
  assert.equal(c.form.get('success_url'), 'https://soloc.test/#/compte'); assert.ok(c.headers['idempotency-key']);
  assert.equal(await paid(ref), 0); // la redirection / la création de session ne marque RIEN comme payé
  assert.equal((await bob.post(`/api/bookings/${ref}/checkout`)).status, 404);
  assert.equal((await new Client().post(`/api/bookings/${ref}/checkout`)).status, 401);
  const pend = (await alice.post('/api/bookings', { vehicleId: 'v1', start: iso(9000), end: iso(9024) })).body.ref;
  assert.equal((await alice.post(`/api/bookings/${pend}/checkout`)).status, 409); // non confirmée
  await admin.post(`/api/admin/bookings/${ref}/payments`, { kind: 'payment', amountCents: 2000 }); fakeCalls = [];
  assert.equal((await alice.post(`/api/bookings/${ref}/checkout`)).status, 200); assert.equal(fakeCalls[0].form.get('line_items[0][price_data][unit_amount]'), '3000'); // solde restant
  await admin.post(`/api/admin/bookings/${ref}/payments`, { kind: 'payment', amountCents: 3000 });
  assert.equal((await alice.post(`/api/bookings/${ref}/checkout`)).status, 409); // déjà réglée
});

test('checkout : erreur du prestataire => 502 sans fuite de détail ; prestataire injoignable => 502', async () => {
  const ref = await confirmedBooking(); fakeStatus = 400;
  const r = await alice.post(`/api/bookings/${ref}/checkout`); fakeStatus = 200;
  assert.equal(r.status, 502); assert.ok(!JSON.stringify(r.body).includes('secret details'));
  const real = process.env.STRIPE_API_BASE; process.env.STRIPE_API_BASE = 'http://127.0.0.1:1';
  try { assert.equal((await alice.post(`/api/bookings/${ref}/checkout`)).status, 502); } finally { process.env.STRIPE_API_BASE = real; }
});

test('webhook : signature obligatoire et corps non altéré', async () => {
  const ref = await confirmedBooking(), ev = JSON.stringify(completed(session(ref, 5000)));
  const post = (headers, body = ev) => fetch(base + '/api/webhooks/stripe', { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body }).then((r) => r.status);
  assert.equal(await post({}), 400); assert.equal(await post({ 'stripe-signature': 'garbage' }), 400);
  assert.equal(await post({ 'stripe-signature': sign(ev, 'whsec_pirate_pirate_pirate') }), 400);
  assert.equal(await post({ 'stripe-signature': sign(ev, SECRET, Math.floor(Date.now() / 1000) - 3600) }), 400); // rejeu d'un vieil événement signé
  assert.equal(await post({ 'stripe-signature': sign(ev) }, ev.replace('5000', '1')), 400); // corps modifié après signature
  assert.equal(await paid(ref), 0);
  assert.equal(await post({ 'stripe-signature': sign(ev) }), 200); assert.equal(await paid(ref), 5000);
});

test('webhook : seul un événement signé marque la réservation payée ; rejeu et doublons sans effet', async () => {
  const ref = await confirmedBooking(), s = session(ref, 5000), ev = completed(s);
  assert.deepEqual((await hook(ev)).body, { received: true, handled: true }); assert.equal(await paid(ref), 5000);
  assert.equal((await hook(ev)).body.reason, 'duplicate');                                                    // même événement rejoué
  assert.equal((await hook(completed(s))).body.reason, 'duplicate');                                          // autre événement, même paiement
  assert.equal((await hook({ ...completed(s), type: 'checkout.session.async_payment_succeeded' })).body.reason, 'duplicate');
  assert.equal(await paid(ref), 5000);
  const m = (await db.get(`SELECT method,provider_ref FROM payments WHERE booking_id=(SELECT id FROM bookings WHERE ref=?)`, [ref])); assert.equal(m.method, 'stripe'); assert.equal(m.provider_ref, s.payment_intent);
});

test('webhook : cas limites (non payé, réservation inconnue, devise ou montant anormal, type ignoré, trop-perçu)', async () => {
  const ref = await confirmedBooking();
  assert.equal((await hook(completed(session(ref, 5000, { payment_status: 'unpaid' })))).body.reason, 'not_paid');
  assert.equal((await hook(completed(session('SL-INCONNU', 5000)))).body.reason, 'unknown_booking');
  assert.equal((await hook(completed(session(ref, 5000, { currency: 'usd' })))).body.reason, 'anomaly');
  assert.equal((await hook(completed(session(ref, -5)))).body.reason, 'anomaly');
  assert.equal((await hook({ id: 'evt_x' + n++, type: 'customer.created', data: { object: {} } })).body.reason, 'ignored_type');
  assert.equal(await paid(ref), 0);
  assert.equal((await hook(completed(session(ref, 6000)))).body.handled, true);                              // argent encaissé : enregistré tel quel…
  assert.equal(await paid(ref), 6000);
  assert.ok((await admin.get('/api/admin/audit?action=payment.overpaid')).body.length >= 1);                 // …et signalé pour remboursement manuel
  assert.ok((await admin.get('/api/admin/audit?action=payment.orphan')).body.length >= 1);
  assert.ok((await admin.get('/api/admin/audit?action=payment.anomaly')).body.length >= 2);
});

test('webhook : remboursements Stripe enregistrés une seule fois, par différence cumulée', async () => {
  const ref = await confirmedBooking(), s = session(ref, 5000); await hook(completed(s));
  const refund = (cum) => hook({ id: 'evt_r' + ++n, type: 'charge.refunded', data: { object: { id: 'ch_1', payment_intent: s.payment_intent, amount_refunded: cum } } });
  assert.equal((await refund(2000)).body.handled, true); assert.equal(await paid(ref), 3000);
  assert.equal((await refund(2000)).body.reason, 'nothing_to_record'); assert.equal(await paid(ref), 3000);
  assert.equal((await refund(5000)).body.handled, true); assert.equal(await paid(ref), 0);
  assert.equal((await hook({ id: 'evt_r' + ++n, type: 'charge.refunded', data: { object: { id: 'ch_2', payment_intent: 'pi_inconnu', amount_refunded: 100 } } })).body.reason, 'unknown_payment');
});

test('paiement désactivé : checkout et webhook répondent 503, aucun appel sortant', async () => {
  const saved = process.env.PAYMENTS_MODE; process.env.PAYMENTS_MODE = 'off'; fakeCalls = [];
  try {
    const ref = await confirmedBooking();
    assert.equal((await alice.post(`/api/bookings/${ref}/checkout`)).status, 503); assert.equal((await new Client().get('/api/config')).body.onlinePayment, false);
    assert.equal((await hook(completed(session(ref, 5000)))).status, 503); assert.equal(fakeCalls.length, 0);
  } finally { process.env.PAYMENTS_MODE = saved; }
});
