"""Parcours de paiement dans Chromium contre un FAUX Stripe local (le vrai Stripe n'est jamais contacté).
Vérifie : bouton visible seulement si le paiement est activé, redirection vers la page du prestataire, réservation
toujours non payée après la redirection, payée uniquement après un webhook signé."""
import hashlib, hmac, json, os, re, subprocess, sys, threading, time, urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')); SECRET = 'whsec_browsertest0123456789'
res = []; check = lambda n, ok, d='': res.append(('OK' if ok else 'ÉCHEC', n, d))
class Fake(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_POST(self):
        self.rfile.read(int(self.headers.get('content-length', 0))); self.send_response(200); self.send_header('content-type', 'application/json'); self.end_headers()
        self.wfile.write(json.dumps({'id': 'cs_test_b', 'url': f'http://127.0.0.1:{FP}/pay/cs_test_b'}).encode())
    def do_GET(self): self.send_response(200); self.send_header('content-type', 'text/html'); self.end_headers(); self.wfile.write(b'<h1>Page de paiement du prestataire (simulee)</h1>')
fake = HTTPServer(('127.0.0.1', 0), Fake); FP = fake.server_address[1]; threading.Thread(target=fake.serve_forever, daemon=True).start()

def start(port, pay):
    db = f'/tmp/pay_{port}.db'
    for e in ('', '-wal', '-shm'):
        try: os.remove(db + e)
        except FileNotFoundError: pass
    env = {**os.environ, 'SQLITE_FILE': db, 'PORT': str(port), 'MAX_PENDING_PER_USER': '50', 'PUBLIC_URL': f'http://127.0.0.1:{port}',
           **({'PAYMENTS_MODE': 'stripe', 'STRIPE_SECRET_KEY': 'sk_test_0123456789abcdef', 'STRIPE_WEBHOOK_SECRET': SECRET, 'STRIPE_API_BASE': f'http://127.0.0.1:{FP}'} if pay else {})}
    seed = subprocess.run(['node', 'src/seed.js'], cwd=ROOT, env=env, capture_output=True, text=True).stdout
    pw = {m.group(1): m.group(3) for m in re.finditer(r'^(admin|employee|client)\s+(\S+)\s+mot de passe : (\S+)', seed, re.M)}
    p = subprocess.Popen(['node', 'src/server.js'], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(40):
        try: urllib.request.urlopen(f'http://127.0.0.1:{port}/healthz'); break
        except Exception: time.sleep(0.15)
    return p, pw

def api(base, method, path, body=None, cookie=None, headers=None):
    req = urllib.request.Request(base + path, method=method, data=json.dumps(body).encode() if body is not None else None, headers={'content-type': 'application/json', **({'cookie': cookie} if cookie else {}), **(headers or {})})
    with urllib.request.urlopen(req) as r: return json.loads(r.read() or 'null'), r.headers.get('set-cookie', '').split(';')[0]

def scenario(port, pay):
    base = f'http://127.0.0.1:{port}'; srv, pw = start(port, pay)
    try:
        _, ca = api(base, 'POST', '/api/auth/login', {'email': 'admin@soloc.test', 'password': pw['admin']})
        _, cc = api(base, 'POST', '/api/auth/login', {'email': 'client@soloc.test', 'password': pw['client']})
        s = time.strftime('%Y-%m-%dT10:00:00.000Z', time.gmtime(time.time() + 86400 * 30)); e = time.strftime('%Y-%m-%dT10:00:00.000Z', time.gmtime(time.time() + 86400 * 32))
        b, _ = api(base, 'POST', '/api/bookings', {'vehicleId': 'ci', 'start': s, 'end': e}, cc); ref = b['ref']
        with sync_playwright() as p:
            br = p.chromium.launch(); pg = br.new_page(viewport={'width': 390, 'height': 844})
            pg.goto(base + '/#/connexion'); pg.fill('#le', 'client@soloc.test'); pg.fill('#lp', pw['client']); pg.click('button[type=submit]'); pg.wait_for_timeout(600)
            pg.goto(base + '/#/compte'); pg.wait_for_timeout(600)
            row = lambda: pg.locator('tr', has_text=ref).locator('button:has-text("Payer")')
            check(f'[paiement={"on" if pay else "off"}] pas de bouton Payer tant que la réservation n’est pas confirmée', row().count() == 0)
            api(base, 'POST', f'/api/admin/bookings/{ref}/confirm', {}, ca); pg.goto(base + '/#/connexion'); pg.goto(base + '/#/compte'); pg.reload(); pg.wait_for_timeout(700)
            btn = row()
            if not pay:
                check('[paiement=off] aucun bouton Payer sur une réservation confirmée', btn.count() == 0); br.close(); return
            check('[paiement=on] bouton « Payer … » affiché sur une réservation confirmée', btn.count() == 1, btn.first.inner_text() if btn.count() else '')
            with pg.expect_navigation(url=re.compile('/pay/cs_test_b')): btn.click()
            check('redirection vers la page de paiement du prestataire', 'cs_test_b' in pg.url and 'prestataire' in pg.inner_text('body'))
            mine, _ = api(base, 'GET', f'/api/bookings/{ref}', cookie=cc)
            check('après la redirection, la réservation n’est PAS marquée payée', mine['paidCents'] == 0, str(mine['paidCents']))
            ev = json.dumps({'id': 'evt_b1', 'type': 'checkout.session.completed', 'data': {'object': {'id': 'cs_test_b', 'payment_intent': 'pi_b1', 'client_reference_id': ref, 'payment_status': 'paid', 'amount_total': mine['totalCents'], 'currency': 'eur'}}})
            t = str(int(time.time())); sig = hmac.new(SECRET.encode(), f'{t}.{ev}'.encode(), hashlib.sha256).hexdigest()
            try: api(base, 'POST', '/api/webhooks/stripe', json.loads(ev), headers={'stripe-signature': f't={t},v1=deadbeef'}); bad = 200
            except urllib.error.HTTPError as ex: bad = ex.code
            check('webhook avec fausse signature refusé (400)', bad == 400)
            req = urllib.request.Request(base + '/api/webhooks/stripe', data=ev.encode(), method='POST', headers={'content-type': 'application/json', 'stripe-signature': f't={t},v1={sig}'}); ok = urllib.request.urlopen(req).status
            mine, _ = api(base, 'GET', f'/api/bookings/{ref}', cookie=cc)
            check('webhook signé accepté : la réservation est payée', ok == 200 and mine['paidCents'] == mine['totalCents'], f"{mine['paidCents']}/{mine['totalCents']}")
            pg.goto(base + '/#/compte'); pg.reload(); pg.wait_for_timeout(700)
            check('le bouton Payer disparaît une fois la réservation réglée', row().count() == 0)
            br.close()
    finally: srv.terminate()

try: scenario(3231, True); scenario(3232, False)
finally: fake.shutdown()
for s, n, d in res: print(f'{s:6} {n}' + (f'  -> {d}' if d and s != 'OK' else ''))
ok = sum(1 for s, _, _ in res if s == 'OK'); print(f'\nTOTAL {ok}/{len(res)} OK'); sys.exit(0 if ok == len(res) else 1)
