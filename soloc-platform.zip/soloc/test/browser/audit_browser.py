"""Audit navigateur (Chromium via Playwright) : parcours, XSS, responsive, tactile, clavier.
Usage : python3 test/browser/audit_browser.py   (démarre sa propre instance du serveur sur une base temporaire)"""
import json, os, re, subprocess, sys, time, urllib.request
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
PORT = 3222; BASE = f'http://127.0.0.1:{PORT}'
DB = '/tmp/audit_browser.db'
for ext in ('', '-wal', '-shm'):
    try: os.remove(DB + ext)
    except FileNotFoundError: pass
env = {**os.environ, 'SQLITE_FILE': DB, 'PORT': str(PORT), 'MAX_PENDING_PER_USER': '50'}
seed = subprocess.run(['node', 'src/seed.js'], cwd=ROOT, env=env, capture_output=True, text=True).stdout
pw = {m.group(1): m.group(3) for m in re.finditer(r'^(admin|employee|client)\s+(\S+)\s+mot de passe : (\S+)', seed, re.M)}
srv = subprocess.Popen(['node', 'src/server.js'], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for _ in range(40):
    try: urllib.request.urlopen(BASE + '/api/options'); break
    except Exception: time.sleep(0.15)

results = []  # (statut, nom, détail)
def check(name, ok, detail=''): results.append(('OK' if ok else 'ÉCHEC', name, detail))

def api(method, path, body=None, cookie=None):
    req = urllib.request.Request(BASE + path, method=method, data=json.dumps(body).encode() if body is not None else None,
                                 headers={'content-type': 'application/json', **({'cookie': cookie} if cookie else {})})
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read() or 'null'), r.headers.get('set-cookie', '').split(';')[0]

XSS = '<img src=x onerror="window.__xss=(window.__xss||0)+1">'
try:
    # --- données hostiles : nom de client et nom de véhicule contenant du HTML
    adm, ck = api('POST', '/api/auth/login', {'email': 'admin@soloc.test', 'password': pw['admin']})
    _, cka = api('POST', '/api/auth/login', {'email': 'admin@soloc.test', 'password': pw['admin']})
    api('POST', '/api/admin/vehicles', {'id': 'xss1', 'plate': 'XS-001-SS', 'name': 'Benin', 'category': 'Citadine', 'bodyType': 'cit', 'seats': 4, 'fuel': 'Essence', 'transmission': 'Manuelle', 'dailyPriceCents': 3000, 'depositCents': 10000}, cka)
    evil, cke = api('POST', '/api/auth/register', {'email': 'evil@x.test', 'password': 'correct-horse-battery', 'firstName': 'Evil', 'lastName': 'User'})
    # données déjà présentes en base (anciennes, importées ou corrompues) : l'affichage doit rester sûr même si l'entrée n'a pas filtré
    import sqlite3
    con = sqlite3.connect(DB); con.execute('UPDATE vehicles SET name=? WHERE id=?', ('Hack ' + XSS, 'xss1')); con.execute('UPDATE users SET first_name=?, last_name=? WHERE email=?', (XSS, '<b onmouseover="window.__xss=99">x</b>', 'evil@x.test')); con.commit(); con.close()
    start = time.strftime('%Y-%m-%dT10:00:00.000Z', time.gmtime(time.time() + 86400 * 20)); end = time.strftime('%Y-%m-%dT10:00:00.000Z', time.gmtime(time.time() + 86400 * 22))
    api('POST', '/api/bookings', {'vehicleId': 'be', 'start': start, 'end': end, 'options': []}, cke)

    with sync_playwright() as p:
        b = p.chromium.launch()
        VPS = {'mobile-360': (360, 740), 'mobile-390': (390, 844), 'tablette-768': (768, 1024), 'bureau-1280': (1280, 800)}

        # ---------- 1. Responsive : débordement horizontal, erreurs console, tactile
        for name, (w, h) in VPS.items():
            ctx = b.new_context(viewport={'width': w, 'height': h}, has_touch=w < 800, is_mobile=w < 800)
            pg = ctx.new_page(); errs = []
            pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'fonts.g' not in m.text and 'ERR_' not in m.text and 'Failed to load resource' not in m.text else None)
            routes = ['#/', '#/catalogue', '#/vehicule/be', '#/reserver/be', '#/connexion']
            for r in routes:
                pg.goto(BASE + '/' + r); pg.wait_for_timeout(350)
                ov = pg.evaluate('document.documentElement.scrollWidth - document.documentElement.clientWidth')
                check(f'[{name}] pas de débordement horizontal {r}', ov <= 1, f'dépassement {ov}px')
            pg.goto(BASE + '/#/'); pg.wait_for_timeout(350); pg.screenshot(path=f'/tmp/shots/{name}-home.png')
            pg.goto(BASE + '/#/catalogue'); pg.wait_for_timeout(350); pg.screenshot(path=f'/tmp/shots/{name}-catalogue.png')
            # admin
            pg.goto(BASE + '/#/connexion'); pg.wait_for_timeout(250)
            pg.fill('#le', 'admin@soloc.test'); pg.fill('#lp', pw['admin']); pg.click('button[type=submit]'); pg.wait_for_timeout(700)
            pg.goto(BASE + '/#/admin'); pg.wait_for_timeout(700)
            ov = pg.evaluate('document.documentElement.scrollWidth - document.documentElement.clientWidth')
            check(f'[{name}] pas de débordement horizontal #/admin', ov <= 1, f'dépassement {ov}px')
            pg.screenshot(path=f'/tmp/shots/{name}-admin.png')
            if w < 800:
                small = pg.evaluate("""() => [...document.querySelectorAll('button,a,input,select')].filter(e => e.offsetParent !== null).map(e => { const r = e.getBoundingClientRect(); return {t:(e.innerText||e.id||e.tagName).slice(0,24), w:Math.round(r.width), h:Math.round(r.height)} }).filter(x => x.h < 44 && x.h > 0 && x.t.trim())""")
                check(f'[{name}] zones tactiles >= 44 px (admin)', len(small) == 0, '; '.join(f"{s['t']}({s['h']}px)" for s in small[:6]))
                for r in ['#/catalogue', '#/vehicule/be']:
                    pg.goto(BASE + '/' + r); pg.wait_for_timeout(450)
                    small = pg.evaluate("""() => [...document.querySelectorAll('button,a,input,select')].filter(e => e.offsetParent !== null).map(e => { const r = e.getBoundingClientRect(); return {t:(e.innerText||e.id||e.tagName).slice(0,24), h:Math.round(r.height)} }).filter(x => x.h < 44 && x.h > 0 && x.t.trim())""")
                    check(f'[{name}] zones tactiles >= 44 px ({r})', len(small) == 0, '; '.join(f"{s['t']}({s['h']}px)" for s in small[:6]))
            check(f'[{name}] aucune erreur JavaScript/console', not errs, ' | '.join(errs[:3]))
            ctx.close()

        # ---------- 2. XSS stocké : nom client, nom véhicule (vus par l'admin)
        ctx = b.new_context(viewport={'width': 1280, 'height': 800}); pg = ctx.new_page()
        pg.goto(BASE + '/#/connexion'); pg.fill('#le', 'admin@soloc.test'); pg.fill('#lp', pw['admin']); pg.click('button[type=submit]'); pg.wait_for_timeout(600)
        for r in ['#/admin', '#/catalogue', '#/vehicule/xss1', '#/']:
            pg.goto(BASE + '/' + r); pg.wait_for_timeout(700)
            pg.mouse.move(400, 400)
            for sel in ['table tbody tr td', '.card', '.tlr .n']:
                try: pg.hover(sel, timeout=300)
                except Exception: pass
            injected = pg.evaluate("() => window.__xss || 0")
            nodes = pg.evaluate("() => document.querySelectorAll('#app img[src=x], #app b[onmouseover]').length")
            check(f'XSS : aucun script exécuté ni balise injectée sur {r}', injected == 0 and nodes == 0, f'__xss={injected}, balises injectées={nodes}')
        ctx.close()

        # ---------- 3. Parcours client complet (inscription dans le tunnel, réservation, suivi, annulation)
        ctx = b.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True); pg = ctx.new_page()
        pg.on('dialog', lambda d: d.accept())
        pg.goto(BASE + '/#/catalogue'); pg.wait_for_timeout(500)
        n_cards = pg.locator('a.card').count(); check('client : le catalogue affiche les véhicules', n_cards >= 7, f'{n_cards} cartes')
        pg.locator('a.card', has_text='Peugeot 508').click(); pg.wait_for_timeout(500)
        pg.click('text=Réserver ce véhicule'); pg.wait_for_timeout(400)
        pg.locator('label.opt', has_text='Assurance').click(); pg.wait_for_timeout(500)
        total_txt = pg.locator('.sum.t').inner_text(); check('client : le récapitulatif affiche un total serveur', '€' in total_txt, total_txt.replace('\n', ' '))
        pg.click('text=Continuer'); pg.wait_for_timeout(300)
        pg.click('text=Envoyer la demande de réservation'); pg.wait_for_timeout(300)
        errs_vis = pg.locator('.err').all_inner_texts()
        check('client : validation des champs obligatoires (messages d’erreur)', any('prénom' in e.lower() for e in errs_vis) and any('mot de passe' in e.lower() or '10' in e for e in errs_vis), ' / '.join(e for e in errs_vis if e))
        pg.fill('#fn', 'Léa'); pg.fill('#ln', 'Martin'); pg.fill('#em', 'lea@test.fr'); pg.fill('#pw', 'un-mot-de-passe-long'); pg.check('#cg')
        pg.click('text=Envoyer la demande de réservation'); pg.wait_for_timeout(900)
        body = pg.inner_text('#app'); check('client : confirmation avec référence unique', re.search(r'SL-[0-9A-F]{8}', body) is not None, body[:80].replace('\n', ' '))
        pg.screenshot(path='/tmp/shots/mobile-confirmation.png')
        pg.goto(BASE + '/#/compte'); pg.wait_for_timeout(600)
        check('client : « Mes réservations » liste la demande', 'À confirmer' in pg.inner_text('#app'))
        pg.click('button:has-text("Annuler")'); pg.wait_for_timeout(700)
        check('client : annulation depuis son espace', 'Annulée' in pg.inner_text('#app'))
        check('client : le lien Espace admin est masqué', not pg.locator('nav a[data-r=admin]').is_visible())
        pg.goto(BASE + '/#/admin'); pg.wait_for_timeout(500)
        check('client : #/admin refuse l’accès (page « Connexion requise »)', 'Connexion requise' in pg.inner_text('#app') and 'Tableau de bord' not in pg.inner_text('#app'))
        # double réservation visible dans l'UI : le véhicule retenu par un autre client passe en indisponible
        pg.goto(BASE + '/#/connexion'); pg.fill('#le', 'client@soloc.test'); pg.fill('#lp', pw['client']); pg.click('button[type=submit]'); pg.wait_for_timeout(500)
        ctx.close()

        # ---------- 4. Parcours employé / admin dans le navigateur
        ctx = b.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True); pg = ctx.new_page()
        dialogs = []
        def on_dialog(d):
            dialogs.append(d.message); d.accept('12000' if 'ilom' in d.message else '60' if 'arburant' in d.message else '10')
        pg.on('dialog', on_dialog)
        pg.goto(BASE + '/#/connexion'); pg.fill('#le', 'admin@soloc.test'); pg.fill('#lp', pw['admin']); pg.click('button[type=submit]'); pg.wait_for_timeout(700)
        pg.goto(BASE + '/#/admin'); pg.wait_for_timeout(700)
        txt = pg.inner_text('#app'); check('admin : tableau de bord et indicateurs affichés', 'Tableau de bord' in txt and 'Véhicules actifs' in txt)
        kp = pg.evaluate("() => Object.fromEntries([...document.querySelectorAll('.kpi')].map(k => [k.querySelector('span').innerText, k.querySelector('b').innerText]))")
        dash, _ = api('GET', '/api/admin/dashboard', cookie=cka)
        check('admin : indicateurs de l’écran = indicateurs de l’API', kp.get('Véhicules actifs') == str(dash['activeVehicles']) and kp.get('Réservations à confirmer') == str(dash['toConfirm']), f"écran={kp.get('Véhicules actifs')}/{kp.get('Réservations à confirmer')} api={dash['activeVehicles']}/{dash['toConfirm']}")
        before = dash['toConfirm']
        pg.locator('button:has-text("Confirmer")').first.click(); pg.wait_for_timeout(900)
        dash2, _ = api('GET', '/api/admin/dashboard', cookie=cka)
        check('admin : confirmer une demande met à jour la base et le tableau de bord', dash2['toConfirm'] == before - 1, f'{before} -> {dash2["toConfirm"]}')
        ctx.close()
        ctx = b.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True); pg = ctx.new_page(); pg.on('dialog', on_dialog)
        pg.goto(BASE + '/#/connexion'); pg.fill('#le', 'agent@soloc.test'); pg.fill('#lp', pw['employee']); pg.click('button[type=submit]'); pg.wait_for_timeout(700)
        pg.goto(BASE + '/#/admin'); pg.wait_for_timeout(700)
        txt = pg.inner_text('#app')
        check('employé : voit le tableau de bord sans le chiffre d’affaires', 'Tableau de bord' in txt and 'Encaissé' not in txt)
        check('employé : aucun bouton Confirmer / Refuser / Archiver / Encaisser', not any(x in txt for x in ['Confirmer', 'Refuser', 'Archiver', 'Encaisser']))
        ctx.close()

        # ---------- 5. Clavier et focus
        ctx = b.new_context(viewport={'width': 1280, 'height': 800}); pg = ctx.new_page(); pg.goto(BASE + '/#/'); pg.wait_for_timeout(500)
        seen = set(); visible_focus = 0
        for _ in range(8):
            pg.keyboard.press('Tab')
            info = pg.evaluate("() => { const e=document.activeElement; const s=getComputedStyle(e); return {t:(e.innerText||e.id||e.tagName).slice(0,20), o:s.outlineStyle!=='none' && parseFloat(s.outlineWidth)>0}}")
            seen.add(info['t']); visible_focus += 1 if info['o'] else 0
        check('clavier : 8 tabulations, focus visible sur chaque élément', visible_focus == 8 and len(seen) >= 6, f'{visible_focus}/8 visibles, {len(seen)} éléments distincts')
        ctx.close(); b.close()
finally:
    srv.terminate()

w = max(len(n) for _, n, _ in results)
for s, n, d in results: print(f'{s:6} {n}' + (f'  -> {d}' if d and s != 'OK' else ''))
ok = sum(1 for s, _, _ in results if s == 'OK'); print(f'\nTOTAL {ok}/{len(results)} OK'); sys.exit(0 if ok == len(results) else 1)
