// Build Netlify + comportement du relais /api/* simulé localement.
// ATTENTION : le relais ci-dessous est MA lecture des règles _redirects, pas Netlify lui-même (voir docs/NETLIFY.md : à vérifier sur un aperçu réel).
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { openDb, migrate } from '../src/db.js';
import { createApp } from '../src/server.js';
import { hashPassword } from '../src/auth.js';

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const build = (env) => { const out = fs.mkdtempSync(path.join(os.tmpdir(), 'soloc-nl-')); const r = spawnSync('node', ['scripts/netlify-build.mjs'], { cwd: ROOT, env: { PATH: process.env.PATH, OUT_DIR: out, ...env }, encoding: 'utf8' }); return { ...r, out }; };

test('build : refuse une adresse de backend absente, en HTTP, locale, d\'exemple ou avec « / » final', () => {
  for (const url of [undefined, '', 'http://api.monsite.fr', 'https://api.monsite.fr/', 'https://api.monsite.fr/api', 'https://localhost:3000', 'https://api.soloc.example', 'https://x.example.com']) {
    const r = build({ BACKEND_URL: url }); assert.equal(r.status, 1, String(url)); assert.match(r.stderr, /BUILD NETLIFY REFUSÉ/);
  }
});
test('build : un aperçu ne peut pas pointer sur le backend de production (sauf dérogation explicite)', () => {
  const prod = 'https://api.monsite.fr';
  assert.equal(build({ BACKEND_URL: prod, PRODUCTION_BACKEND_URL: prod, CONTEXT: 'deploy-preview' }).status, 1);
  assert.equal(build({ BACKEND_URL: prod, PRODUCTION_BACKEND_URL: prod, CONTEXT: 'branch-deploy' }).status, 1);
  assert.equal(build({ BACKEND_URL: prod, PRODUCTION_BACKEND_URL: prod, CONTEXT: 'production' }).status, 0);
  assert.equal(build({ BACKEND_URL: 'https://api-staging.monsite.fr', PRODUCTION_BACKEND_URL: prod, CONTEXT: 'deploy-preview' }).status, 0);
  assert.equal(build({ BACKEND_URL: prod, PRODUCTION_BACKEND_URL: prod, CONTEXT: 'deploy-preview', ALLOW_PREVIEW_ON_PRODUCTION_BACKEND: '1' }).status, 0);
});
test('build : contenu de dist (site, règles de relais, en-têtes, noindex hors production)', () => {
  const p = build({ BACKEND_URL: 'https://api.monsite.fr', CONTEXT: 'production' }); assert.equal(p.status, 0, p.stderr);
  for (const f of ['index.html', 'app.js', 'style.css', '404.html', '_redirects', '_headers']) assert.ok(fs.existsSync(path.join(p.out, f)), f);
  assert.equal(fs.readFileSync(path.join(p.out, '_redirects'), 'utf8'), '/api/webhooks/*  /404.html  404!\n/api/*  https://api.monsite.fr/api/:splat  200!\n');
  const h = fs.readFileSync(path.join(p.out, '_headers'), 'utf8');
  for (const k of ['Strict-Transport-Security', 'X-Frame-Options: DENY', "frame-ancestors 'none'", 'X-Content-Type-Options: nosniff']) assert.ok(h.includes(k), k);
  assert.ok(!h.includes('X-Robots-Tag'));
  const v = build({ BACKEND_URL: 'https://api-staging.monsite.fr', CONTEXT: 'deploy-preview' }); assert.match(fs.readFileSync(path.join(v.out, '_headers'), 'utf8'), /X-Robots-Tag: noindex/);
  assert.ok(!fs.readFileSync(path.join(p.out, 'index.html'), 'utf8').includes('localhost'));   // aucune adresse locale embarquée dans le site
});

// ---- Relais simulé : sert dist/, applique _redirects, relaie /api/* en conservant l'Origin du site et en remplaçant le Host par celui du backend
function fakeNetlify(dist, rules) {
  return http.createServer((req, res) => {
    const rule = rules.find((r) => req.url.startsWith(r.prefix));
    if (rule?.status === 404) { res.writeHead(404); return res.end('introuvable'); }
    if (rule) {
      const upstream = new URL(rule.backend + req.url);
      const headers = { ...req.headers, host: upstream.host, 'x-forwarded-for': '203.0.113.50' };
      const p = http.request({ host: upstream.hostname, port: upstream.port, path: upstream.pathname + upstream.search, method: req.method, headers }, (u) => { res.writeHead(u.statusCode, u.headers); u.pipe(res); });
      return void req.pipe(p);
    }
    const f = path.join(dist, req.url === '/' ? 'index.html' : req.url.split('?')[0]);
    if (fs.existsSync(f) && fs.statSync(f).isFile()) { res.writeHead(200); return res.end(fs.readFileSync(f)); }
    res.writeHead(404); res.end('404');
  });
}
function parseRedirects(file, backendBase) {
  return fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).map((l) => { const [from, to, st] = l.split(/\s+/); return { prefix: from.replace('*', ''), status: st.startsWith('404') ? 404 : 200, backend: backendBase }; });
}
class Jar { constructor(base) { this.base = base; this.cookie = ''; }
  async call(m, u, b) { const r = await fetch(this.base + u, { method: m, headers: { 'content-type': 'application/json', origin: this.base, cookie: this.cookie }, body: b === undefined ? undefined : JSON.stringify(b) }); const sc = r.headers.get('set-cookie'); if (sc) this.cookie = sc.split(';')[0]; return { status: r.status, body: await r.json().catch(() => null), headers: r.headers }; } }

test('relais simulé : connexion et écriture via le domaine du site fonctionnent quand PUBLIC_URL est défini ; refusées sinon ; webhook inaccessible via le site', async () => {
  const db = await openDb({ SQLITE_FILE: ':memory:' }); await migrate(db);
  await db.run(`INSERT INTO users(email,password_hash,first_name,last_name,role,active,created_at) VALUES('c@n.test',?,'C','C','client',1,?)`, [await hashPassword('correct-horse-battery'), new Date().toISOString()]);
  const backend = createApp(db); await new Promise((r) => backend.listen(0, r)); const bBase = `http://127.0.0.1:${backend.address().port}`;
  const b = build({ BACKEND_URL: 'https://api.monsite.fr' });
  const proxy = fakeNetlify(b.out, parseRedirects(path.join(b.out, '_redirects'), bBase)); await new Promise((r) => proxy.listen(0, r)); const site = `http://127.0.0.1:${proxy.address().port}`;
  try {
    assert.equal((await fetch(site + '/')).status, 200); assert.equal((await fetch(site + '/app.js')).status, 200);        // le site est servi par « Netlify »
    const c = new Jar(site);
    assert.equal((await c.call('POST', '/api/auth/login', { email: 'c@n.test', password: 'correct-horse-battery' })).status, 403, 'sans PUBLIC_URL, le backend refuse l\'origine du site');
    process.env.PUBLIC_URL = site;
    const login = await c.call('POST', '/api/auth/login', { email: 'c@n.test', password: 'correct-horse-battery' }); assert.equal(login.status, 200);
    assert.ok(c.cookie.startsWith('soloc_sid='));                                                                         // le cookie traverse le relais
    assert.equal((await c.call('GET', '/api/me')).body.email, 'c@n.test');
    assert.equal((await c.call('GET', '/api/vehicles')).status, 200);
    assert.equal((await fetch(site + '/api/webhooks/stripe', { method: 'POST', body: '{}' })).status, 404);               // webhook non exposé via le site
    const evil = new Jar(site); evil.base = site; const r = await fetch(site + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://evil.example.org' }, body: '{}' }); assert.equal(r.status, 403);
  } finally { delete process.env.PUBLIC_URL; proxy.close(); backend.close(); await db.close(); }
});
