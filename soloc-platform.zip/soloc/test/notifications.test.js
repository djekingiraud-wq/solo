// E-mails transactionnels — vérifiés contre un FAUX fournisseur (Resend) local. Aucun envoi réel n'est testé.
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { openDb, migrate } from '../src/db.js';
import { createApp } from '../src/server.js';
import { hashPassword } from '../src/auth.js';
import { dispatchDue, provider } from '../src/notifications.js';

process.env.MAX_PENDING_PER_USER = '1000';
const T0 = Date.now(), iso = (h) => new Date(T0 + h * 3600e3).toISOString();
let db, server, base, fake, calls = [], statuses = [], admin, alice, bob, n = 0;
class Client {
  constructor() { this.cookie = ''; }
  async call(m, u, b) { const r = await fetch(base + u, { method: m, headers: { 'content-type': 'application/json', cookie: this.cookie }, body: b === undefined ? undefined : JSON.stringify(b) }); const sc = r.headers.get('set-cookie'); if (sc) this.cookie = sc.split(';')[0]; return { status: r.status, body: await r.json().catch(() => null) }; }
  get(u) { return this.call('GET', u); } post(u, b = {}) { return this.call('POST', u, b); }
}
async function mk(role, email, first = 'Camille') { await db.run(`INSERT INTO users(email,password_hash,first_name,last_name,role,active,created_at) VALUES(?,?,?,?,?,1,?)`, [email, await hashPassword('correct-horse-battery'), first, 'T', role, new Date().toISOString()]); const c = new Client(); await c.post('/api/auth/login', { email, password: 'correct-horse-battery' }); return c; }
const rows = (w = '1=1') => db.all(`SELECT * FROM notifications WHERE ${w} ORDER BY id`);
const reset = async () => { await db.run('DELETE FROM notifications'); calls = []; statuses = []; };
async function book(c, vehicle) { return (await c.post('/api/bookings', { vehicleId: vehicle, start: iso(100 + ++n * 30), end: iso(124 + n * 30) })); }

before(async () => {
  fake = http.createServer((req, res) => { let d = ''; req.on('data', (c) => (d += c)); req.on('end', () => { calls.push({ headers: req.headers, body: JSON.parse(d) }); res.writeHead(statuses.shift() ?? 200, { 'content-type': 'application/json' }); res.end('{}'); }); });
  await new Promise((r) => fake.listen(0, r));
  Object.assign(process.env, { NOTIFY_MODE: 'resend', RESEND_API_KEY: 're_testkey0123456789', MAIL_FROM: 'SOLOC <reservations@soloc.test>', RESEND_API_BASE: `http://127.0.0.1:${fake.address().port}` });
  db = await openDb({ SQLITE_FILE: ':memory:' }); await migrate(db);
  server = createApp(db); await new Promise((r) => server.listen(0, r)); base = `http://127.0.0.1:${server.address().port}`;
  admin = await mk('admin', 'a@n.test'); alice = await mk('client', 'alice@n.test', 'Alice'); bob = await mk('client', 'bob@n.test');
  await admin.post('/api/admin/vehicles', { id: 'n1', plate: 'NN-001-AA', name: 'Peugeot 508', category: 'Berline', bodyType: 'ber', seats: 5, fuel: 'Diesel', transmission: 'Auto', dailyPriceCents: 8900, depositCents: 0 });
});
after(async () => { server.close(); fake.close(); await db.close(); for (const k of ['NOTIFY_MODE', 'RESEND_API_KEY', 'MAIL_FROM', 'RESEND_API_BASE']) delete process.env[k]; });

test('outbox : chaque étape métier écrit un message dans la même transaction ; un échec métier n\'en écrit aucun', async () => {
  await reset(); const b = (await book(alice, 'n1')).body;
  assert.equal((await book(bob, 'n1')).status, 201);
  const conflict = await alice.post('/api/bookings', { vehicleId: 'n1', start: iso(110 + n * 30), end: iso(130 + n * 30) }); // chevauche la précédente
  const before = (await rows()).length;
  await admin.post(`/api/admin/bookings/${b.ref}/confirm`); await alice.post(`/api/bookings/${b.ref}/cancel`);
  const all = await rows(), t = all.map((r) => r.template);
  assert.deepEqual(t.filter((x) => x === 'booking_received').length, 2); assert.ok(t.includes('booking_confirmed')); assert.ok(t.includes('booking_cancelled'));
  assert.equal(before, 2 + (conflict.status === 409 ? 0 : 1)); // la demande refusée (409) n'a produit aucun e-mail
  const m = all.find((r) => r.template === 'booking_received' && r.to_addr === 'alice@n.test');
  assert.match(m.subject, new RegExp(b.ref)); assert.match(m.body, /Bonjour Alice/); assert.match(m.body, /Peugeot 508/); assert.match(m.body, /Total TTC/); assert.ok(!/password|mot de passe|carte/i.test(m.body));
});
test('outbox : refus d\'une demande notifié ; NOTIFY_MODE=off n\'écrit rien', async () => {
  await reset(); const b = (await book(alice, 'n1')).body; await admin.post(`/api/admin/bookings/${b.ref}/refuse`);
  assert.ok((await rows()).some((r) => r.template === 'booking_refused'));
  await reset(); process.env.NOTIFY_MODE = 'off'; try { await book(bob, 'n1'); assert.equal((await rows()).length, 0); } finally { process.env.NOTIFY_MODE = 'resend'; }
});
test('envoi : requête conforme (clé, expéditeur, destinataire), statut « sent », pas de double envoi', async () => {
  await reset(); await book(alice, 'n1');
  const out = await dispatchDue(db); assert.deepEqual(out, { sent: 1, retry: 0, failed: 0 });
  assert.equal(calls[0].headers.authorization, 'Bearer re_testkey0123456789'); assert.equal(calls[0].body.from, 'SOLOC <reservations@soloc.test>'); assert.deepEqual(calls[0].body.to, ['alice@n.test']);
  assert.equal((await rows())[0].status, 'sent'); assert.deepEqual(await dispatchDue(db), { sent: 0, retry: 0, failed: 0 }); assert.equal(calls.length, 1);
});
test('envoi : panne temporaire => réessai différé puis succès ; erreur définitive (4xx) => échec sans réessai', async () => {
  await reset(); await book(alice, 'n1'); statuses = [500];
  assert.deepEqual(await dispatchDue(db), { sent: 0, retry: 1, failed: 0 });
  let r = (await rows())[0]; assert.equal(r.status, 'queued'); assert.equal(r.attempts, 1); assert.ok(new Date(r.next_attempt_at) > new Date()); assert.match(r.last_error, /500/);
  assert.deepEqual(await dispatchDue(db), { sent: 0, retry: 0, failed: 0 });                         // pas avant l'échéance
  assert.deepEqual(await dispatchDue(db, { nowMs: Date.now() + 3 * 3600e3 }), { sent: 1, retry: 0, failed: 0 });
  await reset(); await book(bob, 'n1'); statuses = [422];
  assert.deepEqual(await dispatchDue(db), { sent: 0, retry: 0, failed: 1 }); r = (await rows())[0]; assert.equal(r.status, 'failed'); assert.equal(calls.length, 1);
});
test('envoi : abandon après 6 tentatives ; fournisseur injoignable traité comme temporaire', async () => {
  await reset(); await book(alice, 'n1'); statuses = Array(10).fill(503); let out, now = Date.now();
  for (let i = 0; i < 6; i++) { out = await dispatchDue(db, { nowMs: now }); now += 3 * 3600e3; }
  assert.deepEqual(out, { sent: 0, retry: 0, failed: 1 }); assert.equal((await rows())[0].attempts, 6);
  await reset(); await book(bob, 'n1'); const real = process.env.RESEND_API_BASE; process.env.RESEND_API_BASE = 'http://127.0.0.1:1';
  try { assert.deepEqual(await dispatchDue(db, { send: provider() }), { sent: 0, retry: 1, failed: 0 }); } finally { process.env.RESEND_API_BASE = real; }
});
test('envoi : deux répartiteurs simultanés n\'envoient chaque message qu\'une fois ; envoi interrompu repris', async () => {
  await reset(); for (let i = 0; i < 4; i++) await book(i % 2 ? alice : bob, 'n1').catch(() => {});
  const total = (await rows()).length; const [a, b] = await Promise.all([dispatchDue(db), dispatchDue(db)]);
  assert.equal(a.sent + b.sent, total); assert.equal(calls.length, total);
  await reset(); await book(alice, 'n1'); await db.run(`UPDATE notifications SET status='sending', next_attempt_at=?`, [new Date(Date.now() - 60e3).toISOString()]);
  assert.equal((await dispatchDue(db)).sent, 1);
});
test('administration : suivi de la file réservé à l\'admin ; les messages en échec y apparaissent', async () => {
  await reset(); await book(alice, 'n1'); statuses = [422]; await dispatchDue(db);
  assert.equal((await alice.get('/api/admin/notifications')).status, 403);
  const s = (await admin.get('/api/admin/notifications')).body; assert.equal(s.counts.failed, 1); assert.equal(s.problems[0].template, 'booking_received'); assert.ok(!JSON.stringify(s).includes('alice@n.test')); // pas d'adresse dans le suivi
});
