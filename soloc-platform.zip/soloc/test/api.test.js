import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { openDb, migrate } from '../src/db.js';
import { createApp } from '../src/server.js';
import { hashPassword } from '../src/auth.js';

process.env.MAX_PENDING_PER_USER = '1000'; // ces scénarios créent beaucoup de demandes ; le plafond a son propre test (audit.test.js)
let db, server, base;
const PW = 'correct-horse-battery';
const iso = (h) => new Date(Date.now() + h * 3600e3).toISOString();

class Client { // client HTTP avec jar de cookies
  constructor() { this.cookie = ''; }
  async call(method, url, body, headers = {}) {
    const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', cookie: this.cookie, ...headers }, body: body ? JSON.stringify(body) : undefined });
    const sc = r.headers.get('set-cookie'); if (sc) this.cookie = sc.split(';')[0].endsWith('=') ? '' : sc.split(';')[0];
    return { status: r.status, body: await r.json().catch(() => null) };
  }
  get(u) { return this.call('GET', u); } post(u, b = {}) { return this.call('POST', u, b); } patch(u, b) { return this.call('PATCH', u, b); }
}
async function newUser(role, email) {
  await db.run(`INSERT INTO users(email,password_hash,first_name,last_name,role,active,created_at) VALUES(?,?,?,?,?,1,?)`, [email, await hashPassword(PW), 'T', role, role, new Date().toISOString()]);
  const c = new Client(); const r = await c.post('/api/auth/login', { email, password: PW }); assert.equal(r.status, 200); return c;
}
const veh = (id, extra = {}) => ({ id, plate: id.toUpperCase() + '-1', name: 'Auto ' + id, category: 'Citadine', bodyType: 'cit', seats: 5, fuel: 'Essence', transmission: 'Manuelle', dailyPriceCents: 5000, depositCents: 30000, ...extra });
let admin, staff, alice, bob;

before(async () => {
  process.env.PENDING_TTL_HOURS = '24';
  db = await openDb({ SQLITE_FILE: ':memory:' }); await migrate(db);
  server = createApp(db); await new Promise((r) => server.listen(0, r)); base = `http://127.0.0.1:${server.address().port}`;
  admin = await newUser('admin', 'admin@t.test'); staff = await newUser('employee', 'staff@t.test');
  alice = await newUser('client', 'alice@t.test'); bob = await newUser('client', 'bob@t.test');
  for (const id of ['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7', 'a8']) assert.equal((await admin.post('/api/admin/vehicles', veh(id))).status, 201);
});
after(async () => { server.close(); await db.close(); });

test('inscription : mot de passe faible refusé, compte créé et session ouverte', async () => {
  const c = new Client();
  assert.equal((await c.post('/api/auth/register', { email: 'x@t.test', password: 'court', firstName: 'X', lastName: 'Y' })).status, 400);
  const ok = await c.post('/api/auth/register', { email: 'x@t.test', password: PW, firstName: 'X', lastName: 'Y' });
  assert.equal(ok.status, 200); assert.equal(ok.body.role, 'client');
  assert.equal((await c.get('/api/me')).body.email, 'x@t.test');
  assert.equal((await c.post('/api/auth/register', { email: 'X@t.test', password: PW, firstName: 'X', lastName: 'Y' })).status, 409);
  const row = await db.get('SELECT password_hash FROM users WHERE email=?', ['x@t.test']);
  assert.match(row.password_hash, /^scrypt\$/); assert.ok(!row.password_hash.includes(PW));
});

test('le catalogue public ne divulgue pas la plaque ; le personnel la voit', async () => {
  const pub = (await new Client().get('/api/vehicles')).body;
  assert.ok(pub.length >= 8); assert.equal(pub[0].plate, undefined);
  assert.ok((await staff.get('/api/vehicles')).body[0].plate);
});

test('le prix vient du serveur : un montant envoyé par le client est ignoré', async () => {
  const r = await alice.post('/api/bookings', { vehicleId: 'a1', start: iso(100), end: iso(100 + 72), options: ['ass'], totalCents: 1, baseCents: 1 });
  assert.equal(r.status, 201);
  assert.equal(r.body.days, 3); assert.equal(r.body.totalCents, 3 * 5000 + 3 * 1400);
  assert.equal(r.body.vatCents, r.body.totalCents - Math.round(r.body.totalCents / 1.2));
  assert.equal((await alice.post('/api/bookings', { vehicleId: 'a2', start: iso(100), end: iso(101), options: ['bidon'] })).status, 400);
});

test('remise de 10 % à partir de 7 jours', async () => {
  const r = (await new Client().get(`/api/quote?vehicle=a3&from=${iso(300)}&to=${iso(300 + 24 * 7)}`)).body;
  assert.equal(r.days, 7); assert.equal(r.discountCents, 3500); assert.equal(r.totalCents, 31500);
});

test('deux demandes simultanées pour le même véhicule : une seule réussit', async () => {
  const body = { vehicleId: 'a4', start: iso(200), end: iso(224) };
  const res = await Promise.all([alice.post('/api/bookings', body), bob.post('/api/bookings', body), alice.post('/api/bookings', body), bob.post('/api/bookings', body)]);
  assert.deepEqual(res.map((x) => x.status).sort(), [201, 409, 409, 409]);
  assert.equal(Number((await db.get(`SELECT COUNT(*) c FROM bookings WHERE vehicle_id='a4'`)).c), 1);
});

test('chevauchement partiel refusé ; réservations bout à bout acceptées', async () => {
  assert.equal((await alice.post('/api/bookings', { vehicleId: 'a5', start: iso(400), end: iso(430) })).status, 201);
  assert.equal((await bob.post('/api/bookings', { vehicleId: 'a5', start: iso(420), end: iso(450) })).status, 409);
  assert.equal((await bob.post('/api/bookings', { vehicleId: 'a5', start: iso(430), end: iso(460) })).status, 201); // fin == début
});

test('période d\'indisponibilité et statut entretien bloquent la réservation', async () => {
  assert.equal((await admin.post('/api/admin/vehicles/a6/unavailabilities', { start: iso(500), end: iso(600), reason: 'Révision' })).status, 201);
  assert.equal((await alice.post('/api/bookings', { vehicleId: 'a6', start: iso(550), end: iso(560) })).status, 409);
  const list = (await alice.get(`/api/vehicles?from=${iso(550)}&to=${iso(560)}`)).body;
  assert.equal(list.find((v) => v.id === 'a6').available, false);
  assert.equal(list.find((v) => v.id === 'a7').available, true);
  await admin.patch('/api/admin/vehicles/a7', { status: 'maintenance' });
  assert.equal((await alice.post('/api/bookings', { vehicleId: 'a7', start: iso(550), end: iso(560) })).status, 409);
  await admin.patch('/api/admin/vehicles/a7', { status: 'active' });
  assert.equal((await alice.post('/api/bookings', { vehicleId: 'a7', start: iso(550), end: iso(560) })).status, 201);
});

test('contrainte en base : un INSERT SQL direct qui chevauche est rejeté (SQLite : trigger ; PostgreSQL : EXCLUDE, non testé ici)', async () => {
  const b = await db.get(`SELECT * FROM bookings WHERE vehicle_id='a5' ORDER BY id LIMIT 1`);
  await assert.rejects(() => db.run(`INSERT INTO bookings(ref,user_id,vehicle_id,start_at,end_at,status,days,base_cents,discount_cents,options_cents,vat_cents,total_cents,deposit_cents,options,created_at,updated_at) VALUES('SL-RAW',?,?,?,?,'confirmed',1,1,0,0,0,1,0,'[]','x','x')`, [b.user_id, 'a5', b.start_at, b.end_at]), /booking_overlap/);
});

test('un client ne voit jamais les réservations d\'un autre', async () => {
  const aRef = (await alice.get('/api/bookings')).body[0].ref;
  assert.equal((await bob.get(`/api/bookings/${aRef}`)).status, 404);
  assert.ok((await bob.get('/api/bookings')).body.every((x) => x.ref !== aRef));
  assert.equal((await new Client().get('/api/bookings')).status, 401);
  assert.equal((await bob.post(`/api/bookings/${aRef}/cancel`)).status, 404);
});

test('permissions : client et employé ne peuvent pas exécuter les actions administrateur', async () => {
  const ref = (await alice.get('/api/bookings')).body.find((b) => b.status === 'pending').ref;
  for (const c of [alice, staff]) {
    assert.equal((await c.post(`/api/admin/bookings/${ref}/confirm`)).status, 403);
    assert.equal((await c.post('/api/admin/vehicles', veh('zz'))).status, 403);
    assert.equal((await c.get('/api/admin/audit')).status, 403);
  }
  assert.equal((await alice.get('/api/admin/dashboard')).status, 403);
  assert.equal((await staff.get('/api/admin/dashboard')).status, 200);
  assert.equal((await staff.get('/api/admin/dashboard')).body.revenueCents, undefined); // finances réservées à l'admin
  assert.equal((await staff.get('/api/bookings')).status, 200);
  assert.equal((await admin.post(`/api/admin/bookings/${ref}/confirm`)).body.status, 'confirmed');
});

test('expiration : une demande non confirmée libère le véhicule', async () => {
  const r = await alice.post('/api/bookings', { vehicleId: 'a8', start: iso(700), end: iso(720) });
  assert.equal(r.status, 201);
  assert.equal((await bob.post('/api/bookings', { vehicleId: 'a8', start: iso(700), end: iso(720) })).status, 409);
  await db.run(`UPDATE bookings SET expires_at=? WHERE ref=?`, [iso(-1), r.body.ref]);
  assert.equal((await bob.post('/api/bookings', { vehicleId: 'a8', start: iso(700), end: iso(720) })).status, 201);
  assert.equal((await alice.get(`/api/bookings/${r.body.ref}`)).body.status, 'expired');
  assert.equal((await admin.post(`/api/admin/bookings/${r.body.ref}/confirm`)).status, 409);
});

test('archivage : refusé avec réservations ouvertes ; l\'historique survit à l\'archivage', async () => {
  await admin.post('/api/admin/vehicles', veh('old'));
  const r = await alice.post('/api/bookings', { vehicleId: 'old', start: iso(800), end: iso(824) });
  assert.equal((await admin.post('/api/admin/vehicles/old/archive')).status, 409);
  await alice.post(`/api/bookings/${r.body.ref}/cancel`);
  assert.equal((await admin.post('/api/admin/vehicles/old/archive')).status, 200);
  const kept = (await alice.get(`/api/bookings/${r.body.ref}`)).body;
  assert.equal(kept.status, 'cancelled'); assert.equal(kept.vehicleName, 'Auto old');
  assert.equal((await new Client().get('/api/vehicles')).body.find((v) => v.id === 'old'), undefined);
  assert.ok(await db.get(`SELECT id FROM vehicles WHERE id='old'`)); // la ligne existe toujours
});

test('un changement de tarif ne modifie pas une réservation existante', async () => {
  await admin.post('/api/admin/vehicles', veh('px'));
  const r = (await alice.post('/api/bookings', { vehicleId: 'px', start: iso(900), end: iso(948) })).body;
  await admin.patch('/api/admin/vehicles/px', { dailyPriceCents: 99999 });
  assert.equal((await alice.get(`/api/bookings/${r.ref}`)).body.totalCents, 10000);
  assert.equal((await new Client().get(`/api/quote?vehicle=px&from=${iso(1000)}&to=${iso(1024)}`)).body.totalCents, 99999);
});

test('départ, retour, paiements et tableau de bord cohérents avec les données', async () => {
  await admin.post('/api/admin/vehicles', veh('ops'));
  const r = (await alice.post('/api/bookings', { vehicleId: 'ops', start: iso(1), end: iso(26) })).body;
  assert.equal((await staff.post(`/api/bookings/${r.ref}/pickup`, { odometerKm: 100, fuelLevel: 80 })).status, 409); // pas encore confirmée
  await admin.post(`/api/admin/bookings/${r.ref}/confirm`);
  assert.equal((await alice.post(`/api/bookings/${r.ref}/pickup`, { odometerKm: 1, fuelLevel: 1 })).status, 403);
  const before = (await admin.get('/api/admin/dashboard')).body;
  assert.equal((await staff.post(`/api/bookings/${r.ref}/pickup`, { odometerKm: 12000, fuelLevel: 80 })).body.status, 'active');
  const mid = (await admin.get('/api/admin/dashboard')).body;
  assert.equal(mid.rented, before.rented + 1); assert.equal(mid.available, before.available - 1);
  assert.equal((await admin.post(`/api/admin/bookings/${r.ref}/payments`, { kind: 'payment', amountCents: 3000, method: 'manual' })).body.paidCents, 3000);
  assert.equal((await admin.post(`/api/admin/bookings/${r.ref}/payments`, { kind: 'refund', amountCents: 9000 })).status, 409);
  assert.equal((await staff.post(`/api/bookings/${r.ref}/return`, { odometerKm: 11000, fuelLevel: 50 })).status, 400);
  assert.equal((await staff.post(`/api/bookings/${r.ref}/return`, { odometerKm: 12150, fuelLevel: 40 })).body.status, 'completed');
  const after = (await admin.get('/api/admin/dashboard')).body;
  assert.equal(after.rented, before.rented);
  const sum = Number((await db.get(`SELECT SUM(amount_cents) s FROM payments WHERE kind='payment'`)).s);
  assert.equal(after.revenueCents, sum);
  const total = Number((await db.get(`SELECT COUNT(*) c FROM vehicles WHERE status<>'archived'`)).c);
  assert.equal(after.activeVehicles, total);
  assert.ok(Number((await db.get(`SELECT COUNT(*) c FROM audit_log WHERE action='booking.return'`)).c) >= 1);
});

test('annulation client : libre si en attente ; refusée à moins de 48 h si confirmée', async () => {
  await admin.post('/api/admin/vehicles', veh('can'));
  const r = (await alice.post('/api/bookings', { vehicleId: 'can', start: iso(10), end: iso(34) })).body;
  await admin.post(`/api/admin/bookings/${r.ref}/confirm`);
  assert.equal((await alice.post(`/api/bookings/${r.ref}/cancel`)).status, 403);
  assert.equal((await admin.post(`/api/bookings/${r.ref}/cancel`)).body.status, 'cancelled');
});

test('requêtes inter-origines et corps non JSON refusés ; erreurs sans fuite', async () => {
  assert.equal((await alice.call('POST', '/api/bookings', { vehicleId: 'a1' }, { origin: 'https://evil.example' })).status, 403);
  const r = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'text/plain' }, body: 'x' });
  assert.equal(r.status, 415);
  const bad = await alice.post('/api/bookings', { vehicleId: "a1'; DROP TABLE bookings;--", start: iso(5), end: iso(9) });
  assert.equal(bad.status, 404); assert.ok(Number((await db.get('SELECT COUNT(*) c FROM bookings')).c) > 0);
});

test('limitation des tentatives de connexion', async () => {
  const c = new Client(); let last;
  for (let i = 0; i < 7; i++) last = await c.post('/api/auth/login', { email: 'alice@t.test', password: 'mauvais-mot-de-passe' });
  assert.equal(last.status, 429);
});

test('mobile : jeton Bearer renvoyé uniquement sur demande, accepté, révoqué à la déconnexion', async () => {
  const login = (h) => fetch(base + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json', ...h }, body: JSON.stringify({ email: 'bob@t.test', password: PW }) }).then((r) => r.json());
  assert.equal((await login({})).token, undefined);
  const { token } = await login({ 'x-soloc-client': 'mobile' });
  assert.match(token, /^[0-9a-f]{64}$/);
  const me = (t) => fetch(base + '/api/me', { headers: { authorization: `Bearer ${t}` } }).then((r) => r.json());
  assert.equal((await me(token)).email, 'bob@t.test');
  await fetch(base + '/api/auth/logout', { method: 'POST', headers: { authorization: `Bearer ${token}` } });
  assert.equal(await me(token), null);
});

test('incidents : l\'employé signale, le client ne peut pas, la liste est réservée au personnel', async () => {
  const good = { vehicleId: 'a1', category: 'damage', severity: 'medium', description: 'Rayure aile avant droite' };
  assert.equal((await staff.post('/api/incidents', good)).status, 201);
  assert.equal((await alice.post('/api/incidents', good)).status, 403);
  assert.equal((await staff.post('/api/incidents', { ...good, severity: 'x' })).status, 400);
  assert.equal((await staff.post('/api/incidents', { ...good, vehicleId: 'nope' })).status, 404);
  assert.equal((await alice.get('/api/incidents')).status, 403);
  assert.equal((await staff.get('/api/incidents')).body[0].description, good.description);
});
