// Vérifie que le client réseau du mobile (mobile/src) fonctionne contre le VRAI backend, de bout en bout.
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { openDb, migrate } from '../src/db.js';
import { createApp } from '../src/server.js';
import { hashPassword } from '../src/auth.js';
import { createApi } from '../mobile/src/api.ts';
import { createServices } from '../mobile/src/services.ts';
import { ApiError } from '../mobile/src/errors.ts';

let db, server, base;
const PW = 'correct-horse-battery';
const iso = (h) => new Date(Date.now() + h * 3600e3).toISOString();
const session = () => { let token = null; const api = createApi({ baseUrl: base, getToken: () => token }); const s = createServices(api); return { s, setToken: (t) => { token = t; } }; };
const login = async (email) => { const m = session(); const u = await m.s.login(email, PW); m.setToken(u.token); return m.s; };

before(async () => {
  db = await openDb({ SQLITE_FILE: ':memory:' }); await migrate(db);
  server = createApp(db); await new Promise((r) => server.listen(0, r)); base = `http://127.0.0.1:${server.address().port}`;
  for (const [role, email] of [['admin', 'a@m.test'], ['employee', 'e@m.test'], ['client', 'c@m.test'], ['client', 'd@m.test']])
    await db.run(`INSERT INTO users(email,password_hash,first_name,last_name,role,active,created_at) VALUES(?,?,?,?,?,1,?)`, [email, await hashPassword(PW), 'T', role, role, new Date().toISOString()]);
  const admin = await login('a@m.test');
  await db.run(`INSERT INTO vehicles(id,plate,name,category,body_type,color,seats,fuel,transmission,daily_price_cents,deposit_cents,status,created_at) VALUES('v1','AA-1','Test 1','Citadine','cit','#336699',5,'Essence','Manuelle',5000,30000,'active',?)`, [new Date().toISOString()]);
  void admin;
});
after(async () => { server.close(); await db.close(); });

test('parcours client mobile : connexion, catalogue, devis, réservation, conflit, annulation', async () => {
  const c = await login('c@m.test');
  const list = await c.vehicles(iso(48), iso(72)); assert.equal(list[0].available, true);
  assert.deepEqual((await c.options()).map((o) => o.id).sort(), ['ass', 'cdr', 'sie']);
  const q = await c.quote('v1', iso(48), iso(72), ['ass']); assert.equal(q.totalCents, 5000 + 1400);
  const b = await c.createBooking({ vehicleId: 'v1', start: iso(48), end: iso(72), options: ['ass'] });
  assert.equal(b.status, 'pending'); assert.equal(b.totalCents, q.totalCents);
  const d = await login('d@m.test');
  await assert.rejects(() => d.createBooking({ vehicleId: 'v1', start: iso(50), end: iso(60), options: [] }), (e) => e instanceof ApiError && e.kind === 'conflict');
  assert.equal((await d.vehicles(iso(48), iso(72)))[0].available, false);
  await assert.rejects(() => d.booking(b.ref), (e) => e.kind === 'notfound');
  assert.equal((await c.bookings()).length, 1);
  assert.equal((await c.cancel(b.ref)).status, 'cancelled');
});

test('parcours employé mobile : planning, remise, retour, incident ; droits refusés au client', async () => {
  const c = await login('c@m.test'), e = await login('e@m.test'), a = await login('a@m.test');
  const b = await c.createBooking({ vehicleId: 'v1', start: iso(1), end: iso(25), options: [] });
  await assert.rejects(() => e.confirm(b.ref), (x) => x.kind === 'forbidden');
  assert.equal((await a.confirm(b.ref)).status, 'confirmed');
  assert.ok((await e.bookings()).some((x) => x.ref === b.ref && x.client)); // l'employé voit le nom du client
  assert.equal((await e.pickup(b.ref, 5000, 90)).status, 'active');
  await assert.rejects(() => e.giveBack(b.ref, 4000, 50), (x) => x.kind === 'validation');
  assert.equal((await e.giveBack(b.ref, 5100, 40)).status, 'completed');
  const inc = await e.createIncident({ vehicleId: 'v1', bookingRef: b.ref, category: 'cleaning', severity: 'low', description: 'Intérieur à nettoyer' });
  assert.equal(inc.status, 'open');
  assert.equal((await e.incidents())[0].bookingRef, b.ref);
  await assert.rejects(() => c.incidents(), (x) => x.kind === 'forbidden');
});

test('session expirée : le serveur répond 401 et le client mobile déclenche la déconnexion', async () => {
  let out = 0, token = null;
  const api = createApi({ baseUrl: base, getToken: () => token, onUnauthorized: () => out++ });
  const s = createServices(api);
  token = (await s.login('c@m.test', PW)).token;
  await s.logout();
  await assert.rejects(() => s.bookings(), (x) => x.kind === 'unauthorized');
  assert.equal(out, 1);
});

test('serveur injoignable : erreur "network" claire, sans exception brute', async () => {
  const s = createServices(createApi({ baseUrl: 'http://127.0.0.1:1', getToken: () => null }));
  await assert.rejects(() => s.vehicles(), (x) => x.kind === 'network');
});

test('paiement côté mobile : configuration publique et refus propre quand le paiement est désactivé', async () => {
  const c = await login('c@m.test');
  assert.equal((await c.config()).onlinePayment, false);
  const b = await c.createBooking({ vehicleId: 'v1', start: iso(500), end: iso(524), options: [] });
  await assert.rejects(() => c.checkout(b.ref), (e) => e instanceof ApiError && e.status === 503);
});
