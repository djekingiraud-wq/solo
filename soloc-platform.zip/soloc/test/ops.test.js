// Exploitation : configuration, migrations, sondes, démarrage/arrêt réels du processus, sauvegardes.
import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
import { loadConfig } from '../src/config.js';
import { openDb, migrate, pendingMigrations } from '../src/db.js';
import { createApp } from '../src/server.js';
import { hashPassword } from '../src/auth.js';
import { backupSqlite, verifyBackup } from '../src/backup.js';

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const GOOD = { NODE_ENV: 'production', DATABASE_URL: 'postgres://soloc:Zk3pQ9xLm2@db:5432/soloc', PUBLIC_URL: 'https://soloc.test', TRUST_PROXY: '1' };

test('config : une configuration de production valide ne produit aucune erreur', () => {
  const c = loadConfig({ ...GOOD }); assert.deepEqual(c.errors, []);
  assert.equal(c.services.database.mode, 'postgresql'); assert.equal(c.services.push.configured, false); assert.equal(c.services.payments.configured, false);
});
test('config : production refusée si base, URL HTTPS ou secrets sont absents, factices ou mal formés', () => {
  const e = (env) => loadConfig(env).errors.join(' | ');
  assert.match(e({ NODE_ENV: 'production', PUBLIC_URL: 'https://soloc.test' }), /DATABASE_URL/);                              // pas de SQLite en prod
  assert.match(e({ ...GOOD, DATABASE_URL: 'postgres://u:CHANGE_ME@db/soloc' }), /valeur d'exemple/);
  assert.match(e({ ...GOOD, PUBLIC_URL: 'http://soloc.test' }), /PUBLIC_URL/);                                                 // HTTPS obligatoire
  assert.match(e({ ...GOOD, PUBLIC_URL: 'https://soloc.test/' }), /PUBLIC_URL/);
  assert.match(e({ ...GOOD, PUBLIC_URL: 'https://soloc.example' }), /domaine d'exemple/);
  assert.match(e({ ...GOOD, PAYMENTS_MODE: 'stripe' }), /STRIPE_SECRET_KEY/);
  assert.match(e({ ...GOOD, PAYMENTS_MODE: 'stripe', STRIPE_SECRET_KEY: 'pk_live_abcdefghij', STRIPE_WEBHOOK_SECRET: 'whsec_abcdefghij' }), /STRIPE_SECRET_KEY/); // clé publique refusée
  assert.match(e({ ...GOOD, PAYMENTS_MODE: 'stripe', STRIPE_SECRET_KEY: 'sk_live_abcdefghij' }), /STRIPE_WEBHOOK_SECRET/);
  assert.match(e({ ...GOOD, NOTIFY_MODE: 'resend' }), /RESEND_API_KEY/);
  assert.match(e({ ...GOOD, NOTIFY_MODE: 'smtp' }), /NOTIFY_MODE/);
  assert.match(e({ ...GOOD, PENDING_TTL_HOURS: 'abc' }), /PENDING_TTL_HOURS/);
});
test('config : avertissements (clé Stripe de test en production, e-mails non envoyés, proxy)', () => {
  const w = loadConfig({ ...GOOD, TRUST_PROXY: undefined, PAYMENTS_MODE: 'stripe', STRIPE_SECRET_KEY: 'sk_test_abcdefghij', STRIPE_WEBHOOK_SECRET: 'whsec_abcdefghij', NOTIFY_MODE: 'log' });
  assert.deepEqual(w.errors, []); const t = w.warnings.join(' | ');
  assert.match(t, /mode TEST/); assert.match(t, /NOTIFY_MODE=log/); assert.match(t, /TRUST_PROXY/);
  assert.equal(w.services.payments.configured, true); assert.equal(w.services.payments.live, false);
});

test('migrations : somme de contrôle, détection de modification, état « en attente »', async () => {
  const db = await openDb({ SQLITE_FILE: ':memory:' });
  assert.equal((await pendingMigrations(db)).length, 3);
  assert.equal((await migrate(db)).length, 3); assert.deepEqual(await migrate(db), []); assert.deepEqual(await pendingMigrations(db), []); // idempotent
  await db.run(`UPDATE schema_migrations SET checksum='deadbeef' WHERE name='001_init.sql'`); // simule un fichier modifié après application
  await assert.rejects(() => migrate(db), /001_init\.sql a été modifiée/);
  await db.run(`UPDATE schema_migrations SET checksum=NULL`); assert.deepEqual(await migrate(db), []); // base ancienne : somme de contrôle complétée
  await db.close();
});

async function post(base, p, body, headers = {}) { const r = await fetch(base + p, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body) }); return { status: r.status, body: await r.json().catch(() => null) }; }

test('sondes /healthz et /readyz ; /readyz passe en 503 si migration en attente ou base fermée', async () => {
  const db = await openDb({ SQLITE_FILE: ':memory:' }); await migrate(db);
  const srv = createApp(db); await new Promise((r) => srv.listen(0, r)); const base = `http://127.0.0.1:${srv.address().port}`;
  assert.equal((await fetch(base + '/healthz')).status, 200); assert.equal((await fetch(base + '/readyz')).status, 200);
  await db.run(`DELETE FROM schema_migrations WHERE name='003_payments_notifications.sql'`);
  const pend = await fetch(base + '/readyz'); assert.equal(pend.status, 503); assert.equal((await pend.json()).status, 'migrations_pending');
  assert.equal((await fetch(base + '/healthz')).status, 200); // vivant mais pas prêt
  await db.close(); const down = await fetch(base + '/readyz'); assert.equal(down.status, 503); assert.equal((await down.json()).status, 'database_unavailable');
  srv.close();
});

test('IP réelle derrière proxy : une valeur X-Forwarded-For falsifiée en tête ne contourne pas la limitation', async () => {
  const db = await openDb({ SQLITE_FILE: ':memory:' }); await migrate(db);
  await db.run(`INSERT INTO users(email,password_hash,first_name,last_name,role,active,created_at) VALUES('v@t.test',?,'V','V','client',1,?)`, [await hashPassword('correct-horse-battery'), new Date().toISOString()]);
  const srv = createApp(db); await new Promise((r) => srv.listen(0, r)); const base = `http://127.0.0.1:${srv.address().port}`;
  process.env.TRUST_PROXY = '1';
  try {
    const last = []; for (let i = 0; i < 7; i++) last.push((await post(base, '/api/auth/login', { email: 'v@t.test', password: 'mauvais-mot-de-passe' }, { 'x-forwarded-for': `10.0.0.${i}, 198.51.100.7` })).status);
    assert.deepEqual(last.slice(0, 5), [401, 401, 401, 401, 401]); assert.deepEqual(last.slice(5), [429, 429]); // même IP réelle (la dernière) => bloqué
  } finally { delete process.env.TRUST_PROXY; srv.close(); await db.close(); }
});

const run = (args, env) => spawnSync('node', args, { cwd: ROOT, env: { PATH: process.env.PATH, ...env }, encoding: 'utf8', timeout: 15000 });
test('démarrage réel : refusé en production avec configuration invalide ; refusé tant que des migrations sont en attente', () => {
  const bad = run(['src/server.js'], { NODE_ENV: 'production' });
  assert.equal(bad.status, 1); assert.match(bad.stderr, /DATABASE_URL/); assert.match(bad.stderr, /Démarrage refusé/);
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'soloc-')), 'p.db');
  const env = { NODE_ENV: 'production', ALLOW_SQLITE_IN_PRODUCTION: '1', SQLITE_FILE: f, PUBLIC_URL: 'https://soloc.test', TRUST_PROXY: '1', PORT: '3391' };
  const pend = run(['src/server.js'], env); assert.equal(pend.status, 1); assert.match(pend.stderr, /Migrations en attente/);
  const seed = run(['src/seed.js'], env); assert.equal(seed.status, 1); assert.match(seed.stderr, /production/); // pas de données de démonstration en production
});
test('démarrage réel : migrate -> serveur prêt -> SIGTERM => arrêt propre (code 0)', async () => {
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'soloc-')), 'p.db');
  const env = { PATH: process.env.PATH, NODE_ENV: 'production', ALLOW_SQLITE_IN_PRODUCTION: '1', SQLITE_FILE: f, PUBLIC_URL: 'https://soloc.test', TRUST_PROXY: '1', PORT: '3392', LOG_REQUESTS: '1' };
  assert.equal(run(['src/migrate.js'], env).status, 0);
  const child = spawn('node', ['src/server.js'], { cwd: ROOT, env }); let out = ''; child.stdout.on('data', (d) => (out += d)); child.stderr.on('data', (d) => (out += d));
  const code = new Promise((r) => child.on('exit', r));
  let ready = false; for (let i = 0; i < 40 && !ready; i++) { await new Promise((r) => setTimeout(r, 150)); try { ready = (await fetch('http://127.0.0.1:3392/readyz')).status === 200; } catch { /* démarrage */ } }
  assert.ok(ready, 'le serveur n\'est jamais devenu prêt : ' + out);
  const h = await fetch('http://127.0.0.1:3392/api/options'); assert.match(h.headers.get('strict-transport-security') || '', /max-age/);
  child.kill('SIGTERM'); assert.equal(await Promise.race([code, new Promise((r) => setTimeout(() => r('timeout'), 5000))]), 0);
  assert.match(out, /arrêt en cours/); assert.match(out, /"p":"\/api\/options"/); assert.ok(!/cookie|authorization/i.test(out)); // journaux JSON sans données sensibles
});

test('sauvegarde SQLite : réalisée pendant l\'usage, vérifiée, altération détectée, restauration fonctionnelle', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'soloc-bk-')), file = path.join(dir, 'live.db');
  const db = await openDb({ SQLITE_FILE: file }); await migrate(db);
  await db.run(`INSERT INTO users(email,password_hash,first_name,last_name,role,active,created_at) VALUES('b@t.test','x','B','B','client',1,?)`, [new Date().toISOString()]);
  const bk = backupSqlite(file, path.join(dir, 'bk')); // base ouverte et en service
  await db.run(`INSERT INTO users(email,password_hash,first_name,last_name,role,active,created_at) VALUES('c@t.test','x','C','C','client',1,?)`, [new Date().toISOString()]);
  const v = verifyBackup(bk); assert.equal(v.ok, true); assert.equal(v.counts.users, 1); // l'instantané ne contient pas la ligne ajoutée ensuite
  const bad = bk + '.corrompu'; fs.copyFileSync(bk, bad); fs.copyFileSync(bk + '.sha256', bad + '.sha256'); fs.appendFileSync(bad, 'XXXX');
  assert.equal(verifyBackup(bad).ok, false); assert.match(verifyBackup(bad).problems.join(), /somme de contrôle/);
  const restored = path.join(dir, 'restored.db'); fs.copyFileSync(bk, restored);
  const r = await openDb({ SQLITE_FILE: restored }); assert.deepEqual(await pendingMigrations(r), []); assert.equal(Number((await r.get('SELECT COUNT(*) c FROM users')).c), 1);
  await r.close(); await db.close();
});

test('create-admin : crée un administrateur, refuse doublon, mot de passe faible et migrations en attente', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'soloc-ca-')), f = path.join(dir, 'a.db'), env = { SQLITE_FILE: f };
  assert.equal(run(['src/create-admin.js', 'a@soloc.test'], env).status, 1);                                   // migrations en attente
  assert.equal(run(['src/migrate.js'], env).status, 0);
  assert.equal(run(['src/create-admin.js', 'pas-un-email'], env).status, 2);
  assert.equal(run(['src/create-admin.js', 'a@soloc.test'], { ...env, ADMIN_PASSWORD: 'court' }).status, 2);
  const ok = run(['src/create-admin.js', 'A@Soloc.test', 'Ada', 'Admin'], env); assert.equal(ok.status, 0); assert.match(ok.stdout, /Mot de passe \(affiché une seule fois/);
  assert.equal(run(['src/create-admin.js', 'a@soloc.test'], env).status, 1);                                   // doublon (casse ignorée)
  const pw = ok.stdout.match(/: (\S+)\s*$/)[1];
  return openDb({ SQLITE_FILE: f }).then(async (db) => {
    const u = await db.get('SELECT email,role,password_hash FROM users'); assert.equal(u.role, 'admin'); assert.equal(u.email, 'a@soloc.test'); assert.ok(!u.password_hash.includes(pw));
    assert.ok(await db.get(`SELECT 1 x FROM audit_log WHERE action='user.create'`)); await db.close();
  });
});
test('config : mot de passe PostgreSQL factice ou trop court refusé', () => {
  assert.match(loadConfig({ ...GOOD, POSTGRES_PASSWORD: 'CHANGE_ME' }).errors.join(), /POSTGRES_PASSWORD/);
  assert.match(loadConfig({ ...GOOD, POSTGRES_PASSWORD: 'court' }).errors.join(), /POSTGRES_PASSWORD/);
  assert.deepEqual(loadConfig({ ...GOOD, POSTGRES_PASSWORD: 'Zk3pQ9xLm2Rt7' }).errors, []);
});

test('origines : site relayé (Netlify) accepté via PUBLIC_URL / ALLOWED_ORIGINS ; origine étrangère, « null » et invalide refusées sans erreur 500', async () => {
  const db = await openDb({ SQLITE_FILE: ':memory:' }); await migrate(db);
  const srv = createApp(db); await new Promise((r) => srv.listen(0, r)); const port = srv.address().port;
  const http = await import('node:http');
  const send = (origin, host = `api-backend.test:${port}`) => new Promise((ok) => { const r = http.request({ host: '127.0.0.1', port, path: '/api/auth/login', method: 'POST', headers: { host, ...(origin ? { origin } : {}), 'content-type': 'application/json' } }, (res) => { res.resume(); ok(res.statusCode); }); r.end('{"email":"x@y.zz","password":"p"}'); });
  try {
    assert.equal(await send('https://monsite.netlify.app'), 403);                       // non déclarée : refusée
    process.env.PUBLIC_URL = 'https://monsite.netlify.app';
    assert.equal(await send('https://monsite.netlify.app'), 401);                       // acceptée (401 = identifiants faux, la requête est passée)
    assert.equal(await send('https://evil.example.org'), 403); assert.equal(await send('null'), 403); assert.equal(await send('pas une url'), 403);
    delete process.env.PUBLIC_URL; process.env.ALLOWED_ORIGINS = 'https://www.monsite.fr, https://preview--monsite.netlify.app';
    assert.equal(await send('https://www.monsite.fr'), 401); assert.equal(await send('https://preview--monsite.netlify.app'), 401); assert.equal(await send('https://monsite.fr'), 403);
    assert.equal(await send(undefined), 401);                                           // clients sans Origin (mobile, curl) inchangés
  } finally { delete process.env.PUBLIC_URL; delete process.env.ALLOWED_ORIGINS; srv.close(); await db.close(); }
});
test('config : ALLOWED_ORIGINS invalide ou d\'exemple refusé en production', () => {
  assert.match(loadConfig({ ...GOOD, ALLOWED_ORIGINS: 'http://a.fr' }).errors.join(), /ALLOWED_ORIGINS/);
  assert.match(loadConfig({ ...GOOD, ALLOWED_ORIGINS: 'https://a.fr/' }).errors.join(), /ALLOWED_ORIGINS/);
  assert.match(loadConfig({ ...GOOD, ALLOWED_ORIGINS: 'https://soloc.example' }).errors.join(), /ALLOWED_ORIGINS/);
  assert.deepEqual(loadConfig({ ...GOOD, ALLOWED_ORIGINS: 'https://a.fr, https://b.netlify.app' }).errors, []);
});

test('origines : joker limité à l\'intérieur d\'un libellé (aperçus Netlify) ; jamais un libellé entier', async () => {
  const db = await openDb({ SQLITE_FILE: ':memory:' }); await migrate(db);
  const srv = createApp(db); await new Promise((r) => srv.listen(0, r)); const port = srv.address().port; const http = await import('node:http');
  const send = (origin) => new Promise((ok) => { const r = http.request({ host: '127.0.0.1', port, path: '/api/auth/login', method: 'POST', headers: { host: 'api.test', origin, 'content-type': 'application/json' } }, (res) => { res.resume(); ok(res.statusCode); }); r.end('{"email":"x@y.zz","password":"p"}'); });
  process.env.ALLOWED_ORIGINS = 'https://deploy-preview-*--monsite.netlify.app';
  try {
    assert.equal(await send('https://deploy-preview-12--monsite.netlify.app'), 401);
    assert.equal(await send('https://deploy-preview-7--monsite.netlify.app'), 401);
    for (const o of ['https://deploy-preview-12--autre.netlify.app', 'https://monsite.netlify.app', 'https://deploy-preview-1.evil.org--monsite.netlify.app', 'https://deploy-preview---monsite.netlify.app.evil.org', 'https://deploy-preview-12--monsite.netlify.app.evil.org']) assert.equal(await send(o), 403, o);
  } finally { delete process.env.ALLOWED_ORIGINS; srv.close(); await db.close(); }
  assert.match(loadConfig({ ...GOOD, ALLOWED_ORIGINS: 'https://*.netlify.app' }).errors.join(), /libellé DNS entier/);
  const w = loadConfig({ ...GOOD, ALLOWED_ORIGINS: 'https://deploy-preview-*--monsite.netlify.app' }); assert.deepEqual(w.errors, []); assert.match(w.warnings.join(), /joker/);
});

test('étalonnage du proxy : LOG_CLIENT_IP journalise la chaîne X-Forwarded-For et l\'IP retenue, uniquement sur demande', async () => {
  const db = await openDb({ SQLITE_FILE: ':memory:' }); await migrate(db);
  const srv = createApp(db); await new Promise((r) => srv.listen(0, r)); const base = `http://127.0.0.1:${srv.address().port}`;
  const lines = []; const orig = console.log; console.log = (l) => lines.push(l);
  Object.assign(process.env, { LOG_REQUESTS: '1', TRUST_PROXY: '1', TRUST_PROXY_HOPS: '2' });
  try {
    await fetch(base + '/api/options', { headers: { 'x-forwarded-for': '203.0.113.5, 10.1.1.1, 10.2.2.2' } }); await new Promise((r) => setTimeout(r, 50));
    assert.ok(!lines.at(-1).includes('xff'));                                            // désactivé par défaut (donnée personnelle)
    process.env.LOG_CLIENT_IP = '1';
    await fetch(base + '/api/options', { headers: { 'x-forwarded-for': '203.0.113.5, 10.1.1.1, 10.2.2.2' } }); await new Promise((r) => setTimeout(r, 50));
    const l = JSON.parse(lines.at(-1)); assert.equal(l.xff, '203.0.113.5, 10.1.1.1, 10.2.2.2'); assert.equal(l.ip, '10.1.1.1');   // 2 relais de confiance => avant-dernière valeur
  } finally { console.log = orig; for (const k of ['LOG_REQUESTS', 'TRUST_PROXY', 'TRUST_PROXY_HOPS', 'LOG_CLIENT_IP']) delete process.env[k]; srv.close(); await db.close(); }
});
