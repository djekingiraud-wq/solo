## Changement
<!-- Quoi et pourquoi, en deux phrases. -->

## Vérifications
- [ ] `npm test` et `npm run test:mobile` verts (CI)
- [ ] Aucune migration existante modifiée (nouvelle migration `00N_…sql` si besoin, **additive**)
- [ ] Aucun secret, aucune clé, aucun `.env*` dans le diff
- [ ] Si API modifiée : l'application mobile publiée reste compatible
- [ ] Si prix, paiement ou disponibilité : test ajouté
- [ ] Si nouvelle variable d'environnement : `src/config.js`, `.env.production.example` et `docs/DEPLOY.md` à jour

## Risque et retour arrière
<!-- Que se passe-t-il si on revient en arrière ? Les données restent-elles compatibles ? -->
